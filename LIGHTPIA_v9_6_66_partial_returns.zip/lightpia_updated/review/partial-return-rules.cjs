const assert=require('node:assert/strict'),fs=require('node:fs'),api=require('firebase/firestore');
const {initializeTestEnvironment,assertFails}=require('@firebase/rules-unit-testing');
const ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2';
const equipment=(db,id)=>api.doc(db,'company/main/equipment',id);
const loan=(db,id)=>api.doc(db,'company/main/loans',id);

(async()=>{
 const {maintenanceReturnFields,partialReturnLimit}=await import('../www/maintenance-model.js');
 const {patchPartialReturnRules}=await import('../push_sender/partial-return-rules.mjs');
 const rules=fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8');
 assert.equal(patchPartialReturnRules(rules),rules);
 const source=fs.readFileSync('www/app.js','utf8');
 const implementation=source.slice(source.indexOf('async function returnLoan(l,quantity)'),source.indexOf('let signupSubmitting='));
 const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules}});
 try{
  await env.clearFirestore();
  const owner={ownerUid:ADMIN,teamId:'T',team:'본팀',projectId:'P',person:'관리자',loanDate:'2026-11-01',dueDate:'2026-12-31',status:'active',quantity:4};
  await env.withSecurityRulesDisabled(async c=>{
   const db=c.firestore();
   await api.setDoc(api.doc(db,'teams/T'),{active:true,name:'본팀'});
   await api.setDoc(api.doc(db,'teams/U'),{active:true,name:'다른 팀'});
   for(const [id,teamId] of [['staff','T'],['other','U']])await api.setDoc(api.doc(db,'members',id),{active:true,role:'team',teamId});
   for(const [id,extra] of [['ea',{}],['box',{unit:'BOX',unitsPerBox:4}]]){
    await api.setDoc(equipment(db,id),{name:id,total:12,loaned:4,repairing:0,...extra});
    await api.setDoc(loan(db,id),{...owner,equipmentId:id,equipmentName:id,...extra,...(id==='box'?{damageEa:5,lastDamageId:'reported'}:{})});
   }
  });
  const staff=env.authenticatedContext('staff').firestore(),admin=env.authenticatedContext(ADMIN).firestore(),other=env.authenticatedContext('other').firestore();
  const read=async ref=>(await api.getDoc(ref)).data();
  const run=db=>new Function('db','doc','collection','runTransaction','serverTimestamp','loanDoc','eqDoc','maintenanceReturnFields','partialReturnLimit','canHandleLoan',implementation+';return returnLoan;')(
   db,api.doc,api.collection,api.runTransaction,api.serverTimestamp,id=>loan(db,id),id=>equipment(db,id),maintenanceReturnFields,partialReturnLimit,()=>true);
  const ea={id:'ea',...await read(loan(staff,'ea'))};
  await assertFails(run(other)(ea,2));
  await assertFails(api.updateDoc(loan(staff,'ea'),{quantity:2,lastPartialReturnId:'missing'}));
  await assertFails(api.updateDoc(equipment(staff,'ea'),{loaned:2,lastLoanId:'ea'}));
  await run(staff)(ea,2);
  const remainder={id:'ea',...await read(loan(staff,'ea'))};
  assert.equal(remainder.quantity,2);assert.equal(remainder.status,'active');
  const history=await read(loan(staff,remainder.lastPartialReturnId));
  assert.equal(history.quantity,2);assert.equal(history.status,'returned');
  assert.equal(history.partialReturnOf,'ea');assert.equal(history.ownerUid,ADMIN);
  assert.equal(history.loanDate,ea.loanDate);assert(history.returnedAt);
  assert.equal((await read(equipment(staff,'ea'))).loaned,2);
  await assert.rejects(run(staff)(ea,2),/다시 확인/);
  const simultaneous=await Promise.allSettled([run(staff)(remainder,1),run(admin)(remainder,1)]);
  assert.equal(simultaneous.filter(result=>result.status==='fulfilled').length,1);
  const conflict=simultaneous.find(result=>result.status==="rejected").reason;
  assert(conflict.code==="permission-denied"||/다시 확인/.test(conflict.message));
  assert.equal((await read(loan(staff,'ea'))).quantity,1);
  await run(staff)({id:'ea',...await read(loan(staff,'ea'))},1);
  assert.equal((await read(loan(staff,'ea'))).status,'returned');
  assert.equal((await read(equipment(staff,'ea'))).loaned,0);
  const box={id:'box',...await read(loan(admin,'box'))};
  await assert.rejects(run(admin)(box,3),/고장 신고/);
  await run(admin)(box,2);
  const boxRemainder={id:'box',...await read(loan(admin,'box'))};
  assert.equal(boxRemainder.damageEa,5);assert.equal(boxRemainder.lastDamageId,'reported');
  assert.equal((await read(loan(admin,boxRemainder.lastPartialReturnId))).unitsPerBox,4);
  assert.equal((await read(equipment(admin,'box'))).loaned,2);
  await run(admin)(boxRemainder);
  const returnedBox=await read(equipment(admin,'box'));
  assert.equal(returnedBox.loaned,0);assert.equal(returnedBox.brokenEa,5);
  console.log('PASS partial returns: team permissions, atomic stock and history, stale quantities, legacy EA, BOX and damage, final full return');
 }finally{await env.cleanup()}
})().catch(e=>{console.error(e);process.exit(1)});
