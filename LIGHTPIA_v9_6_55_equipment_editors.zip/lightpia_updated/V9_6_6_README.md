# V9.6.6 예약 내역 관리자 삭제

관리자 전용 예약 삭제 버튼, 확인창, Firestore 관리자 삭제 규칙 추가.

**중요:** Firebase Console > Firestore Database > Rules 에서 `www/firestore.rules`의 규칙을 반영하고 게시해야 삭제가 작동합니다. 기존 규칙을 사용자 지정한 경우 전체 덮어쓰기 대신 `/company/main/reservations/{reservationId}` 의 `allow delete: if admin();`만 반영하세요.

실제 대여/출고 기록은 삭제하지 않습니다.
