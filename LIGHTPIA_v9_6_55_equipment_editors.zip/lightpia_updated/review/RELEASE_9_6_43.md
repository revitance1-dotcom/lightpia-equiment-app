Fix JSON backup inspection rejecting valid total-zero (untracked) equipment whenever loaned or repairing is positive. Apply the existing app inventory policy: non-negative integer counters are still required, but total-zero equipment has no tracked upper bound. Tracked overflow, negative/fractional/missing counters and duplicate IDs remain rejected.

Show an explicit successful no-op when all equipment IDs already exist and there is nothing new to restore. Retain the existing restore scope: current records are never overwritten; only absent idle equipment can be created; loan/repair history and missing equipment with active counters remain excluded.

backup-ui.cjs uses actual exportJSON -> importJSON with 70 existing items, including a total-zero active C-stand; checks error/no-op behavior, invalid input rejection, idle untracked restore, preservation of existing and active records, creation race protection and admin-only access at 320/393/768px.
