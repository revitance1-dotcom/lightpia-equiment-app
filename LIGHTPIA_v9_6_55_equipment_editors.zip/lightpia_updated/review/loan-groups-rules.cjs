const fs=require('fs'),assert=require('assert');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing'),api=require('firebase/firestore');
(async()=>{
 const {submitBulkLoans}=await import('../www/bulk-loan-model.js'),{loanMetadata,groupLoans}=await import('../www/loan-groups.js'),{maintenanceReturnFields}=await import('../www/maintenance-model.js');
 const {patchLoanGroupsRules}=await import('../push_sender/loan-groups-rules.mjs');
 const source=fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8');assert.equal(patchLoanGroupsRules(source),source);
 const ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2',env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:source}});
 try{
 await env.clearFirestore();await env.withSecurityRulesDisabled(async c=>{
  const db=c.firestore();for(const [id,team]of [['staff','A'],['other','B']])await api.setDoc(api.doc(db,'members',id),{active:true,role:'team',teamId:team,teamName:team,displayName:id});
  for(const team of ['A','B'])await api.setDoc(api.doc(db,'teams',team),{name:team,active:true,projectId:'P'});
  await api.setDoc(api.doc(db,'projects','P'),{name:'작품',active:true});await api.setDoc(api.doc(db,'company/main/equipment','e'),{name:'오비터',total:100,loaned:0,repairing:0});
 });
 const a=env.authenticatedContext(ADMIN).firestore(),staff=env.authenticatedContext('staff').firestore(),other=env.authenticatedContext('other').firestore(),guest=env.unauthenticatedContext().firestore();
 const eq=db=>api.doc(db,'company/main/equipment','e'),loan=(db,id)=>api.doc(db,'company/main/loans',id);
 const payload=(uid,extra={})=>({team:uid===ADMIN?'관리자':'A',teamId:uid===ADMIN?'admin':'A',ownerUid:uid,person:uid===ADMIN?'관리자':'staff',loanDate:'2026-10-28',dueDate:'2026-10-31',note:'비고 유지',...extra});
 const create=(db,id,p)=>submitBulkLoans(api,db,[{equipmentId:'e',quantity:2,loanId:id}],p);
 await assertSucceeds(create(staff,'staff-set',payload('staff',loanMetadata({equipmentGroup:'세트장비'}))));
 await assertSucceeds(create(a,'external',payload(ADMIN,loanMetadata({rentalType:'external',externalTeam:'언내추럴 외부팀',externalPerson:'김광민 기사님'},true))));
 await assertSucceeds(create(a,'person-only',payload(ADMIN,loanMetadata({rentalType:'external',externalPerson:'담당자만'},true))));
 await assertSucceeds(create(a,'proxy',payload(ADMIN,{teamId:'A',team:'A',projectId:'P',projectName:'작품',rentalType:'internal',equipmentGroup:'세트장비'})));
 await assert.rejects(create(a,'proxy-fake',payload(ADMIN,{teamId:'missing',team:'없는팀',projectId:'P'})));
 await assert.rejects(create(a,'proxy-name',payload(ADMIN,{teamId:'A',team:'다른이름',projectId:'P'})));
 await assert.rejects(create(staff,'fake-project-name',payload('staff',{projectId:'P',projectName:'가짜 작품'})));
 const before=(await api.getDoc(eq(a))).data().loaned;
 for(const [id,p]of [['staff-external',payload('staff',{rentalType:'external',equipmentGroup:'추가장비',externalTeam:'위조'})],['staff-spoof',payload('staff',{rentalType:'internal',externalTeam:'위조'})],['wrong-team',payload('staff',{teamId:'B',equipmentGroup:'상주장비'})],['bad-group',payload('staff',{equipmentGroup:'임의 구분'})]])await assert.rejects(create(staff,id,p));
 await assert.rejects(create(a,'blank-external',payload(ADMIN,{rentalType:'external',equipmentGroup:'추가장비'})));assert.equal((await api.getDoc(eq(a))).data().loaned,before);
 await assertFails(api.getDoc(loan(guest,'external')));await assertFails(api.updateDoc(loan(staff,'external'),{equipmentGroup:'상주장비'}));await assertFails(api.updateDoc(loan(staff,'staff-set'),{equipmentGroup:'상주장비'}));
 await assertSucceeds(api.updateDoc(loan(a,'staff-set'),{equipmentGroup:'상주장비',updatedAt:api.serverTimestamp()}));
 await assertFails(api.updateDoc(loan(a,'staff-set'),{rentalType:'external',externalTeam:'바꾸면 안됨'}));
 await assertFails(api.updateDoc(loan(a,'external'),{quantity:99,externalTeam:'바뀐 팀'}));await assertFails(api.updateDoc(loan(a,'external'),{ownerUid:'staff',equipmentGroup:'세트장비'}));
 await assertSucceeds(api.updateDoc(loan(a,'external'),{externalTeam:'다른 외부팀',updatedAt:api.serverTimestamp()}));
 assert.equal((await api.getDoc(eq(a))).data().loaned,before);assert.equal((await api.getDoc(loan(a,'external'))).data().note,'비고 유지');
 await assert.rejects(create(a,'external',payload(ADMIN,loanMetadata({rentalType:'external',externalTeam:'다른 사람'},true))));
 const returnOne=(db,id)=>api.runTransaction(db,async tx=>{const lr=loan(db,id),ls=await tx.get(lr),er=eq(db),es=await tx.get(er);tx.update(er,maintenanceReturnFields(es.data(),ls.data(),id));tx.update(lr,{status:'returned',returnedAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});});
 await assert.rejects(returnOne(other,'proxy'));await assertSucceeds(returnOne(staff,'proxy'));
 await assert.rejects(returnOne(staff,'external'));await assert.rejects(returnOne(other,'external'));await assertSucceeds(returnOne(a,'external'));assert.equal((await api.getDoc(eq(a))).data().loaned,before-4);await assert.rejects(returnOne(a,'external'));
 await assertSucceeds(create(staff,'legacy',payload('staff')));await assertSucceeds(api.updateDoc(loan(a,'legacy'),loanMetadata({equipmentGroup:'세트장비'},true)));
 const rows=(await api.getDocs(api.collection(a,'company/main/loans'))).docs.map(d=>({...d.data(),id:d.id})),groups=groupLoans(rows,ADMIN);
 assert.equal(groups.find(g=>g.id==='admin').sections[0].label,'외부팀');assert(groups.find(g=>g.id==='team:A').rows.some(l=>l.id==='proxy'));assert(groups.find(g=>g.id==='team:A').sections.some(s=>s.label==='세트장비'));
 console.log('PASS rental groups: employee classifications, admin-only external teams/person-only, legacy compatibility, metadata-only edits preserve stock/history, owner/team immutable, external returns admin-only, retry mismatch rejected');
 }finally{await env.cleanup();}
})().catch(e=>{console.error(e);process.exit(1)});
