export function patchPartialReturnRules(source){
 if(source.includes('// LNS_PARTIAL_RETURNS_V1'))return source;
 const equipment='match /company/main/equipment/{equipmentId} {';
 const loans='match /company/main/loans/{loanId} {';
 if(source.split(equipment).length!==2||source.split(loans).length!==2)throw Error('Unexpected equipment or loan rules structure.');
 return source.replace(equipment,`// LNS_PARTIAL_RETURNS_V1
  function lnsPartialStockUpdate(equipmentId, returnId) {
   let returned = getAfter(loanPath(returnId)).data;
   return returned.get('partialReturnOf','') != ''
    && returned.equipmentId == equipmentId
    && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['loaned','lastLoanId','brokenStock'])
    && request.resource.data.get('brokenStock',0) == resource.data.get('brokenStock',0)
    && request.resource.data.loaned == resource.data.loaned - returned.quantity
    && validQty(request.resource.data);
  }
  function lnsPartialRemainder(sourceId, before, remaining, returnId) {
   let returnRef = loanPath(returnId);
   let returned = getAfter(returnRef).data;
   let stockRef = eqPath(before.equipmentId);
   return loanOwner(before) && before.status == 'active'
    && remaining.diff(before).affectedKeys().hasOnly(['quantity','lastPartialReturnId','updatedAt'])
    && remaining.updatedAt == request.time
    && remaining.quantity is int && remaining.quantity > 0
    && lnsDamageTotal(before) <= remaining.quantity * lnsPack(before)
    && !exists(returnRef) && returned.get('partialReturnOf','') == sourceId
    && returned.quantity == before.quantity - remaining.quantity
    && getAfter(stockRef).data.lastLoanId == returnId
    && getAfter(stockRef).data.loaned == get(stockRef).data.loaned - returned.quantity;
  }
  function lnsPartialHistory(returnId, sourceId, returned) {
   let sourceRef = loanPath(sourceId);
   let before = get(sourceRef).data;
   let remaining = getAfter(sourceRef).data;
   return returned.status == 'returned' && returned.quantity is int && returned.quantity > 0
    && remaining.lastPartialReturnId == returnId && before.get('lastPartialReturnId','') != returnId
    && remaining.quantity == before.quantity - returned.quantity
    && returned.diff(before).affectedKeys().hasOnly(['quantity','status','partialReturnOf','returnedAt','createdAt','updatedAt','damageQuantity','damageEa','lastDamageId','lastPartialReturnId'])
    && !returned.keys().hasAny(['damageQuantity','damageEa','lastDamageId','lastPartialReturnId'])
    && returned.createdAt == request.time && returned.returnedAt == request.time && returned.updatedAt == request.time;
  }
  ${equipment}
 allow update: if request.resource.data.loaned < resource.data.loaned
   && request.resource.data.get('lastLoanId','') is string
   && request.resource.data.get('lastLoanId','') != ''
   && !exists(loanPath(request.resource.data.lastLoanId))
   && lnsPartialStockUpdate(equipmentId,request.resource.data.lastLoanId);
`).replace(loans,`${loans}
   allow create: if request.resource.data.get('partialReturnOf','') is string
    && request.resource.data.get('partialReturnOf','') != ''
    && lnsPartialHistory(loanId,request.resource.data.partialReturnOf,request.resource.data);
   allow update: if request.resource.data.quantity < resource.data.quantity
    && request.resource.data.get('lastPartialReturnId','') is string
    && request.resource.data.get('lastPartialReturnId','') != ''
    && lnsPartialRemainder(loanId,resource.data,request.resource.data,request.resource.data.lastPartialReturnId);
`);
}
