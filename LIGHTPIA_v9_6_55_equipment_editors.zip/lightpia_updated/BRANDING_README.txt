브랜딩 적용판 v4. 팀별 공용 Firebase 권한/인증 기능은 아직 구현되지 않았습니다.
GitHub 저장소 루트에 ZIP 업로드 후 .github/workflows/build-apk.yml 을 동봉 파일 내용으로 교체하세요.
기존 Firebase 개인용 데이터 구조와 규칙은 유지됩니다.
