import {createHash} from 'node:crypto';
export const ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2';
export const digest=x=>createHash('sha256').update(x).digest('hex');
export function koreaClock(now){const local=new Date(now+9*3600000);return {day:local.toISOString().slice(0,10),hour:local.getUTCHours(),tomorrow:new Date(now+9*3600000+86400000).toISOString().slice(0,10)};}
export function eventsFor(source,rows,previous,activatedAt,now){
 const out=[],state={},clock=koreaClock(now);const add=(id,kind,title,body,rest={})=>out.push({id:digest(source+':'+id),kind,title,body:body.slice(0,2000),tab:source==='loans'?'loans':source==='reservations'?'reservations':'settings',...rest});
 const groups=new Map();
 for(const row of [...rows].sort((a,b)=>Number(a.createdAt?.toMillis?.()||0)-Number(b.createdAt?.toMillis?.()||0)||a.id.localeCompare(b.id))){
  const {id,...d}=row,created=Number(d.createdAt?.toMillis?.()||0),updated=Number(d.updatedAt?.toMillis?.()||created),old=previous[id];state[id]={status:d.status||'',updated};
  const recent=created>=activatedAt,newRow=!old&&recent;
  const changed=old?old.status!==d.status:recent;
  const label=d.externalTeam||[d.projectName,d.teamName||d.team||d.requestedTeam].filter(Boolean).join(' · ')||'직원',target={ownerUid:d.ownerUid||'',teamId:d.teamId||''};
  if(source==='joinRequests'){
   if(newRow||d.status==='pending')add(id+':join','join','새로운 가입 신청',`${d.name||d.username||'직원'} · ${label}`,{adminOnly:true});
   if(changed&&d.status==='approved'&&updated>=activatedAt)add(id+':approved','signup','가입이 승인됐습니다','관리자 승인이 완료됐습니다. 로그인해서 장비관리 앱을 이용해 주세요.',{ownerUid:id});
  }
  if(source==='reservations'){
   if(newRow)add(id+':new','reservation','새 장비 예약 신청',`${label} · ${d.person||''} · ${d.startDate||''} ~ ${d.endDate||''}`,{adminOnly:true,reservationId:id});
   if(changed&&['approved','rejected','cancelled','revoked'].includes(d.status)&&updated>=activatedAt){const status={approved:'승인',rejected:'거절',cancelled:'신청 취소',revoked:'승인 취소'}[d.status];add(id+':'+d.status+':'+updated,'reservation','예약 '+status,`${label} · ${d.startDate||''} ~ ${d.endDate||''}` ,{...target,reservationId:id,includeAdmin:d.status==='cancelled'});}
   if(clock.hour>=9&&d.status==='approved'&&d.startDate===clock.tomorrow)add(id+':departure:'+clock.day,'departure','내일 예약 장비 출고 예정',`${label} · ${d.startDate} · ${(d.items||[]).length}종`,{...target,reservationId:id});
  }
  if(source==='loans'){
   // Operations in one transaction share a timestamp. Group by timestamp + owner + team.
   const returned=Number(d.returnedAt?.toMillis?.()||0),action=changed&&d.status==='returned'&&returned>=activatedAt?'반납':newRow?'대여':'';
   if(action){const stamp=action==='반납'?returned:created,op=action==='대여'?id.match(/^op_([A-Za-z0-9]+)_/):null;
    const party=[action,d.teamId||'',d.ownerUid||'',d.person||'',d.rentalType||'',d.externalTeam||'',d.equipmentGroup||''].join(':');
    let key=op?party+':op:'+op[1]:party+':'+stamp;
    if(!op){const prior=[...groups.entries()].find(([k,g])=>g.party===party&&!g.op&&Math.abs(stamp-g.last)<=60000);if(prior)key=prior[0];}
    const g=groups.get(key)||{action,label,items:[],party,op:!!op,last:stamp};g.last=Math.max(g.last,stamp);g.items.push({...d,id});groups.set(key,g);}
   if(clock.hour>=9&&d.status!=='returned'&&d.dueDate&&d.dueDate<=clock.day){const late=d.dueDate<clock.day,key=[d.teamId||'',d.ownerUid||'',d.dueDate,late].join(':');const g=groups.get('due:'+key)||{due:true,label,late,...target,date:d.dueDate,items:[]};g.items.push(d);groups.set('due:'+key,g);}
  }
  if(source==='tests'&&newRow)add(id,'test','Lightpia · 테스트 알림','이 기기의 알림 수신이 정상적으로 작동합니다.',{ownerUid:d.ownerUid});
  if(source==='reservations'&&clock.hour>=9&&d.status==='approved'&&d.startDate<clock.day&&(d.items||[]).some(i=>Number(d.fulfilledItems?.[i.id]||0)<Number(i.qty)))add(id+':unshipped:'+clock.day,'departure','미출고 예약 확인',`${label} · ${d.startDate} · 출고 처리를 확인해 주세요.`,{adminOnly:true,reservationId:id});
  if(source==='announcements'&&newRow)add(id,'notice',d.title,d.body,{all:!d.teamId,teamId:d.teamId||''});
 }
 for(const [key,g] of groups){if(g.due)add(key+':'+clock.day,'due',g.late?'반납 기한이 지났습니다':'오늘 장비 반납 예정',`${g.label} · ${g.date} · ${g.items.length}건`,{ownerUid:g.ownerUid,teamId:g.teamId,includeAdmin:g.late});else add(key,'loan','장비 '+g.action+' 알림',`${g.label} · ${g.items.length}건 · ${g.items.slice(0,3).map(d=>(d.equipmentName||'장비')+' '+Number(d.quantity||0)+(d.unit==='BOX'?'box':'ea')).join(', ')+(g.items.length>3?' 외 '+(g.items.length-3)+'종':'')}`,{adminOnly:true});}
 return {events:out,state};
}
export function recipients(event,members){const ids=new Set();if(event.adminOnly||event.includeAdmin)ids.add(ADMIN);if(!event.adminOnly){if(event.ownerUid)ids.add(event.ownerUid);for(const m of members)if(m.active===true&&(event.all||(event.teamId&&m.teamId===event.teamId)))ids.add(m.id);}return [...ids];}
export function shouldPush(p,e,uid){return p?.enabled===true&&p.kinds?.[e.kind]!==false&&(!(['reservation','due','departure'].includes(e.kind)&&e.teamId&&e.ownerUid!==uid&&uid!==ADMIN)||p.scope!=='mine');}
