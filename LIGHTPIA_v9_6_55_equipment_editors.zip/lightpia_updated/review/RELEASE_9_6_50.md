# 9.6.50 — Equipment display and administrator ordering

- Natural name order, numeric descending within model series, across inventory, selections, loans, reservation items and archives.
- Administrator long press + drag (touch/mouse), Alt+arrow keyboard alternative, shared Firestore display settings.
- Category order shared across stock overview, inventory, loans and reservation selectors; absent/new categories reconcile safely.
- Home cards, home actions, record actions and loan actions persist independent order.
- Default loan-history filter is all records.
- Presentation-only preference permissions: approved readers, administrator writes, bounded fields and no inventory authority.
- New UI tests use real Chromium CDP touch events, test no accidental click, staff restriction, selection retention and shared state.
