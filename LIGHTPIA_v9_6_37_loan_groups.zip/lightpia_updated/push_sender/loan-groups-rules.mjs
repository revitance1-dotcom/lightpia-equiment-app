import fs from 'node:fs';
export function patchLoanGroupsRules(source){
 if(source.includes('LNS_LOAN_GROUPS_V1'))return source;
 const anchor='match /company/main/loans/{loanId}',start=source.indexOf(anchor),end=source.indexOf('match /company/main/reservations/',start);
 if(start<0||end<0||source.indexOf(anchor,start+anchor.length)>=0)throw Error('Unexpected loan rule layout');
 let block=source.slice(start,end);
 const old="'teamId','projectId'])";
 if(!block.includes(old)||!block.includes('   allow delete:'))throw Error('Unexpected loan create rules');
 block=block.replace(old,"'teamId','projectId','rentalType','equipmentGroup','externalTeam','externalPerson']) && lnsLoanClassification(request.resource.data)");
 block=block.replace('   allow delete:',`   allow update: if admin() && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['rentalType','equipmentGroup','externalTeam','externalPerson','updatedAt']) && lnsLoanClassification(request.resource.data);
   allow delete:`);
 const helper=fs.readFileSync(new URL('./loan-groups.rules',import.meta.url),'utf8');
 return source.slice(0,start)+helper+'  '+block+source.slice(end);
}
