const assert=require('assert'),admin=require('firebase-admin');
(async()=>{
 if(!process.env.FIRESTORE_EMULATOR_HOST)throw Error('Emulator required');
 const app=admin.initializeApp({projectId:'demo-lightpia'},'tag-correction-test'),db=app.firestore();
 const {apply18kTagCorrection}=await import('../push_sender/tag-correction-model.mjs');
 const stamp=()=>admin.firestore.FieldValue.serverTimestamp(),col=db.collection('company/main/equipment'),marker=db.doc('appMigrations/equipment-tags-v9630');
 try{
  await db.recursiveDelete(col);await marker.delete();
  await col.doc('com').set({name:'18K COM',searchTags:'#old',total:5,loaned:2,repairing:1});
  await col.doc('par').set({name:'18K PAR',searchTags:'#sun #컴 #파',total:7,loaned:1,repairing:0});
  await col.doc('other').set({name:'M90',searchTags:'#sun #컴',total:3});
  await apply18kTagCorrection(db,stamp);
  assert.equal((await col.doc('com').get()).data().searchTags,'#old #sun #컴');assert.equal((await col.doc('par').get()).data().searchTags,'#파');
  assert.equal((await col.doc('other').get()).data().searchTags,'#sun #컴');assert.equal((await col.doc('com').get()).data().loaned,2);
  const audit=(await marker.get()).data();assert.equal(audit.records.length,2);assert(audit.records.some(r=>r.equipmentId==='par'&&r.before==='#sun #컴 #파'));
  await col.doc('par').update({searchTags:'#new'});await apply18kTagCorrection(db,stamp);assert.equal((await col.doc('par').get()).data().searchTags,'#new');
  await marker.delete();await col.doc('duplicate').set({name:'18k par',searchTags:'#sun'});await assert.rejects(apply18kTagCorrection(db,stamp));assert.equal((await col.doc('par').get()).data().searchTags,'#new');assert(!(await marker.get()).exists);
  console.log('PASS real Admin SDK tag correction: boolean snapshots, isolated records, preserved other tags/stock, atomic server audit, one-time retry, ambiguity rejected');
 }finally{await app.delete();}
})().catch(e=>{console.error(e);process.exit(1)});
