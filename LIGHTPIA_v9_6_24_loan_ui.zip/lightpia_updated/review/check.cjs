const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('www/app.js','utf8');
const start=source.indexOf('async function approveUser(uid)'),end=source.indexOf('\n}',start)+2;
async function check(id,teams,expected){
 const writes=[];let committed=false;const alerts=[];
 const ctx={isAdmin:()=>true,$:()=>({value:id}),teamList:teams,joinRequests:[{id:'u',name:'직원'}],db:{},doc:(_,c,u)=>c+'/'+u,serverTimestamp:()=>0,alert:x=>alerts.push(x),writeBatch:()=>({set:(...x)=>writes.push(x),update:(...x)=>writes.push(x),commit:async()=>{committed=true}})};
 vm.createContext(ctx);vm.runInContext(source.slice(start,end),ctx);await ctx.approveUser('u');
 assert.equal(committed,expected);if(expected){assert.equal(writes.length,2);assert.equal(writes[0][1].teamName,id?'A팀':'대기 직원');if(!id)assert(!('teamId' in writes[0][1]));}
}
(async()=>{await check('',[],true);await check('a',[{id:'a',name:'A팀',active:true}],true);await check('a',[{id:'a',name:'A팀',active:false}],false);
 const match=source.match(/\$\("cartDate"\)\.onchange=\(\)=>\{([^\n]+)\};/);assert(match);
 for(const due of ['2026-10-01','2026-11-01','']){const els={cartDate:{value:'2026-10-27'},cartDue:{value:due,focus(){}}};vm.runInNewContext('(()=>{'+match[1]+'})()',{$:id=>els[id]});assert.equal(els.cartDue.min,'2026-10-27');assert.equal(els.cartDue.value,due==='2026-11-01'?due:'2026-10-27');}
 assert.equal(fs.readFileSync('firestore.rules','utf8'),fs.readFileSync('www/firestore.rules','utf8'));
 console.log('PASS: waiting approval, team approval, inactive-team rejection, 3 date cases, rules copies');
})().catch(e=>{console.error(e);process.exit(1)});

