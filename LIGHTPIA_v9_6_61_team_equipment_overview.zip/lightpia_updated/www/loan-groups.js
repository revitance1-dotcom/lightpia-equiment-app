export const LOAN_GROUPS=['상주장비','세트장비','추가장비'];
// Keep different equipment IDs and BOX configurations separate when combining records.
export function summarizeHeldEquipment(rows=[]){
 const result=new Map();
 for(const loan of rows){
  const quantity=Number(loan.quantity||0);if(loan.status==='returned'||!Number.isFinite(quantity)||quantity<=0)continue;
  const unit=loan.unit==='BOX'?'BOX':'EA',unitsPerBox=unit==='BOX'?Number(loan.unitsPerBox||1):1;
  const id=JSON.stringify([loan.equipmentId||loan.equipmentName,unit,unitsPerBox]);
  if(!result.has(id))result.set(id,{equipmentId:loan.equipmentId,equipmentName:loan.equipmentName,unit,unitsPerBox,quantity:0,groups:{},rows:[]});
  const row=result.get(id),group=loanGroupName(loan);row.quantity+=quantity;row.groups[group]=(row.groups[group]||0)+quantity;row.rows.push(loan);
 }
 return [...result.values()];
}
export function teamHeldLoans(rows=[],id='',adminUid=''){
 if(!id)return [];
 return rows.filter(l=>l.status!=='returned'&&l.rentalType!=='external'&&(l.teamId===id||(id==='admin'&&!l.teamId&&(l.team==='관리자'||(adminUid&&l.ownerUid===adminUid)))));
}
const text=v=>String(v??'').trim();
const key=v=>text(v).normalize('NFKC').toLocaleLowerCase();
export function loanMetadata(values,admin=false){
 const rentalType=values.rentalType||'internal',equipmentGroup=values.equipmentGroup||'추가장비';
 if(!LOAN_GROUPS.includes(equipmentGroup))throw Error('장비 구분을 선택해 주세요.');
 if(!['internal','external'].includes(rentalType)||(!admin&&rentalType==='external'))throw Error('외부팀 대여는 관리자만 등록할 수 있습니다.');
 const externalTeam=text(values.externalTeam),externalPerson=text(values.externalPerson);
 if(externalTeam.length>100||externalPerson.length>80)throw Error('외부팀명은 100자, 담당자는 80자 이내로 입력해 주세요.');
 if(rentalType==='external'&&!externalTeam&&!externalPerson)throw Error('외부팀명 또는 담당자 이름을 입력해 주세요.');
 return {rentalType,equipmentGroup,externalTeam:rentalType==='external'?externalTeam:'',externalPerson:rentalType==='external'?externalPerson:''};
}
export function loanParty(l){return l.rentalType==='external'?[l.externalTeam,l.externalPerson].filter(Boolean).join(' · '):l.person||'';}
export function loanGroupName(l){return LOAN_GROUPS.includes(l.equipmentGroup)?l.equipmentGroup:'미분류';}
export function loanSearchText(l,teams=[],projects=[]){return [l.equipmentName,loanTeamLabel(l,teams,projects),l.projectName,l.team,l.person,l.note,l.externalTeam,l.externalPerson,loanGroupName(l),l.rentalType==='external'?'외부팀':''].filter(Boolean).join(' ').toLocaleLowerCase();}
export function groupLoans(rows,adminUid,teams=[],projects=[]){
 const groups=new Map();
 for(const l of rows){
  const admin=l.teamId==='admin'||(!l.teamId&&(l.ownerUid===adminUid||l.team==='관리자'));
  const id=admin?'admin':l.teamId?'team:'+l.teamId:'legacy:'+text(l.team||'팀 미입력');
  if(!groups.has(id))groups.set(id,{id,label:admin?'관리자':loanTeamLabel(l,teams,projects),rows:[],sections:new Map()});
  const g=groups.get(id);g.rows.push(l);
  const external=l.rentalType==='external',label=external?'외부팀':loanGroupName(l);
  if(!g.sections.has(label))g.sections.set(label,{id:id+'/'+label,label,rows:[],parties:new Map()});
  const section=g.sections.get(label);section.rows.push(l);
  if(external){
   const partyId=l.externalTeam?'team:'+key(l.externalTeam):'person:'+key(l.externalPerson);
   if(!section.parties.has(partyId))section.parties.set(partyId,{id:section.id+'/'+partyId,label:l.externalTeam||l.externalPerson||'대여처 미입력',rows:[]});
   section.parties.get(partyId).rows.push(l);
  }
 }
 const order=[...LOAN_GROUPS,'외부팀','미분류'];
 return [...groups.values()].sort((a,b)=>a.id===b.id?0:a.id==='admin'?-1:b.id==='admin'?1:a.label.localeCompare(b.label,'ko')).map(g=>({...g,sections:[...g.sections.values()].sort((a,b)=>order.indexOf(a.label)-order.indexOf(b.label)).map(s=>({...s,parties:[...s.parties.values()]}))}));
}
export function loanTeamLabel(l,teams=[],projects=[]){
 if(l.teamId==='admin'||(!l.teamId&&l.team==='관리자'))return '관리자';
 const team=teams.find(t=>t.id===l.teamId),projectId=l.projectId||team?.projectId;
 const project=text(l.projectName)||text(projects.find(p=>p.id===projectId)?.name),name=text(l.team)||text(team?.name)||'팀 미입력';
 return project&&name!==project&&!name.startsWith(project+' ')&&!name.startsWith(project+' ·')?project+' · '+name:name;
}
export function loanDestination({admin,mode='internal',targetTeamId,currentTeamId,teamName,teams=[],projects=[]}){
 if(!admin&&mode!=='internal')throw Error('다른 팀 대여는 관리자만 등록할 수 있습니다.');
 if(admin&&mode!=='team')return {teamId:'admin',team:'관리자'};
 const id=admin?targetTeamId:currentTeamId,team=teams.find(t=>t.id===id),project=projects.find(p=>p.id===team?.projectId);
 if(!id||!team||team.active===false||!project||project.active===false)throw Error('진행 중인 작품의 활성 팀을 선택해 주세요.');
 return {teamId:id,team:admin?(team.name||teamName):teamName,projectId:project.id,projectName:project.name||''};
}
