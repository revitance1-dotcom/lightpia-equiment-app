import {validateCrewPost,applyForCrew} from './crew-model.js';
export function createCrewBoard(ui){
 const {api,esc}=ui;let posts=[],mine=[],filter='open',detailUnsub=null;
 const col=name=>api.collection(ui.db(),'company/main/'+name),ref=(name,id)=>api.doc(ui.db(),'company/main/'+name,id);
 const own=p=>ui.isAdmin()||p.authorUid===ui.uid(),labels={pending:'지원 완료',accepted:'선택됨',rejected:'미선택',withdrawn:'지원 취소'};
 function render(){
  const target=document.getElementById('crewList');if(!target)return;
  const q=(document.getElementById('crewSearch')?.value||'').toLocaleLowerCase().trim();
  const list=posts.filter(p=>p.status!=='deleted'&&(filter==='all'||filter==='mine'&&p.authorUid===ui.uid()||filter==='applied'&&mine.some(a=>a.postId===p.id)||filter==='open'&&p.status==='open'&&p.endDate>=ui.today())&&[p.projectName,p.rank,p.location,p.authorName,p.pay].join(' ').toLocaleLowerCase().includes(q));
  target.innerHTML=list.length?list.map(p=>{const application=mine.find(a=>a.postId===p.id);return `<button type="button" class="crew-card" data-crew-open="${esc(p.id)}"><div class="row"><span class="pill ${p.status==='open'&&p.endDate>=ui.today()?'green':'amber'}">${p.status==='open'&&p.endDate>=ui.today()?'모집 중':'모집 마감'}</span>${application?`<span class="pill">${labels[application.status]}</span>`:''}</div><h3>${esc(p.projectName)}</h3><div class="crew-job-meta">${esc(p.startDate)} ~ ${esc(p.endDate)}<br><strong>${esc(p.rank)}</strong> · ${p.slots}명 · ${esc(p.pay)}<br>${esc(p.location||'장소 협의')}</div><p class="meta">작성자 ${esc(p.authorName)}${p.authorTeam?' · '+esc(p.authorTeam):''}</p></button>`;}).join(''):'<div class="empty">조건에 맞는 구인글이 없습니다.<br>지원 인원이 필요할 때 구인글을 올려 보세요.</div>';
 }
 function stopDetail(){detailUnsub?.();detailUnsub=null;}
 new MutationObserver(()=>{if(!document.querySelector('[data-crew-detail]'))stopDetail();}).observe(document.getElementById('modalRoot'),{childList:true,subtree:true});
 function openForm(id=''){
  const old=posts.find(p=>p.id===id)||{};if(id&&!own(old))return;
  const f=(key,label,type='text',required=true)=>`<div class="field"><label for="crew-${key}">${label}${required?' *':''}</label><input id="crew-${key}" type="${type}" value="${esc(old[key]??(key==='slots'?1:['startDate','endDate'].includes(key)?ui.today():''))}" ${required?'required':''} ${key==='slots'?'min="1" max="99"':''} maxlength="${key==='location'?200:120}"></div>`;
  ui.modal(id?'구인글 수정':'지원 인원 구하기',`<form id="crewPostForm">${f('projectName','작품명')}<div class="formgrid">${f('startDate','시작 날짜','date')}${f('endDate','종료 날짜','date')}${f('pay','페이 · 예: 일당 20만원 / 협의')}${f('rank','모집 직급 · 예: 조명 막내')}${f('slots','모집 인원','number')}${f('contact','연락처')}</div>${f('location','촬영 장소','text',false)}<div class="field"><label for="crew-details">상세 내용</label><textarea id="crew-details" rows="4" maxlength="4000" placeholder="집합 시간, 업무, 교통·식사 등">${esc(old.details||'')}</textarea></div><p class="meta">작성자 ${esc(ui.name())} · 회사 계정으로 승인된 팀원들에게 공개됩니다.</p><button type="submit">${id?'수정 저장':'구인글 등록'}</button></form>`);
  const form=document.getElementById('crewPostForm');
  form.onsubmit=async event=>{event.preventDefault();if(form.dataset.saving)return;const button=form.querySelector('button'),data={};for(const key of ['projectName','startDate','endDate','pay','rank','contact','location','details'])data[key]=document.getElementById('crew-'+key).value.trim();data.slots=Number(document.getElementById('crew-slots').value);
   try{validateCrewPost(data);if(!id&&data.startDate<ui.today())throw Error('오늘 이후 날짜를 선택해 주세요.');form.dataset.saving='true';button.disabled=true;
    if(id)await api.updateDoc(ref('crewPosts',id),{...data,updatedAt:api.serverTimestamp()});else await api.addDoc(col('crewPosts'),{...data,authorUid:ui.uid(),authorName:ui.name(),authorTeam:ui.team(),status:'open',createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});
    if(form.isConnected)ui.closeModal();
   }catch(err){alert('구인글 저장 실패: '+err.message);}finally{delete form.dataset.saving;button.disabled=false;}
  };
 }
 function openPost(id){
  const p=posts.find(x=>x.id===id);if(!p||p.status==='deleted')return;stopDetail();
  const manager=own(p),application=mine.find(a=>a.postId===id),active=p.status==='open'&&p.endDate>=ui.today();
  ui.modal(esc(p.projectName),`<div data-crew-detail="${esc(id)}"><span class="pill ${active?'green':'amber'}">${active?'모집 중':'모집 마감'}</span><dl class="crew-facts">${[['날짜',p.startDate+' ~ '+p.endDate],['페이',p.pay],['직급',p.rank+' · '+p.slots+'명'],['장소',p.location||'협의'],['연락처',p.contact],['작성자',p.authorName+(p.authorTeam?' · '+p.authorTeam:'')]].map(([k,v])=>`<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl><p class="crew-description">${esc(p.details||'추가 내용이 없습니다.')}</p>${manager?`<div class="row"><button data-crew-edit="${esc(id)}" class="secondary">글 수정</button><button data-crew-status="${p.status==='open'?'closed':'open'}" data-crew-id="${esc(id)}">${p.status==='open'?'모집 마감':'다시 모집'}</button><button class="danger" data-crew-status="deleted" data-crew-id="${esc(id)}">글 삭제</button></div><h3>지원자 확인</h3><p class="meta">선택된 지원자와 연락해 일정·페이를 확정해 주세요.</p><div id="crewApplicants" class="list">지원자를 불러오는 중…</div>`:`${application?`<p class="notice">내 지원 상태: ${labels[application.status]}<br>${esc(application.contact)}</p>`:''}${active&&(!application||['withdrawn','rejected'].includes(application.status))?`<button data-crew-apply="${esc(id)}">지원하기</button>`:''}${application&&['pending','accepted'].includes(application.status)?`<button class="secondary" data-crew-withdraw="${esc(application.id)}">지원 취소</button>`:''}`}</div>`);
  if(manager)detailUnsub=api.onSnapshot(api.query(col('crewApplications'),api.where('postId','==',id)),snap=>{
   const target=document.getElementById('crewApplicants');if(!target||document.querySelector('[data-crew-detail]')?.dataset.crewDetail!==id)return;
   target.innerHTML=snap.docs.length?snap.docs.map(d=>{const a=d.data();return `<div class="crew-applicant"><div class="row"><b>${esc(a.name)}</b><span class="pill">${labels[a.status]}</span></div><p>${esc(a.contact)}</p><p class="meta">${esc(a.memo||'메모 없음')}</p>${p.status==='open'&&['pending','accepted','rejected'].includes(a.status)?`<div class="row"><button data-crew-select="accepted" data-crew-application="${esc(d.id)}">지원자 선택</button><button class="secondary" data-crew-select="rejected" data-crew-application="${esc(d.id)}">미선택</button></div>`:''}</div>`;}).join(''):'<div class="empty">아직 지원자가 없습니다.</div>';
  },()=>{const target=document.getElementById('crewApplicants');if(target)target.textContent='지원자 목록을 불러오지 못했습니다.';});
 }
 function applicationForm(id){
  const p=posts.find(p=>p.id===id);if(!p)return;
  ui.modal('촬영 지원하기',`<form id="crewApplicationForm"><h3>${esc(p.projectName)}</h3><p class="meta">지원자 ${esc(ui.name())}<br>연락처와 메모는 본인·글 작성자·관리자만 볼 수 있습니다.</p><div class="field"><label for="crewApplyContact">연락처 *</label><input id="crewApplyContact" maxlength="80" required type="tel" autocomplete="tel"></div><div class="field"><label for="crewApplyMemo">지원 메모</label><textarea id="crewApplyMemo" rows="3" maxlength="1000" placeholder="가능 일정, 경력 등"></textarea></div><button type="submit">지원 신청</button></form>`);
  const form=document.getElementById('crewApplicationForm');form.onsubmit=async event=>{event.preventDefault();if(form.dataset.saving)return;form.dataset.saving='true';form.querySelector('button').disabled=true;
   try{await applyForCrew(api,ui.db(),id,{name:ui.name(),contact:document.getElementById('crewApplyContact').value,memo:document.getElementById('crewApplyMemo').value},ui.uid());if(form.isConnected)ui.closeModal();alert('지원했습니다. 작성자가 연락처와 메모를 확인할 수 있습니다.');}catch(err){alert('지원 실패: '+err.message);}finally{delete form.dataset.saving;form.querySelector('button').disabled=false;}
  };
 }
 document.getElementById('crewSearch')?.addEventListener('input',render);
 document.getElementById('crewFilter')?.addEventListener('change',event=>{filter=event.target.value;render();});
 document.addEventListener('click',async event=>{
  const b=event.target.closest('button');if(!b)return;
  try{
   if(b.id==='crewCreate')openForm();if(b.dataset.crewOpen)openPost(b.dataset.crewOpen);if(b.dataset.crewEdit)openForm(b.dataset.crewEdit);if(b.dataset.crewApply)applicationForm(b.dataset.crewApply);
   if(b.dataset.crewStatus){const p=posts.find(p=>p.id===b.dataset.crewId);if(!p||!own(p))return;if(!confirm(b.dataset.crewStatus==='deleted'?'이 구인글을 삭제할까요?':'모집 상태를 변경할까요?'))return;b.disabled=true;await api.updateDoc(ref('crewPosts',p.id),{status:b.dataset.crewStatus,updatedAt:api.serverTimestamp()});ui.closeModal();}
   if(b.dataset.crewWithdraw){if(!confirm('지원을 취소할까요?'))return;b.disabled=true;await api.updateDoc(ref('crewApplications',b.dataset.crewWithdraw),{status:'withdrawn',updatedAt:api.serverTimestamp()});ui.closeModal();}
   if(b.dataset.crewSelect){b.disabled=true;await api.updateDoc(ref('crewApplications',b.dataset.crewApplication),{status:b.dataset.crewSelect,updatedAt:api.serverTimestamp()});}
  }catch(err){alert('처리 실패: '+err.message);b.disabled=false;}
 });
 return {render,reset:()=>{posts=[];mine=[];stopDetail();render();},subscribe:()=>[
  api.onSnapshot(api.query(col('crewPosts'),api.orderBy('createdAt','desc')),snap=>{posts=snap.docs.map(d=>({...d.data(),id:d.id}));render();},()=>{document.getElementById('crewList').textContent='구인글을 불러오지 못했습니다. 다시 로그인해 주세요.';}),
  api.onSnapshot(api.query(col('crewApplications'),api.where('applicantUid','==',ui.uid())),snap=>{mine=snap.docs.map(d=>({...d.data(),id:d.id}));render();},()=>{})
 ]};
}
