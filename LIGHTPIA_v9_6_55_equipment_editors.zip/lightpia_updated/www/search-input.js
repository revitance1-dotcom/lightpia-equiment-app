// The editable DOM and IME spans stay browser-owned; only results are rendered.
const composing=new WeakSet();
export const isSearchComposing=input=>!!input&&composing.has(input);
export const searchText=input=>input?.isContentEditable?(input.textContent||""):(input?.value||"");
export function bindSearchInput(input,onSearch){
 if(!input)return;
 let pending;
 const canPreview=()=>input.isContentEditable||!isSearchComposing(input);
 const commit=()=>{
  clearTimeout(pending);pending=undefined;
  if(input.isConnected&&canPreview())onSearch(searchText(input));
 };
 const schedule=()=>{clearTimeout(pending);pending=setTimeout(commit,60);};
 input.addEventListener('compositionstart',()=>{clearTimeout(pending);composing.add(input);});
 // Read the live editable text after each DOM edit, including an uncommitted last syllable.
 input.addEventListener('compositionupdate',()=>{if(input.isContentEditable)schedule();});
 input.addEventListener('compositionend',()=>{
  composing.delete(input);clearTimeout(pending);pending=setTimeout(commit,0);
 });
 input.addEventListener('input',event=>{
  if(event.isComposing||isSearchComposing(input)){if(input.isContentEditable)schedule();return;}
  if(pending){clearTimeout(pending);pending=setTimeout(commit,0);}else commit();
 });
 if(input.isContentEditable)input.addEventListener('keydown',event=>{
  if(event.key==='Enter'&&!event.isComposing&&event.keyCode!==229&&!isSearchComposing(input)){
   event.preventDefault();commit();
  }
 });
 const button=input.closest('.search-field')?.querySelector('[data-search-submit]');
 if(button&&button.dataset.searchSubmit===input.id){
  // Keep the keyboard and current IME selection intact when tapping Search.
  button.addEventListener('pointerdown',event=>event.preventDefault());
  button.addEventListener('click',commit);
 }
}
