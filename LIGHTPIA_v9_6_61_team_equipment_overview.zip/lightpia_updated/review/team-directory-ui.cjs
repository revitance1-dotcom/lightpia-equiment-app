const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/www/app.js','utf8');
const board=s.slice(s.indexOf("document.getElementById('activeTeamsCard')"),s.indexOf('// Reservation pilot:'));const statLine=s.split('\n').find(line=>line.includes('const al=activeLoans();$("statKinds")'));
const code=s.slice(s.indexOf('function subscribe(){'),s.indexOf('function initConfig('));
const html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{for(const width of [320,393,768]){
 const page=await browser.newPage({viewport:{width,height:900}});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.setContent(html);await page.addScriptTag({content:fs.readFileSync(require('path').resolve(__dirname,'../www/display-order.js'),'utf8').replace(/export /g,'')});await page.addScriptTag({content:fs.readFileSync(path.resolve(__dirname,'../www/equipment-units.js'),'utf8').replace(/export /g,'')});
 await page.addScriptTag({content:fs.readFileSync(root+'/www/loan-groups.js','utf8').replace(/export /g,'')});
 await page.addScriptTag({content:`const $=id=>document.getElementById(id),ID_DOMAIN='accounts.lightpia.internal';
 let reservations=[],membersList=[];const esc=value=>String(value??''),activeLoans=()=>[],late=()=>false,notificationCenter={refresh(){}};function modal(title,content){window.teamModal={title,content};}let member=null;const renderEquipmentList=()=>{};let ready=true,adminMode=false,currentUser={uid:'staff',email:'test@accounts.lightpia.internal'},teamName='본팀',teamId='A',teamList=[],projects=[],unsubs=[],callbacks={};
 const isAdmin=()=>adminMode,db={},auth={},equipmentPhotos={subscribe:()=>()=>{}},crewBoard={subscribe:()=>[]},signOut=async()=>{},clearSubs=()=>{unsubs=[]},render=()=>{${statLine}},renderProjects=()=>{},renderTeamAdmin=()=>{},renderReservations=()=>{},updateAdminPushPanel=()=>{};
 const eqCol=()=> 'equipment',loanCol=()=> 'loans',repairCol=()=> 'repairs',reservationCol=()=> 'reservations';
 const doc=(db,...args)=>args.join('/'),collection=(db,...args)=>args.join('/'),query=x=>x,orderBy=()=>{};
 function onSnapshot(ref,callback){callbacks[ref]=callback;return ()=>{}}
 function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}
 function status(label,ok=false){$('connection').textContent=label;$('connection').className='status'+(ok?' ok':'');}
 ${s.slice(s.indexOf('function canEditEquipment('),s.indexOf('function field('))}
 ${code}
 ${board}
 show('app',true);show('loginGate',false);show('view-home',false);show('view-settings',true);
 updateAccountUI(currentUser);status('본팀 · 공용 재고 연결됨',true);subscribe();`});
 assert((await page.locator('#accountInfo').textContent()).startsWith('본팀'));
 await page.evaluate(()=>callbacks['members/staff']({id:'staff',exists:()=>true,data:()=>({role:'team',active:true,teamName:'본팀',equipmentEditor:true})}));assert(await page.locator('#addEquipmentBtn').evaluate(el=>!el.classList.contains('hidden')));await page.evaluate(()=>callbacks['members/staff']({id:'staff',exists:()=>true,data:()=>({role:'team',active:true,teamName:'본팀',equipmentEditor:false})}));assert(!(await page.locator('#addEquipmentBtn').evaluate(el=>!el.classList.contains('hidden'))));
 await page.evaluate(()=>callbacks.teams({docs:[{id:'A',data:()=>({name:'본팀',projectId:'P',active:true})}]}));
 await page.evaluate(()=>callbacks.projects({docs:[{id:'P',data:()=>({name:'언내추럴',active:true})}]}));
 assert.equal(await page.locator('#connection').textContent(),'언내추럴 · 본팀 · 공용 재고 연결됨');assert.equal(await page.locator('#accountInfo').textContent(),'언내추럴 · 본팀 · test · 회사 공용 재고');
 // Metadata can arrive in the reverse order or change later without re-login.
 await page.evaluate(()=>{teamList=[];projects=[];callbacks.projects({docs:[{id:'P',data:()=>({name:'새 작품',active:true})}]});callbacks.teams({docs:[{id:'A',data:()=>({name:'본팀',projectId:'P',active:true})}]});});
 assert((await page.locator('#connection').textContent()).startsWith('새 작품 · 본팀'));
 await page.evaluate(()=>{status('장비 읽기 오류');callbacks.projects({docs:[{id:'P',data:()=>({name:'갱신된 작품',active:true})}]});});
 assert.equal(await page.locator('#connection').textContent(),'장비 읽기 오류');assert((await page.locator('#accountInfo').textContent()).startsWith('갱신된 작품 · 본팀'));
 await page.evaluate(()=>{adminMode=true;refreshAccountIdentity();status(accountTeamLabel()+' · 공용 재고 연결됨',true);});assert((await page.locator('#accountInfo').textContent()).startsWith('관리자 ·'));
 await page.evaluate(()=>{adminMode=false;teamId='';teamName='대기 직원';refreshAccountIdentity();});assert((await page.locator('#accountInfo').textContent()).startsWith('대기 직원 ·'));
 await page.evaluate(()=>{teamId='A';teamName='본팀';projects=[{id:'P',name:'VERY_LONG_PROJECT_NAME_WITHOUT_SPACES_'.repeat(3)}];refreshAccountIdentity();});
 await page.evaluate(()=>{adminMode=false;teamId='A';teamName='본팀';callbacks.projects({docs:[{id:'P',data:()=>({name:'언내추럴',active:true})},{id:'Q',data:()=>({name:'다른 작품',active:true})},{id:'R',data:()=>({name:'종료 작품',active:false})}]});window.directoryTeams=[{id:'A',name:'본팀',projectId:'P',active:true},{id:'B',name:'장비 없는 팀',projectId:'Q',active:true},{id:'C',name:'종료된 팀',projectId:'Q',active:false},{id:'D',name:'종료 작품 팀',projectId:'R',active:true},{id:'E',name:'작품 미연결',active:true}];callbacks.teams({docs:directoryTeams.map(t=>({id:t.id,data:()=>t}))});show('view-home',true);show('view-settings',false);});
 assert.equal(await page.locator('#statKinds').textContent(),'2');assert((await page.locator('#accountInfo').textContent()).startsWith('언내추럴 · 본팀'));
 await page.locator('#activeTeamsCard').click();let detail=await page.evaluate(()=>teamModal.content);assert(detail.includes('언내추럴'));assert(detail.includes('다른 작품'));assert(detail.includes('장비 없는 팀'));assert(!detail.includes('종료된 팀'));assert(!detail.includes('종료 작품 팀'));assert(!detail.includes('작품 미연결'));assert(!detail.includes('data-close-team'));assert(!detail.includes('data-move-member'));
 await page.evaluate(()=>{teamId='';teamName='대기 직원';callbacks.teams({docs:directoryTeams.map(t=>({id:t.id,data:()=>t}))});});assert.equal(await page.locator('#statKinds').textContent(),'2');
 await page.evaluate(()=>{adminMode=true;callbacks.teams({docs:directoryTeams.map(t=>({id:t.id,data:()=>t}))});});assert.equal(await page.locator('#statKinds').textContent(),'2');
 await page.evaluate(()=>{adminMode=false;directoryTeams.find(t=>t.id==='B').active=false;callbacks.teams({docs:directoryTeams.map(t=>({id:t.id,data:()=>t}))});});assert.equal(await page.locator('#statKinds').textContent(),'1');
 console.log('PASS all-team dashboard',width,'assigned/standby/admin parity, cross-project teams without loans, closed/unlinked exclusion, own identity retained, real-time team closure, read-only popup');
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert.equal(errors.length,0,errors.join('\n'));
 console.log('PASS account identity',width,'actual team/project subscription callbacks, both arrival orders, header and Settings labels, live rename, preserve errors, admin/waiting fallbacks, long names without overflow');await page.close();
}}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
