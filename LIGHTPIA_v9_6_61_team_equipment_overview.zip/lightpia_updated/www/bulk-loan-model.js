import {loadCapacitySnapshot,readCapacityLock,writeCapacityLock,checkCapacity} from './availability-model.js';
import {unitSnapshot,sameUnit,quantityText,inventoryStock} from './equipment-units.js';
// Three equipment/loan pairs leave room for member, team and project rule reads.
// Each pair is atomic; stable loan IDs make retry after an uncertain commit safe.
export async function submitBulkLoans(api,db,items,payload,onProgress=()=>{}) {
 if(!items.length||new Set(items.map(x=>x.equipmentId)).size!==items.length)throw Error('장비를 1종 이상 중복 없이 선택해 주세요.');
 if(items.some(x=>!Number.isInteger(x.quantity)||x.quantity<1))throw Error('대여 수량은 1 이상의 정수여야 합니다.');
 const fields=['equipmentId','quantity','ownerUid','team','teamId','projectId','person','loanDate','dueDate','note','rentalType','equipmentGroup','externalTeam','externalPerson','projectName'];
 let completed=0;
 for(let start=0;start<items.length;start+=3){
  const chunk=items.slice(start,start+3);
  let finished=false;for(let attempt=0;attempt<5&&!finished;attempt++){
  const capacity=api.capacity,snapshot=capacity?await loadCapacitySnapshot(capacity,db,chunk.map(i=>i.equipmentId),payload.loanDate):null;
  try{await api.runTransaction(db,async tx=>{
   const rows=[];
   for(const item of chunk){
    const loanRef=api.doc(db,'company/main/loans',item.loanId),eqRef=api.doc(db,'company/main/equipment',item.equipmentId);
    const lock=capacity?await readCapacityLock(capacity,db,tx,item.equipmentId,snapshot):null;
    const loan=await tx.get(loanRef),eq=await tx.get(eqRef);
    const unit=unitSnapshot(eq.exists()?eq.data():loan.exists()?loan.data():{});if(item.unit&&!sameUnit(item,unit))throw Error("장비 단위가 변경되었습니다. 목록을 다시 선택해 주세요.");
    const data={...payload,...unit,equipmentId:item.equipmentId,quantity:item.quantity};
    if(loan.exists()){
     const old=loan.data();
     if(!sameUnit(old,data)||!fields.every(k=>(old[k]??'')===(data[k]??'')))throw Error('이미 저장된 대여 건입니다. 대여 내역에서 확인해 주세요.');
     rows.push({saved:true});continue;
    }
    if(!eq.exists())throw Error('삭제된 장비가 있습니다.');
    const stock=eq.data(),available=inventoryStock(stock).available;
    if(Number(stock.total||0)!==0&&item.quantity>available)throw Error(`${stock.name}: 가용 ${quantityText(available,stock)}, 신청 ${quantityText(item.quantity,stock)}`);
    if(capacity)checkCapacity({...stock,id:item.equipmentId},snapshot,item.quantity,payload.loanDate,payload.dueDate,api.today||payload.loanDate);
    rows.push({loanRef,eqRef,stock,data,lock});
   }
   for(const row of rows){
    if(row.saved)continue;
    if(capacity)writeCapacityLock(capacity,tx,row.lock,row.loanRef.id,'loan');
    tx.update(row.eqRef,{loaned:Number(row.stock.loaned||0)+row.data.quantity,lastLoanId:row.loanRef.id});
    tx.set(row.loanRef,{...row.data,equipmentName:row.stock.name,status:'active',createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});
   }
  });finished=true;}catch(e){if(!e.capacityRetry||attempt===4)throw e;}
  }
  completed+=chunk.length;onProgress(chunk,completed,items.length);
 }
 return completed;
}
