import admin from 'firebase-admin';import fs from 'node:fs';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');if(account?.project_id!=='light-4e07d')throw Error('Unexpected project');
admin.initializeApp({credential:admin.credential.cert(account)});
const base=JSON.parse(fs.readFileSync('/tmp/lightpia-rules/base.json','utf8'));
if(base.changed){
 const current=await admin.securityRules().getFirestoreRuleset();if(current.name!==base.rulesetName)throw Error('Production rules changed during validation. Please retry.');
 await admin.securityRules().releaseFirestoreRulesetFromSource(fs.readFileSync('/tmp/lightpia-rules/candidate.rules','utf8'));
 console.log('Enabled validated administrator and maintenance rules. Unrelated access rules preserved.');
}else console.log('No security rules change needed.');
