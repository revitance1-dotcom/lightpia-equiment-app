V6: Built-in Firebase project configuration; native Android/iOS JSON/CSV export via Capacitor Filesystem+Share; iOS PWA manifest and apple-touch-icon.
NOT YET IMPLEMENTED: team access codes, shared organization database, team security rules, server-side inventory transactions.
iOS native build requires macOS + Xcode + Apple signing; web/PWA must be hosted over HTTPS.
Security: current Firestore data is scoped per Firebase auth UID; team sharing does not work yet.
