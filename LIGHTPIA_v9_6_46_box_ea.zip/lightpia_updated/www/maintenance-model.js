import {unitSnapshot,quantityText} from './equipment-units.js';
export const MAINTENANCE_ADMIN_UID='7iSB1gW9PAhYPgi253IUk4Dooyp2';
const integer=(n,label)=>{if(!Number.isSafeInteger(n)||n<0)throw Error(label+'은 0 이상의 정수여야 합니다.');return n;};
export function stockState(e){
 const total=integer(e.total??0,'전체 수량'),loaned=integer(e.loaned??0,'대여 수량'),repairing=integer(e.repairing??0,'수리 수량'),brokenStock=integer(e.brokenStock??0,'입고된 고장 수량'),reportRepairing=integer(e.reportRepairing??0,'신고 수리 수량');
 if(reportRepairing>repairing)throw Error('수리 수량이 일치하지 않습니다.');
 return {total,loaned,repairing,brokenStock,reportRepairing,available:total-loaned-repairing-brokenStock};
}
export function maintenanceReturnFields(e,loan,id){
 const s=stockState(e),quantity=integer(loan.quantity,'대여 수량'),damage=integer(loan.damageQuantity??0,'고장 수량');
 if(!quantity||s.loaned<quantity||damage>quantity)throw Error('대여·고장 수량이 일치하지 않습니다.');
 return {loaned:s.loaned-quantity,brokenStock:s.brokenStock+damage,lastLoanId:id};
}
const adminActor=actor=>{if(!actor?.isAdmin||actor.uid!==MAINTENANCE_ADMIN_UID)throw Error('관리자 전용입니다.');};
const eqRef=(api,db,id)=>api.doc(db,'company','main','equipment',id);
const loanRef=(api,db,id)=>api.doc(db,'company','main','loans',id);
const reportRef=(api,db,id)=>api.doc(db,'company','main','damageReports',id);
export async function setRepairQuantity(api,db,id,quantity,actor){
 adminActor(actor);integer(quantity,'수리 수량');
 return api.runTransaction(db,async tx=>{
  const ref=eqRef(api,db,id),snap=await tx.get(ref);if(!snap.exists())throw Error('장비가 없습니다.');const e=snap.data(),s=stockState(e);
  if(quantity<s.reportRepairing)throw Error(`고장 신고에서 접수한 ${quantityText(s.reportRepairing,e)}는 해당 신고에서 수리 완료 처리해 주세요.`);
  if(s.total!==0&&s.loaned+s.brokenStock+quantity>s.total)throw Error(`수리 수량은 최대 ${quantityText(Math.max(0,s.total-s.loaned-s.brokenStock),e)}입니다.`);
  tx.update(ref,{repairing:quantity,updatedAt:api.serverTimestamp()});return {equipmentId:id};
 });
}
export async function submitDamageReport(api,db,id,quantity,symptom,actor){
 integer(quantity,'고장 수량');if(quantity<1)throw Error('고장 수량은 1 이상이어야 합니다.');symptom=String(symptom||'').trim();if(!symptom||symptom.length>1000)throw Error('고장 증상을 1~1,000자로 입력해 주세요.');
 const report=api.doc(api.collection(db,'company','main','damageReports'));
 return api.runTransaction(db,async tx=>{
  const ref=loanRef(api,db,id),snap=await tx.get(ref);if(!snap.exists())throw Error('대여 기록이 없습니다.');const l=snap.data();
  if(l.status!=='active')throw Error('대여 중인 장비만 고장 신고할 수 있습니다.');
  if(!actor?.uid||!(actor.isAdmin&&actor.uid===MAINTENANCE_ADMIN_UID)&&actor.uid!==l.ownerUid&&!(actor.teamId&&actor.teamId===l.teamId))throw Error('본인 또는 같은 팀의 대여 장비만 신고할 수 있습니다.');
  const current=integer(l.damageQuantity??0,'기존 고장 수량');if(current+quantity>l.quantity)throw Error(`추가 신고 가능한 수량은 ${quantityText(Math.max(0,l.quantity-current),l)}입니다.`);
  const eq=await tx.get(eqRef(api,db,l.equipmentId));if(!eq.exists())throw Error('장비가 없습니다.');
  const data={...unitSnapshot(l),equipmentId:l.equipmentId,equipmentName:l.equipmentName||eq.data().name,loanId:id,teamId:l.teamId||'',teamName:l.team||'',reporterUid:actor.uid,reporterName:String(actor.name||'직원').slice(0,80),quantity,symptom,status:'reported',createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()};
  tx.update(ref,{damageQuantity:current+quantity,lastDamageId:report.id,updatedAt:api.serverTimestamp()});tx.set(report,data);
  return {equipmentId:l.equipmentId,reportId:report.id};
 });
}
export async function transitionDamageReport(api,db,id,next,actor){
 if(next!=='cancelled')adminActor(actor);if(!['repairing','completed','cancelled'].includes(next))throw Error('지원하지 않는 처리입니다.');
 return api.runTransaction(db,async tx=>{
  const ref=reportRef(api,db,id),snap=await tx.get(ref);if(!snap.exists())throw Error('고장 신고가 없습니다.');const r=snap.data();
  if(next==='cancelled'&&!(actor?.isAdmin&&actor.uid===MAINTENANCE_ADMIN_UID)&&(!actor?.uid||actor.uid!==r.reporterUid))throw Error('본인이 등록한 고장 신고만 취소할 수 있습니다.');
  if(r.status===next)return {equipmentId:r.equipmentId};
  if(!(r.status==='reported'&&['repairing','cancelled'].includes(next)||r.status==='repairing'&&['completed','cancelled'].includes(next)))throw Error('이미 처리되었거나 변경된 신고입니다.');
  const lr=loanRef(api,db,r.loanId),er=eqRef(api,db,r.equipmentId),lSnap=await tx.get(lr),eSnap=await tx.get(er);
  if(!lSnap.exists()||!eSnap.exists())throw Error('연결된 장비 또는 대여 기록이 없습니다.');const l=lSnap.data(),s=stockState(eSnap.data()),q=integer(r.quantity,'신고 수량'),damage=integer(l.damageQuantity??0,'미처리 고장 수량');
  if(!q||damage<q||l.equipmentId!==r.equipmentId)throw Error('고장 수량 또는 연결 정보가 일치하지 않습니다.');
  if(next==='repairing'){
   if(l.status!=='returned')throw Error('현장 장비를 먼저 반납 처리한 뒤 수리 접수해 주세요.');if(s.brokenStock<q)throw Error('입고된 고장 수량이 부족합니다.');
   tx.update(er,{brokenStock:s.brokenStock-q,repairing:s.repairing+q,reportRepairing:s.reportRepairing+q,lastMaintenanceId:id,updatedAt:api.serverTimestamp()});
  }else{
   if(next==='completed'||r.status==='repairing'){
    if(l.status!=='returned'||s.repairing<q||s.reportRepairing<q)throw Error('수리 수량이 일치하지 않습니다.');
    tx.update(er,{repairing:s.repairing-q,reportRepairing:s.reportRepairing-q,lastMaintenanceId:id,updatedAt:api.serverTimestamp()});
   }else if(l.status==='returned'){
    if(s.brokenStock<q)throw Error('입고된 고장 수량이 부족합니다.');tx.update(er,{brokenStock:s.brokenStock-q,lastMaintenanceId:id,updatedAt:api.serverTimestamp()});
   }else if(l.status!=='active')throw Error('대여 상태를 확인해 주세요.');
   tx.update(lr,{damageQuantity:damage-q,lastDamageId:id,updatedAt:api.serverTimestamp()});
  }
  tx.update(ref,{status:next,reviewedBy:actor.uid,updatedAt:api.serverTimestamp()});return {equipmentId:r.equipmentId};
 });
}
