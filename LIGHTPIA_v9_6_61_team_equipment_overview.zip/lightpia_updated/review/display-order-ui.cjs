const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/www/app.js','utf8'),html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const rendering=s.slice(s.indexOf('let equipmentCategoryFilter='),s.indexOf('function modal(')),modal=s.slice(s.indexOf('function modal('),s.indexOf('function addEquipment(')),cart=s.slice(s.indexOf('let cartItems='),s.indexOf('async function submitCart(')),reservation=s.slice(s.indexOf('// Reservation pilot:'),s.indexOf('async function submitReservation('));
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{for(const width of [320,393,1280]){
 const page=await browser.newPage({viewport:{width,height:950},hasTouch:true}),errors=[];page.on('pageerror',e=>{errors.push(e.message);console.error('PAGE ERROR',e.message)});page.on('dialog',d=>d.accept());await page.setContent(html);await page.locator('#loanViewMode').evaluate(el=>el.value='details');
 for(const name of ['display-order','equipment-units','equipment-search','search-input','loan-groups','reservation-parties'])await page.addScriptTag({content:fs.readFileSync(root+'/www/'+name+'.js','utf8').replace(/export /g,'')});
 await page.addScriptTag({content:`const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let adminMode=true,ready=true;const isAdmin=()=>adminMode,ADMIN_UID='admin',currentUser={uid:'admin'},teamId='admin',teamName='관리자',today=()=> '2026-10-29';const projects=[],teamList=[],reservations=[],breakdownReports=[];
 const equipment=[{id:'400',name:'STORM 400X',category:'LED',total:7},{id:'600',name:'storm 600x',category:'LED',total:7},{id:'1200',name:'STORM 1200X',category:'LED',total:7},{id:'m18',name:'ARRI M18',category:'HMI',total:7},{id:'m90',name:'ARRI M90',category:'HMI',total:7},{id:'k',name:'기타 장비',category:'기타',total:0}];
 const loans=equipment.slice(0,3).map((e,i)=>({id:'l'+i,equipmentId:e.id,equipmentName:e.name,quantity:1,team:'관리자',teamId:'admin',ownerUid:'admin',status:i===0?'returned':'active',equipmentGroup:'추가장비'}));
 const activeLoans=()=>loans.filter(l=>l.status!=='returned'),canHandleLoan=()=>true,canReportDamage=()=>false,late=()=>false,borrowedQtyFor=()=>0,repairQtyFor=()=>0,brokenQtyFor=()=>0,availableQtyFor=id=>equipment.find(e=>e.id===id).total,untracked=id=>equipment.find(e=>e.id===id).total===0;
 let bulkReturnSubmitting=false;function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}function showEquipmentDetail(){}function submitCart(){}function rowCountForReservation(id){return [...document.querySelectorAll('[data-reserve-count]')].find(x=>x.dataset.reserveCount===id)}
 ${rendering}\n${modal}\n${cart}\n${reservation}
 let saved={},writes=0,actionClicks=0;const memory={getItem:()=>null,setItem(){}};
 const displayOrder=createDisplayOrder({isAdmin,storage:memory,onSave:async(group,keys)=>{writes++;saved[group]=keys;},onChange:()=>{renderEquipmentList();renderStockOverview();if($('cartEquipmentList'))renderCart();if($('reserveEquipmentList'))renderReservationEquipment();}});
 show('app',true);show('loginGate',false);show('setupNotice',false);show('view-home',false);show('view-loans',true);render();displayOrder.apply();
 $('addLoanBtn').addEventListener('click',()=>actionClicks++);$('loanFilter').addEventListener('change',render);
 `});
 assert.equal(await page.locator('#loanFilter').inputValue(),'all');assert.equal(await page.locator('#loanList .item').count(),3);
 assert.deepEqual(await page.locator('#loanList .itemtitle').allTextContents(),['STORM 1200X · 1EA','storm 600x · 1EA','STORM 400X · 1EA']);
 await page.locator('#loanFilter').selectOption('active');assert.equal(await page.locator('#loanList .item').count(),2);await page.locator('#loanFilter').selectOption('all');
 async function mouseDrag(source,target){const a=await source.boundingBox(),b=await target.boundingBox();await page.mouse.move(a.x+a.width/2,a.y+a.height/2);await page.mouse.down();await page.waitForTimeout(500);await page.mouse.move(b.x+b.width/2,b.y+b.height/2,{steps:4});await page.mouse.up();await page.evaluate(()=>displayOrder.whenSaved());}
 await mouseDrag(page.locator('#addLoanBtn'),page.locator('#bulkDeleteReturnedBtn'));
 assert.deepEqual(await page.evaluate(()=>saved.loanActions),['loan','delete','return']);assert.equal(await page.evaluate(()=>actionClicks),0);
 await page.waitForTimeout(750);await page.locator('#addLoanBtn').click();assert.equal(await page.evaluate(()=>actionClicks),1);
 // Reapplying a server snapshot simulates a second device/app restart.
 await page.evaluate(()=>{const remote=JSON.parse(JSON.stringify(saved));displayOrder.receive(remote);});assert.equal(await page.locator('[data-reorder-group=loanActions]>button').first().getAttribute('id'),'addLoanBtn');
 await page.evaluate(()=>showStockOverview());const expected=['m90','m18','1200','600','400','k'];assert.deepEqual(await page.locator('.stock-item').evaluateAll(nodes=>nodes.map(n=>n.dataset.equipmentDetail)),expected);
 // Real Chromium touch sequence: hold then move; no pointer-only simulation.
 const source=page.locator('[data-stock-category=LED]'),target=page.locator('[data-stock-category="전체"]');await source.scrollIntoViewIfNeeded();const a=await source.boundingBox(),b=await target.boundingBox(),cdp=await page.context().newCDPSession(page);
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:a.x+a.width/2,y:a.y+a.height/2}]});await page.waitForTimeout(550);
 assert.equal(await page.locator('.reorder-ghost').count(),1);
 await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:b.x+b.width/2,y:b.y+b.height/2}]});await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.evaluate(()=>displayOrder.whenSaved());
 assert.equal((await page.evaluate(()=>saved.categories))[0],'LED');assert.equal(await page.locator('[data-stock-category][aria-pressed=true]').textContent(),'전체');
 await page.evaluate(()=>{closeModal();show('view-loans',false);show('view-equipment',true);renderEquipmentList();});assert.equal(await page.locator('#equipmentCategories>button').first().getAttribute('data-equipment-category'),'LED');
 await page.evaluate(()=>addLoan());assert.equal(await page.locator('#cartCategories>button').first().getAttribute('data-cart-cat'),'LED');assert.deepEqual(await page.locator('[data-cart-row]').evaluateAll(nodes=>nodes.map(n=>n.dataset.cartRow)),['k','m90','m18','1200','600','400']);
 await page.locator('[data-cart-plus="400"]').click({trial:true});await page.evaluate(()=>{cartItems['400']=1;renderCart(true);closeModal();openReservation();});assert.equal(await page.locator('#reserveCategories>button').first().getAttribute('data-reserve-category'),'LED');
 assert.deepEqual(await page.locator('[data-reserve-row]').evaluateAll(nodes=>nodes.map(n=>n.dataset.reserveRow)),['k','m90','m18','1200','600','400']);
 await page.evaluate(()=>{document.querySelector('[data-reserve-qty="400"]').value='2';displayOrder.receive({...saved,categories:['기타','HMI','LED','전체']});});assert.equal(await page.locator('[data-reserve-qty="400"]').inputValue(),'2');
 await page.evaluate(()=>{closeModal();adminMode=false;displayOrder.apply();show('view-equipment',false);show('view-loans',true);});const before=await page.evaluate(()=>writes);await mouseDrag(page.locator('#addLoanBtn'),page.locator('#bulkReturnBtn'));assert.equal(await page.evaluate(()=>writes),before);assert.equal(await page.locator('.reorder-ghost').count(),0);
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert.equal(errors.length,0,errors.join('\n'));console.log('PASS display order UI',width,'natural equipment names, all-history default, mouse + real touch long press, no accidental actions, shared category preference, selection retained, staff read only and no overflow');await page.close();
 }}finally{await browser.close()}})().catch(e=>{console.error(e);process.exit(1)});
