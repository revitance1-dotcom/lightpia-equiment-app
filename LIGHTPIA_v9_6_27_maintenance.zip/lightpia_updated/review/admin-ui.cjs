const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),source=fs.readFileSync(root+'/www/app.js','utf8'),shots=process.env.UI_SCREENSHOT_DIR||'/tmp/lightpia-ui/screenshots';fs.mkdirSync(shots,{recursive:true});
const helpers=source.slice(source.indexOf('function modal('),source.indexOf('function addEquipment('));
const basket=source.slice(source.indexOf('let equipmentDrafts='));
let html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 for(const [width,height] of [[320,700],[393,850],[768,1024]]){
  const page=await browser.newPage({viewport:{width,height},locale:'ko-KR'}),dialogs=[];
  page.setDefaultTimeout(12000);page.on('pageerror',e=>console.error('PAGE ERROR:',e.message));
  page.on('dialog',async d=>{dialogs.push(d.message());await d.accept();});await page.setContent(html);
  console.log('BASKET viewport',width,'start');await page.addScriptTag({content:`const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}const isAdmin=()=>true,ADMIN_UID='admin',currentUser={uid:'admin'},db={},equipment=[];const saved=new Map();let seq=0;window.failCommit=true;window.commits=0;function eqCol(){return {path:'equipment'}}function doc(col){return {id:'new-'+(++seq)}}const serverTimestamp=()=>0;const getDoc=async ref=>({exists:()=>saved.has(ref.id)});const writeBatch=()=>{const rows=[];return {set:(ref,data)=>rows.push([ref.id,data]),commit:async()=>{if(window.failCommit)throw Error('네트워크 테스트');for(const [id,d]of rows)saved.set(id,d);window.commits++;}}};${helpers}\n${basket}\nopenEquipmentBatch();`});
  console.log('BASKET adding',width);await page.locator('#eqName').fill('ARRI M90');await page.locator('#eqCategory').fill('HMI');await page.locator('#eqTotal').fill('2');await page.locator('#equipmentDraftAdd').click();
  assert.equal(await page.locator('#eqCategory').inputValue(),'HMI');assert.equal(await page.locator('#eqName').inputValue(),'');
  await page.locator('#eqName').fill('ARRI M90');await page.locator('#equipmentDraftAdd').click();assert(dialogs.some(s=>s.includes('같은 장비')));await page.locator('#eqName').fill('ARRI M18');await page.locator('#equipmentDraftAdd').click();
  await page.locator('[data-draft-edit="0"]').click();await page.locator('#eqTotal').fill('5');await page.locator('#equipmentDraftAdd').click();
  await page.locator('#eqName').fill('Skypanel S60-C');await page.locator('#eqCategory').fill('LED');
  console.log('BASKET first save',width);await page.locator('#equipmentDraftSave').click();await page.waitForFunction(()=>!equipmentDraftSaving,null,{timeout:10000});assert(dialogs.some(s=>s.includes('네트워크 테스트')));assert.equal(await page.evaluate(()=>equipmentDrafts.length),3);assert.equal(await page.evaluate(()=>saved.size),0);
  const geometry=await page.evaluate(()=>{const b=document.querySelector('.loan-step').getBoundingClientRect(),f=document.querySelector('.loan-footer').getBoundingClientRect();return {body:b.bottom,footer:f.top,bottom:f.bottom,scroll:document.documentElement.scrollWidth};});assert(geometry.body<=geometry.footer+1);assert(geometry.bottom<=height+1);assert(geometry.scroll<=width+1);
  if(width===393)await page.screenshot({path:path.join(shots,'equipment-basket.png')});
  console.log('BASKET retry save',width);await page.evaluate(()=>window.failCommit=false);await page.locator('#equipmentDraftSave').click();await page.waitForFunction(()=>!document.getElementById('equipmentDraftSave'),null,{timeout:10000}).catch(async e=>{console.error('Save dialogs:',dialogs);console.error('Save state:',await page.evaluate(()=>({saving:equipmentDraftSaving,drafts:equipmentDrafts,refs:equipmentDraftRefs,saved:[...saved]})));await page.screenshot({path:path.join(shots,'basket-failure.png')});throw e;});assert.equal(await page.evaluate(()=>saved.size),3);assert.equal(await page.evaluate(()=>[...saved.values()].find(x=>x.name==='ARRI M90').total),5);assert.equal(await page.evaluate(()=>window.commits),1);
  assert.equal(await page.evaluate(()=>{try{validateEquipmentDraft({name:'장비',total:1.5,model:'',category:'',searchTags:'',note:''});return false}catch{return true}}),true);
  console.log('PASS equipment basket',width,height,'category retention, duplicate detection, edit, unsaved last item, atomic failure retention, retry, footer layout');await page.close();
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
