const clean=value=>String(value??'').normalize('NFKC').toLocaleLowerCase();
export function normalizeEquipmentTags(value){
 const seen=new Set();return String(value??'').normalize('NFKC').split(/[\s,#]+/u).filter(Boolean).filter(tag=>{const key=clean(tag);if(seen.has(key))return false;seen.add(key);return true;}).map(tag=>'#'+tag).join(' ');
}
export function matchesEquipmentSearch(e,query){
 const terms=clean(query).trim().split(/\s+/u).filter(Boolean);
 const tags=normalizeEquipmentTags(e.searchTags).split(' ').filter(Boolean).map(t=>clean(t.slice(1)));
 const text=clean([e.name,e.model,e.category,e.note,...tags].filter(Boolean).join(' '));
 return terms.every(term=>term.startsWith('#')?tags.some(tag=>tag.startsWith(term.slice(1))):text.includes(term)||text.replace(/\s+/g,'').includes(term));
}
