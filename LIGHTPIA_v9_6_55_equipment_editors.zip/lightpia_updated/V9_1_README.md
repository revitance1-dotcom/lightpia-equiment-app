# Lightpia & Softsun V9.1 test

- Bulk full returns: select up to 5 loan records, each for a distinct equipment ID; all-or-nothing Firestore transaction. Same equipment with multiple loan records must be returned separately. Partial returns not included.
- Equipment total = 0 means **untracked quantity**, NOT zero stock. Loans may exceed zero; the remaining figure can be negative. A known positive total still strictly enforces stock limits.
- Publish `www/firestore.rules` to Firebase Console BEFORE testing V9.1. Rules now allow untracked items with total zero to have outstanding loans.
- Back up current data and test with sample loans first. APK and live Firebase not tested here.
- Existing V9 bulk loan can hit Firestore rule document access limits for large baskets; limit basket size for operational reliability.
