V9.6.5: Fixed blank hero banner caused by competing CSS rules. Uses bundled image element; no Firebase or business logic changes.
