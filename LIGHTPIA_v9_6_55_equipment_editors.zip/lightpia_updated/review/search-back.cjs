const assert=require('assert');
(async()=>{
 const {normalizeEquipmentTags,matchesEquipmentSearch}=await import('../www/equipment-search.js');
 const {correct18kTags}=await import('../push_sender/tag-correction-model.mjs');
 const {installAndroidBackHandler}=await import('../www/android-back.js');
 assert.equal(normalizeEquipmentTags('#sun #컴 SUN, #SUN'),'#sun #컴');
 const com={name:'18K COM',category:'HMI',searchTags:'#sun #컴'},par={name:'18K PAR',category:'HMI',searchTags:'#파'};
 for(const q of ['#sun','sun','#컴','컴','18k com','18kcom']){assert(matchesEquipmentSearch(com,q));assert(!matchesEquipmentSearch(par,q));}
 assert(matchesEquipmentSearch(par,'18k par'));assert(matchesEquipmentSearch(par,'#파'));assert(matchesEquipmentSearch(com,'HMI #컴'));
 assert.equal(correct18kTags('18K PAR','#sun #컴 #파 #PAR'),'#파 #PAR');
 assert.equal(correct18kTags('18K COM','#other'),'#other #sun #컴');
 assert.equal(correct18kTags('M90','#sun #컴'),'#sun #컴');
 let listener,closed=0,exits=0,homes=0,modal=true,secondary=true,registrations=0;
 const cap={isNativePlatform:()=>true,getPlatform:()=> 'android',Plugins:{App:{addListener:async(name,fn)=>{assert.equal(name,'backButton');registrations++;listener=fn;return {};},exitApp:async()=>exits++}}};
 const ui={hasModal:()=>modal,closeModal:()=>closed++,isSecondaryView:()=>secondary,goHome:()=>{homes++;secondary=false;}};
 await installAndroidBackHandler(cap,ui);await listener();assert.equal(closed,1);assert.equal(exits,0);assert.equal(homes,0);
 // A cancelled Close confirmation or a saving guard still consumes the back event.
 await listener();assert.equal(exits,0);modal=false;await listener();assert.equal(homes,1);assert.equal(exits,0);await listener();assert.equal(exits,1);
 assert.equal(await installAndroidBackHandler({isNativePlatform:()=>false},ui),null);assert.equal(registrations,1);
 console.log('PASS tags: per-equipment lookup, hashtag/plain/multi-term search, duplicate normalization, targeted correction preserves other aliases; Android back closes modal first, respects close guards, returns home before exit, browser excluded');
})().catch(e=>{console.error(e);process.exit(1)});
