async function readEquipmentPhoto(file){
 const named=/\.(jpe?g|png|webp)$/i.test(file?.name||'');
 if(!file||(!['image/jpeg','image/png','image/webp'].includes(file.type)&&!named))throw Error('JPG, PNG, WEBP 사진을 선택해 주세요.');
 if(file.size>20*1024*1024)throw Error('20MB 이하 사진을 선택해 주세요.');
 const url=URL.createObjectURL(file),img=new Image();
 try{await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('사진 읽기가 지연되고 있습니다. 사진을 다시 선택해 주세요.')),15000);img.onload=()=>{clearTimeout(timer);resolve()};img.onerror=()=>{clearTimeout(timer);reject(Error('사진을 읽을 수 없습니다. JPG 또는 PNG로 저장한 뒤 다시 선택해 주세요.'))};img.src=url;});return img;}finally{URL.revokeObjectURL(url);}
}
function drawPhotoFrame(ctx,img,size,crop={zoom:1,x:0,y:0}){
 ctx.fillStyle='#fff';ctx.fillRect(0,0,size,size);
 const scale=Math.min(size/img.naturalWidth,size/img.naturalHeight)*.92*crop.zoom,w=img.naturalWidth*scale,h=img.naturalHeight*scale;
 ctx.drawImage(img,(size-w)/2+crop.x*size,(size-h)/2+crop.y*size,w,h);
}
function encodeEquipmentPhoto(img,crop={zoom:1,x:0,y:0}){
 const encode=(max,limit,square)=>{
  const canvas=document.createElement('canvas');let scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight)),side=max;
  for(let n=0;n<5;n++){
   canvas.width=square?side:Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=square?side:Math.max(1,Math.round(img.naturalHeight*scale));
   const ctx=canvas.getContext('2d');if(!ctx)throw Error('사진 편집 화면을 만들지 못했습니다. 앱을 다시 열어 주세요.');
   if(square)drawPhotoFrame(ctx,img,side,crop);else{ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);}
   for(const quality of [.86,.72,.56,.4]){const data=canvas.toDataURL('image/jpeg',quality);if(data.length<=limit)return data;}
   scale*=.7;side=Math.max(32,Math.round(side*.7));
  }throw Error('사진을 줄이지 못했습니다. 다른 사진을 선택해 주세요.');
 };
 return {image:encode(960,240000,false),thumbnail:encode(192,24000,true)};
}
export async function compressEquipmentPhoto(file){return encodeEquipmentPhoto(await readEquipmentPhoto(file));}
export function createEquipmentPhotos(ui){
 const {api,esc}=ui;let photos=new Map(),active=null;
 const valid=s=>typeof s==='string'&&/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(s);
 const loadImage=data=>new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('사진을 읽지 못했습니다. 새 사진을 선택해 주세요.'));img.src=data;});
 function thumbnail(id){const data=photos.get(id);return `<button type="button" class="equipment-photo" data-equipment-photo="${esc(id)}" aria-label="장비 사진 보기">${valid(data)?`<img src="${data}" alt="장비 사진" loading="lazy">`:'<span aria-hidden="true">▧</span>'}</button>`;}
 function label(id,body,mode='row'){
  const data=photos.get(id),has=valid(data),size=mode==='stock'?22:mode==='micro'?16:mode==='review'?20:28;
  return `<span class="equipment-inline-label photo-mode-${esc(mode)} ${has?'has-equipment-image':''}" data-equipment-label="${esc(id)}"><span class="equipment-inline-image" aria-hidden="true">${has?`<img src="${data}" alt="" loading="lazy" decoding="async" width="${size}" height="${size}">`:''}</span><span class="equipment-inline-text">${body}</span></span>`;
 }
 function refreshInline(){
  document.querySelectorAll('[data-equipment-label]').forEach(el=>{
   const data=photos.get(el.dataset.equipmentLabel),has=valid(data),slot=el.querySelector(':scope > .equipment-inline-image');if(!slot)return;
   el.classList.toggle('has-equipment-image',has);
   if(!has){slot.replaceChildren();return;}
   let image=slot.querySelector('img');if(!image){image=document.createElement('img');image.alt='';image.loading='lazy';image.decoding='async';slot.append(image);}
   if(image.getAttribute('src')!==data)image.src=data;
  });
 }
 async function open(id){
  const equipment=ui.equipment(id);if(!equipment)return;
  ui.modal(`${esc(equipment.name)} · 사진`,`<div id="equipmentPhotoView" data-photo-equipment="${esc(id)}"><p class="meta">사진을 불러오는 중…</p></div><p id="equipmentPhotoStatus" class="meta photo-status" role="status" aria-live="polite"></p>${ui.isAdmin()?`<div class="row photo-actions"><label class="photo-picker">새 사진 선택<input id="equipmentPhotoFile" type="file" accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"></label><button type="button" class="secondary" id="equipmentPhotoEdit" disabled>위치 조정</button><button type="button" class="secondary" id="equipmentPhotoDelete">사진 삭제</button></div><div id="equipmentPhotoEditor" class="photo-editor hidden"><h3>장비목록에 표시될 사진</h3><p class="meta">금색 테두리 안이 목록에 표시됩니다. 사진을 끌거나 아래 조절 막대로 위치와 크기를 맞춰 주세요.</p><div class="photo-stage"><canvas id="equipmentPhotoCanvas" width="512" height="512" tabindex="0" aria-label="사진 위치 조정. 방향키 또는 아래 조절 막대를 사용하세요."></canvas><span class="photo-frame" aria-hidden="true"></span></div><div class="photo-preview-row"><canvas id="equipmentPhotoThumb" width="68" height="68" aria-label="장비목록 실제 크기 미리보기"></canvas><span class="meta">목록 미리보기<br>원본 사진은 상세 보기에 보존됩니다.</span></div><label class="photo-adjust">크기 <input id="equipmentPhotoZoom" type="range" min="0.5" max="4" step="0.01" value="1"><output id="equipmentPhotoZoomValue">100%</output></label><label class="photo-adjust">좌우 <input id="equipmentPhotoX" type="range" min="-100" max="100" step="1" value="0"></label><label class="photo-adjust">위아래 <input id="equipmentPhotoY" type="range" min="-100" max="100" step="1" value="0"></label><div class="row"><button type="button" class="small secondary" id="equipmentPhotoFit">전체 맞춤</button><button type="button" class="small secondary" id="equipmentPhotoCenter">중앙 정렬</button></div><div class="modalbuttons"><button type="button" class="secondary" id="equipmentPhotoCancel">취소</button><button type="button" id="equipmentPhotoSave">사진 저장</button></div></div><p class="meta">사진을 선택한 뒤 위치를 확인하고 ‘사진 저장’을 눌러 주세요. JPG · PNG · WEBP, 최대 20MB.</p>`:''}`);
  const root=document.getElementById('equipmentPhotoView'),status=document.getElementById('equipmentPhotoStatus'),session={root,saving:false,dirty:false};active=session;
  const find=name=>root.parentElement?.querySelector('#equipmentPhoto'+name),file=find('File'),remove=find('Delete'),edit=find('Edit'),editor=find('Editor'),canvas=find('Canvas'),preview=find('Thumb');
  let saved=null,sourceDetail=null,revision=0,img=null,crop={zoom:1,x:0,y:0};
  const alive=()=>root.isConnected&&active===session;
  const message=(text,error=false)=>{if(!alive())return;status.textContent=text;status.classList.toggle('photo-error',error);};
  const paint=data=>{if(alive())root.innerHTML=valid(data)?`<img class="equipment-photo-large" src="${data}" alt="${esc(equipment.name)} 사진">`:'<div class="empty">등록된 사진이 없습니다. 새 사진을 선택해 주세요.</div>';};
  const controls=disabled=>{session.saving=disabled;if(!alive()||!file)return;for(const el of [file,remove,edit,...editor.querySelectorAll('button,input')])el.disabled=disabled;edit.disabled=disabled||!valid(saved);};
  const draw=()=>{if(!img||!alive())return;drawPhotoFrame(canvas.getContext('2d'),img,512,crop);drawPhotoFrame(preview.getContext('2d'),img,68,crop);find('Zoom').value=crop.zoom;find('X').value=Math.round(crop.x*100);find('Y').value=Math.round(crop.y*100);find('ZoomValue').value=Math.round(crop.zoom*100)+'%';};
  const begin=(source,original=null)=>{if(!alive())return;img=source;sourceDetail=original;crop={zoom:1,x:0,y:0};session.dirty=true;editor.classList.remove('hidden');root.classList.add('hidden');draw();message('위치와 크기를 확인한 뒤 사진 저장을 눌러 주세요.');};
  const ref=api.doc(ui.db(),'company/main/equipmentPhotoDetails',id);
  if(file){
   // Bind immediately: a slow initial Firestore read must not swallow file selections.
   file.onchange=async()=>{
    const selected=file.files?.[0];if(session.saving||!selected)return;file.value='';const ticket=++revision;
    message('선택한 사진을 읽고 있어요…');
    try{const source=await readEquipmentPhoto(selected);if(!alive()||ticket!==revision)return;begin(source);}catch(err){if(alive()&&ticket===revision)message(err.message,true);}
   };
   edit.onclick=async()=>{if(session.saving||!valid(saved))return;const ticket=++revision;message('사진 편집 화면을 준비하고 있어요…');try{const source=await loadImage(saved);if(alive()&&ticket===revision)begin(source,saved);}catch(err){message(err.message,true);}};
   for(const [name,key,factor] of [['Zoom','zoom',1],['X','x',.01],['Y','y',.01]])find(name).oninput=e=>{if(session.saving)return;crop[key]=Number(e.target.value)*factor;draw();};
   find('Fit').onclick=()=>{crop={zoom:1,x:0,y:0};draw();};find('Center').onclick=()=>{crop.x=0;crop.y=0;draw();};
   find('Cancel').onclick=()=>{if(session.saving)return;++revision;session.dirty=false;img=null;editor.classList.add('hidden');root.classList.remove('hidden');paint(saved||photos.get(id));message('사진 변경을 취소했어요.');};
   let pointer=null;
   canvas.onpointerdown=e=>{if(session.saving||!img)return;pointer={id:e.pointerId,x:e.clientX,y:e.clientY,left:crop.x,top:crop.y};canvas.setPointerCapture(e.pointerId);};
   canvas.onpointermove=e=>{if(!pointer||pointer.id!==e.pointerId||session.saving)return;const box=canvas.getBoundingClientRect();crop.x=Math.max(-1,Math.min(1,pointer.left+(e.clientX-pointer.x)/box.width));crop.y=Math.max(-1,Math.min(1,pointer.top+(e.clientY-pointer.y)/box.height));draw();};
   canvas.onpointerup=canvas.onpointercancel=()=>{pointer=null;};
   canvas.onkeydown=e=>{if(session.saving)return;const axis={ArrowLeft:['x',-.01],ArrowRight:['x',.01],ArrowUp:['y',-.01],ArrowDown:['y',.01]}[e.key];if(axis){e.preventDefault();crop[axis[0]]=Math.max(-1,Math.min(1,crop[axis[0]]+axis[1]));draw();}};
   find('Save').onclick=async()=>{
    if(session.saving||!img)return;if(!ui.isAdmin())return message('사진 등록은 관리자만 할 수 있습니다.',true);
    controls(true);message('사진을 저장하고 있어요…');const timer=setTimeout(()=>message('연결이 지연되고 있어요. 저장 완료 안내가 나올 때까지 기다려 주세요.'),12000);
    try{const result=encodeEquipmentPhoto(img,crop);if(sourceDetail)result.image=sourceDetail;const batch=api.writeBatch(ui.db()),base={equipmentId:id,updatedBy:ui.uid(),updatedAt:api.serverTimestamp()};batch.set(api.doc(ui.db(),'company/main/equipmentPhotos',id),{...base,thumbnail:result.thumbnail});batch.set(ref,{...base,image:result.image});await batch.commit();
     saved=result.image;photos.set(id,result.thumbnail);session.dirty=false;++revision;if(alive()){editor.classList.add('hidden');root.classList.remove('hidden');paint(saved);message('사진 저장 완료 · 장비목록에 반영했어요.');}ui.render();refreshInline();
    }catch(err){message('사진 저장 실패: '+err.message+' · 위치를 유지했어요. 다시 저장해 주세요.',true);}finally{clearTimeout(timer);controls(false);}
   };
   remove.onclick=async()=>{
    if(session.saving||!ui.isAdmin()||!confirm('이 장비의 사진을 삭제할까요?'))return;controls(true);message('사진을 삭제하고 있어요…');
    try{const batch=api.writeBatch(ui.db());batch.delete(api.doc(ui.db(),'company/main/equipmentPhotos',id));batch.delete(ref);await batch.commit();++revision;saved=null;img=null;photos.delete(id);session.dirty=false;if(alive()){editor.classList.add('hidden');root.classList.remove('hidden');paint(null);message('사진을 삭제했어요.');}ui.render();refreshInline();}catch(err){message('사진 삭제 실패: '+err.message,true);}finally{controls(false);}
   };
  }
  if(valid(photos.get(id)))paint(photos.get(id));
  const ticket=revision;
  // Fetch in the background after every control is ready; ignore stale responses.
  Promise.resolve().then(()=>api.getDoc(ref)).then(snap=>{if(!alive()||ticket!==revision||session.dirty||session.saving)return;saved=snap.exists()?snap.data().image:null;paint(saved);if(edit)edit.disabled=!valid(saved);}).catch(()=>{if(alive()&&ticket===revision&&!session.dirty)message('기존 사진을 불러오지 못했어요. 새 사진 선택은 사용할 수 있습니다.',true);});
 }
 document.addEventListener('click',event=>{const target=event.target.closest('[data-equipment-photo]');if(target){event.stopPropagation();open(target.dataset.equipmentPhoto).catch(err=>alert(err.message));}});
 return {thumbnail,label,refreshInline,open,beforeClose:()=>{if(!active?.root.isConnected)return true;if(active.saving)return false;if(active.dirty&&!confirm('아직 저장하지 않은 사진 변경을 취소할까요?'))return false;active=null;return true;},reset:()=>{photos=new Map();active=null;refreshInline();},subscribe:()=>api.onSnapshot(api.collection(ui.db(),'company/main/equipmentPhotos'),snap=>{photos=new Map(snap.docs.map(d=>[d.id,d.data().thumbnail]));ui.render();refreshInline();},()=>ui.error('장비 사진을 불러오지 못했습니다.'))};
}
