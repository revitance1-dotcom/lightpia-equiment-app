export async function installAndroidBackHandler(capacitor,ui){
 if(!capacitor?.isNativePlatform?.()||capacitor.getPlatform?.()!=='android')return null;
 const app=capacitor.Plugins?.App||capacitor.registerPlugin?.('App');
 if(!app)throw Error('Android App plugin missing');
 return app.addListener('backButton',async()=>{
  // Use the actual Close button so its saving guards and discard confirmation apply.
  if(ui.hasModal()){ui.closeModal();return;}
  if(ui.isSecondaryView()){ui.goHome();return;}
  await app.exitApp();
 });
}
