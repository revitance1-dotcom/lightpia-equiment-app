import {buildEquipmentSchedule,filterEquipmentSchedule,scheduleMonthGrid,shiftScheduleMonth,shiftScheduleDay,validScheduleDay,scheduleEventsOnDay,layoutScheduleWeek} from './equipment-schedule-model.js';
import {loanQuantityText} from './equipment-units.js';
import {bindSearchInput} from './search-input.js';
export function createEquipmentSchedule(ui){
 const esc=ui.esc;let root=null,month='',selected='',query='',filter='all',events=[],focusedEvent='';
 const find=id=>root?.querySelector('#'+id);
 const labels={loan:'대여',returnDue:'반납 예정',returned:'반납 완료',reservation:'예약'};
 const style=e=>['loan','returnDue'].includes(e.kind)&&e.state==='late'?'late':e.kind;
 const label=e=>e.kind==='returnDue'&&e.state==='late'?'반납 지연':e.kind==='reservation'?(e.state==='pending'?'예약 대기':'예약 승인'):labels[e.kind];
 const party=e=>[e.team,e.person].filter(Boolean).join(' · ');
 function refresh(){
  if(!root?.isConnected||root.classList.contains('hidden'))return;
  const grid=scheduleMonthGrid(month),data=ui.data();
  events=filterEquipmentSchedule(buildEquipmentSchedule({...data,today:ui.today(),through:grid.weeks[grid.weeks.length-1][6]}),query,filter,data.equipment);
  const monthInput=find('scheduleMonth');if(monthInput.value!==month)monthInput.value=month;
  const calendar=find('scheduleCalendar'),modal=root.closest('.modal');
  const maxHeight=modal?(parseFloat(getComputedStyle(modal).maxHeight)||innerHeight*.92):innerHeight*.92;
  const top=modal?calendar.getBoundingClientRect().top-modal.getBoundingClientRect().top+modal.scrollTop:300;
  const weekHeight=Math.max(60,Math.min(145,Math.floor((maxHeight-top-44)/grid.weeks.length)-4)),barHeight=innerWidth<700?18:23;
  const lanes=Math.max(1,Math.min(3,Math.floor((weekHeight-40)/(barHeight+2))));
  root.style.setProperty('--schedule-week-height',weekHeight+'px');root.style.setProperty('--schedule-bar-height',barHeight+'px');
  calendar.innerHTML='<div class="schedule-weekdays" aria-hidden="true">'+['일','월','화','수','목','금','토'].map((d,i)=>`<span class="${i===0?'sunday':i===6?'saturday':''}">${d}</span>`).join('')+'</div>'+grid.weeks.map(days=>{
   const {bars,hidden}=layoutScheduleWeek(events,days,lanes);
   return `<div class="schedule-week"><div class="schedule-week-days">${days.map((day,i)=>{const count=scheduleEventsOnDay(events,day).length;return `<button type="button" class="schedule-day ${day.slice(0,7)!==month?'outside-month':''} ${day===ui.today()?'is-today':''} ${day===selected?'is-selected':''} ${i===0?'sunday':i===6?'saturday':''}" data-schedule-day="${day}" aria-label="${esc(day+' · '+count+'건 · 상세 보기')}" aria-pressed="${day===selected}" ${day===ui.today()?'aria-current="date"':''}><span class="schedule-day-number">${Number(day.slice(-2))}</span>${hidden[day]?`<span class="schedule-more">+${hidden[day]}건</span>`:''}</button>`;}).join('')}</div><div class="schedule-week-bars">${bars.map(b=>`<button type="button" class="schedule-event schedule-${style(b.event)} ${b.continuesBefore?'continues-before':''} ${b.continuesAfter?'continues-after':''}" style="grid-column:${b.column}/span ${b.span};grid-row:${b.lane+1}" data-schedule-event="${esc(b.event.id)}" data-schedule-pick="${b.start<grid.first&&b.end>=grid.first?grid.first:b.start}" title="${esc(label(b.event)+' · '+party(b.event)+' · '+b.event.start+' ~ '+b.event.end)}" aria-label="${esc(label(b.event)+' · '+party(b.event)+' · '+b.event.items.length+'종 · 상세 보기')}"><span>${esc(party(b.event))}</span></button>`).join('')}</div></div>`;
  }).join('');
  find('scheduleMonthStatus').textContent=`${Number(month.slice(0,4))}년 ${Number(month.slice(5))}월 · 날짜를 누르면 해당 날짜의 전체 장비를 확인합니다.`;
  find('scheduleFilters').querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(filter===b.dataset.scheduleFilter)));
  renderDay();
 }
 function renderDay(){
  const rows=scheduleEventsOnDay(events,selected),byKind=kind=>rows.filter(e=>e.kind===kind).length;
  find('scheduleDayTitle').textContent=`${selected.replaceAll('-','.')} 장비 일정`;
  find('scheduleDayCount').textContent=rows.length?`대여 ${byKind('loan')} · 반납 예정 ${byKind('returnDue')} · 반납 완료 ${byKind('returned')} · 예약 ${byKind('reservation')}건`:'해당 날짜에 표시할 장비 일정이 없습니다.';
  find('scheduleDayRows').innerHTML=rows.map(e=>{
   const status=e.kind==='loan'?(e.state==='returned'?'대여 이력':e.state==='late'?'반납 지연 · 미반납':selected===e.start?'대여 · 출고':'대여 중'):label(e);
   const range=e.kind==='reservation'?`예약 ${e.start} ~ ${e.end}`:e.kind==='loan'?`대여 ${e.start} · 반납 예정 ${e.plannedEnd||'미정'}${e.actualReturn?' · 실제 반납 '+e.actualReturn:''}`:`대여 ${e.loanStart} · ${e.kind==='returned'?'실제 반납':'반납 예정'} ${e.start}`;
   const missing=e.missingReturnDate?'<p class="meta">이전 반납 기록에 실제 반납 날짜가 없어 반납 완료 일정에는 표시하지 않습니다. 대여 막대는 당시 예정일까지만 표시합니다.</p>':'';
   return `<article class="schedule-detail ${focusedEvent===e.id?'schedule-detail-selected':''}" data-schedule-detail="${esc(e.id)}"><div class="schedule-detail-head"><span class="schedule-badge schedule-${style(e)}">${esc(status)}</span><strong>${esc(e.team)}</strong><span class="meta">${esc(e.person||'담당자 미기록')} · ${esc(e.group)}</span></div><p class="meta">${esc(range)}${e.kind==='reservation'?' · 남은 예약 장비':''}</p>${missing}${e.openEnd?'<p class="meta">반납 예정일이 없어 미반납 상태로 표시합니다. 실제 반납 여부를 확인해 주세요.</p>':''}<div class="schedule-equipment-list">${e.items.map(i=>`<div class="schedule-equipment"><div>${ui.equipmentLabel?ui.equipmentLabel(i.id,`<b>${esc(i.name)}</b>`,'review'):`<b>${esc(i.name)}</b>`}${i.note?`<small class="meta">${esc(i.note)}</small>`:''}</div><strong>${esc(loanQuantityText(i.qty,i))}</strong></div>`).join('')}</div></article>`;
  }).join('')||'<div class="empty">날짜·검색어·일정 구분을 바꿔 확인해 주세요.</div>';
 }
 function pick(day,eventId='',scroll=true){
  if(!validScheduleDay(day))return;
  selected=day;focusedEvent=eventId;
  if(day.slice(0,7)!==month)month=day.slice(0,7);
  refresh();
  if(scroll){const item=[...find('scheduleDayRows').querySelectorAll('[data-schedule-detail]')].find(n=>n.dataset.scheduleDetail===eventId);(item||find('scheduleDayDetails')).scrollIntoView({behavior:'smooth',block:'nearest'});}
 }
 function mount(target){
  if(root===target&&root.isConnected){refresh();return;}
  root=target;month=ui.today().slice(0,7);selected=ui.today();query='';filter='all';focusedEvent='';
  root.innerHTML=`<div class="schedule-intro"><p>팀별 장비 이동과 사용 기간을 한눈에 확인하세요.</p><div class="schedule-legend"><span class="schedule-badge schedule-loan">대여</span><span class="schedule-badge schedule-returnDue">반납 예정</span><span class="schedule-badge schedule-returned">반납 완료</span><span class="schedule-badge schedule-reservation">예약</span><span class="schedule-badge schedule-late">반납 지연</span></div></div><div class="schedule-toolbar"><button type="button" class="secondary small" data-schedule-month="-1" aria-label="이전 달">‹</button><label class="schedule-month-label"><span class="sr-only">표시할 월</span><input id="scheduleMonth" type="month" min="1900-01" max="2199-12" value="${month}" aria-label="표시할 월"></label><button type="button" class="secondary small" data-schedule-month="1" aria-label="다음 달">›</button><button type="button" class="secondary small" id="scheduleToday">오늘</button></div><input id="scheduleSearch" class="search" placeholder="팀명 · 담당자 · 장비명 검색" aria-label="장비 스케줄 검색"><div id="scheduleFilters" class="schedule-filters" role="group" aria-label="일정 구분">${[['all','전체'],['loan','대여'],['return','반납'],['reservation','예약']].map(([id,text])=>`<button type="button" class="small secondary" data-schedule-filter="${id}" aria-pressed="${id==='all'}">${text}</button>`).join('')}</div><p id="scheduleMonthStatus" class="meta" aria-live="polite"></p><div id="scheduleCalendar" class="schedule-calendar" aria-label="월간 장비 일정"></div><p class="schedule-help meta">막대는 대여·예약 기간, 반납은 예정일 또는 실제 완료일입니다. 같은 팀·담당자·기간의 대여 장비는 묶어서 표시합니다. +건을 포함해 날짜를 누르면 전체 일정이 아래에 나옵니다. 예약은 자동 출고되지 않습니다.</p><section id="scheduleDayDetails" class="schedule-day-details" aria-label="선택한 날짜의 장비 상세"><h3 id="scheduleDayTitle"></h3><p id="scheduleDayCount" class="meta" role="status" aria-live="polite"></p><div id="scheduleDayRows"></div></section>`;
  root.addEventListener('click',e=>{
   const prev=e.target.closest('[data-schedule-month]'),f=e.target.closest('[data-schedule-filter]'),bar=e.target.closest('[data-schedule-event]'),day=e.target.closest('[data-schedule-day]');
   if(prev){const next=shiftScheduleMonth(month,Number(prev.dataset.scheduleMonth));if(next<'1900-01'||next>'2199-12')return;month=next;selected=month+'-01';focusedEvent='';refresh();}
   else if(f){filter=f.dataset.scheduleFilter;focusedEvent='';refresh();}
   else if(bar)pick(bar.dataset.schedulePick,bar.dataset.scheduleEvent);
   else if(day)pick(day.dataset.scheduleDay);
   else if(e.target.closest('#scheduleToday')){month=ui.today().slice(0,7);pick(ui.today(),'',false);}
  });
  find('scheduleMonth').addEventListener('change',e=>{const next=e.target.value;if(!/^\d{4}-\d{2}$/.test(next)||next<'1900-01'||next>'2199-12'||!validScheduleDay(next+'-01')){e.target.value=month;return;}month=next;selected=month+'-01';focusedEvent='';refresh();});
  bindSearchInput(find('scheduleSearch'),value=>{query=value;focusedEvent='';refresh();});
  root.addEventListener('keydown',e=>{const day=e.target.closest('[data-schedule-day]'),step={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7}[e.key];if(!day||!step)return;e.preventDefault();const next=shiftScheduleDay(day.dataset.scheduleDay,step);if(next<'1900-01-01'||next>'2199-12-31')return;pick(next,'',false);root.querySelector('[data-schedule-day="'+next+'"]')?.focus();});
  refresh();
 }
 let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(refresh,120);});
 return {mount,refresh};
}
