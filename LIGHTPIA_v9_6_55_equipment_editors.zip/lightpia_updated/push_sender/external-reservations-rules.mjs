import fs from 'node:fs';
export function patchExternalReservationRules(source){
 if(source.includes('LNS_EXTERNAL_RESERVATIONS_V1'))return source;
 const start=source.indexOf('match /company/main/reservations/{reservationId}'),end=source.indexOf('match /company/main/repairs/',start);
 if(start<0||end<0)throw Error('Unexpected reservation rule layout');
 let block=source.slice(start,end);
 const fields="'status','createdAt','updatedAt'])";
 const from=block.indexOf('     && request.resource.data.projectId is string'),to=block.indexOf('     && request.resource.data.startDate is string',from);
 if(!block.includes(fields)||from<0||to<0||!block.slice(from,to).includes("profile().get('teamId','')"))throw Error('Unexpected reservation create rule');
 block=block.slice(0,from)+'     && lnsReservationParty(request.resource.data)\n'+block.slice(to);
 block=block.replace(fields,"'status','createdAt','updatedAt','rentalType','externalTeam','externalPerson'])");
 return source.slice(0,start)+fs.readFileSync(new URL('./external-reservations.rules',import.meta.url),'utf8')+'  '+block+source.slice(end);
}
