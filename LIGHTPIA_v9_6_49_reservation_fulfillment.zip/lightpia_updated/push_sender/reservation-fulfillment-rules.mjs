import fs from 'node:fs';
export function patchReservationFulfillmentRules(source){
 if(source.includes('LNS_RESERVATION_FULFILLMENT_V1'))return source;
 const marker='match /company/main/reservations/{reservationId}';if(!source.includes(marker))throw Error('Reservation rule block missing');source=source.replace(marker,fs.readFileSync(new URL('./reservation-fulfillment.rules',import.meta.url),'utf8')+'\n  '+marker);
 const start=source.indexOf('match /company/main/loans/{loanId}'),end=source.indexOf('// LNS_EXTERNAL_RESERVATIONS_V1',start);let loan=source.slice(start,end);
 loan=loan.replace("'unit','unitsPerBox'])", "'unit','unitsPerBox','reservationId','reservationItemIndex'])");
 loan=loan.replace('&& validTeamForCreate(request.resource.data)',"&& (!request.resource.data.keys().hasAny(['reservationId','reservationItemIndex']) || lnsReservationLoanMatches(loanId,request.resource.data))\n    && validTeamForCreate(request.resource.data)");loan=loan.replace('allow create: if (admin() || activeTeamMember())',"allow create: if !request.resource.data.keys().hasAny(['reservationId','reservationItemIndex']) && (admin() || activeTeamMember())");loan=loan.replace('   allow update:', '   allow create: if lnsFulfillmentLoanCreate(loanId);\n   allow update:');source=source.slice(0,start)+loan+source.slice(end);
 const a=source.indexOf(marker),b=source.indexOf('match /company/main/repairs/',a);let reservation=source.slice(a,b);reservation=reservation.replace('   allow delete: if admin();','   allow update: if lnsFulfillmentUpdate(reservationId);\n   allow delete: if admin();');return source.slice(0,a)+reservation+source.slice(b);
}
