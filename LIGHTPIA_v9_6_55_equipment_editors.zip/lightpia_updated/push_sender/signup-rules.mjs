// Only relax the stale mandatory-team predicate; preserve all other access rules.
export function patchSignupRules(source){
 const anchor='match /joinRequests/{uid}';
 const start=source.indexOf(anchor),end=source.indexOf('\n  match ',start+anchor.length);
 if(start<0||end<0||source.indexOf(anchor,start+anchor.length)>=0)throw Error('Unexpected signup rules layout');
 let block=source.slice(start,end);
 const optional='request.resource.data.requestedTeam is string && request.resource.data.requestedTeam.size() <= 100';
 const required='request.resource.data.requestedTeam is string && request.resource.data.requestedTeam.size() > 0 && request.resource.data.requestedTeam.size() <= 100';
 if(block.includes(required))block=block.replace(required,optional);
 else if(!block.includes(optional))throw Error('Unexpected requestedTeam validation; review required');
 if(!block.includes('LNS_OPTIONAL_SIGNUP_TEAM_V1'))block=block.replace(anchor+' {',anchor+' { // LNS_OPTIONAL_SIGNUP_TEAM_V1');
 return source.slice(0,start)+block+source.slice(end);
}
