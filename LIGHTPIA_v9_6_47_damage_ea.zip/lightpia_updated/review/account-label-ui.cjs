const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/www/app.js','utf8');
const code=s.slice(s.indexOf('function subscribe(){'),s.indexOf('function initConfig('));
const html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{for(const width of [320,393,768]){
 const page=await browser.newPage({viewport:{width,height:900}});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.setContent(html);await page.addScriptTag({content:fs.readFileSync(path.resolve(__dirname,'../www/equipment-units.js'),'utf8').replace(/export /g,'')});
 await page.addScriptTag({content:fs.readFileSync(root+'/www/loan-groups.js','utf8').replace(/export /g,'')});
 await page.addScriptTag({content:`const $=id=>document.getElementById(id),ID_DOMAIN='accounts.lightpia.internal';
 let ready=true,adminMode=false,currentUser={uid:'staff',email:'test@accounts.lightpia.internal'},teamName='본팀',teamId='A',teamList=[],projects=[],unsubs=[],callbacks={};
 const isAdmin=()=>adminMode,db={},auth={},equipmentPhotos={subscribe:()=>()=>{}},crewBoard={subscribe:()=>[]},signOut=async()=>{},clearSubs=()=>{unsubs=[]},render=()=>{},renderProjects=()=>{},renderTeamAdmin=()=>{},renderReservations=()=>{},updateAdminPushPanel=()=>{};
 const eqCol=()=> 'equipment',loanCol=()=> 'loans',repairCol=()=> 'repairs',reservationCol=()=> 'reservations';
 const doc=(db,...args)=>args.join('/'),collection=(db,...args)=>args.join('/'),query=x=>x,orderBy=()=>{};
 function onSnapshot(ref,callback){callbacks[ref]=callback;return ()=>{}}
 function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}
 function status(label,ok=false){$('connection').textContent=label;$('connection').className='status'+(ok?' ok':'');}
 ${code}
 show('app',true);show('loginGate',false);show('view-home',false);show('view-settings',true);
 updateAccountUI(currentUser);status('본팀 · 공용 재고 연결됨',true);subscribe();`});
 assert((await page.locator('#accountInfo').textContent()).startsWith('본팀'));
 await page.evaluate(()=>callbacks['teams/A']({id:'A',exists:()=>true,data:()=>({name:'본팀',projectId:'P',active:true})}));
 await page.evaluate(()=>callbacks.projects({docs:[{id:'P',data:()=>({name:'언내추럴',active:true})}]}));
 assert.equal(await page.locator('#connection').textContent(),'언내추럴 · 본팀 · 공용 재고 연결됨');assert.equal(await page.locator('#accountInfo').textContent(),'언내추럴 · 본팀 · test · 회사 공용 재고');
 // Metadata can arrive in the reverse order or change later without re-login.
 await page.evaluate(()=>{teamList=[];projects=[];callbacks.projects({docs:[{id:'P',data:()=>({name:'새 작품',active:true})}]});callbacks['teams/A']({id:'A',exists:()=>true,data:()=>({name:'본팀',projectId:'P',active:true})});});
 assert((await page.locator('#connection').textContent()).startsWith('새 작품 · 본팀'));
 await page.evaluate(()=>{status('장비 읽기 오류');callbacks.projects({docs:[{id:'P',data:()=>({name:'갱신된 작품',active:true})}]});});
 assert.equal(await page.locator('#connection').textContent(),'장비 읽기 오류');assert((await page.locator('#accountInfo').textContent()).startsWith('갱신된 작품 · 본팀'));
 await page.evaluate(()=>{adminMode=true;refreshAccountIdentity();status(accountTeamLabel()+' · 공용 재고 연결됨',true);});assert((await page.locator('#accountInfo').textContent()).startsWith('관리자 ·'));
 await page.evaluate(()=>{adminMode=false;teamId='';teamName='대기 직원';refreshAccountIdentity();});assert((await page.locator('#accountInfo').textContent()).startsWith('대기 직원 ·'));
 await page.evaluate(()=>{teamId='A';teamName='본팀';projects=[{id:'P',name:'VERY_LONG_PROJECT_NAME_WITHOUT_SPACES_'.repeat(3)}];refreshAccountIdentity();});
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert.equal(errors.length,0,errors.join('\n'));
 console.log('PASS account identity',width,'actual team/project subscription callbacks, both arrival orders, header and Settings labels, live rename, preserve errors, admin/waiting fallbacks, long names without overflow');await page.close();
}}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
