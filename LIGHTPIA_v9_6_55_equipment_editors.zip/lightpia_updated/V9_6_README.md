V9.6 직원 아이디 가입/로그인
- 새 직원은 이메일 없이 아이디(4~20자)와 비밀번호로 가입 신청합니다.
- 기존 Firebase 이메일 계정은 이메일을 입력하여 계속 로그인할 수 있습니다.
- 내부적으로 아이디@accounts.lightpia.internal 이메일을 Firebase Authentication에 사용합니다.
- 기존 Firebase 프로젝트와 Firestore 데이터, 관리자 UID는 유지됩니다.
- 기존 Firebase Authentication 이메일/비밀번호 로그인 공급자를 활성화한 상태여야 합니다.
- 관리자 승인 흐름은 이전과 동일합니다.
