import admin from 'firebase-admin';
import {apply18kTagCorrection} from './tag-correction-model.mjs';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');
if(account?.project_id!=='light-4e07d')throw Error('Unexpected project');
admin.initializeApp({credential:admin.credential.cert(account)});
await apply18kTagCorrection(admin.firestore(),()=>admin.firestore.FieldValue.serverTimestamp());
