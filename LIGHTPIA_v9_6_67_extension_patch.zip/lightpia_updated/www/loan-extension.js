import {loadCapacitySnapshot,readCapacityLock,writeCapacityLock,checkCapacity} from './availability-model.js';
export function validateExtension(loan,date,day){
 if(loan.status!=='active')throw Error('이미 반납된 대여입니다.');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date<day||date<loan.loanDate||(loan.dueDate&&date<=loan.dueDate))throw Error('오늘 이후이며 기존 반납예정일보다 늦은 날짜를 선택해 주세요.');
}
export async function extendLoan(api,db,id,date,day,canHandle,expectedDate){
 const path=(kind,key)=>api.doc(db,'company','main',kind,key),ref=path('loans',id);
 const initial=await api.getDoc(ref);if(!initial.exists())throw Error('삭제된 대여입니다.');
 const equipmentId=initial.data().equipmentId;
 for(let attempt=0;attempt<5;attempt++){
  const snapshot=await loadCapacitySnapshot(api,db,[equipmentId],day);
  try{return await api.runTransaction(db,async tx=>{
   const lock=await readCapacityLock(api,db,tx,equipmentId,snapshot),s=await tx.get(ref),eq=await tx.get(path('equipment',equipmentId));
   if(!s.exists()||!eq.exists())throw Error('삭제된 대여 또는 장비입니다.');
   const loan={...s.data(),id};if(!canHandle(loan))throw Error('이 대여를 연장할 권한이 없습니다.');
   if(loan.equipmentId!==equipmentId||loan.dueDate!==expectedDate)throw Error('대여 정보가 변경되었습니다. 다시 열어 확인해 주세요.');
   validateExtension(loan,date,day);
   // Replace this loan in the capacity snapshot without counting it as unknown stock.
   const others=snapshot.loans.filter(l=>l.id!==id);
   checkCapacity({...eq.data(),id:equipmentId,loaned:Math.max(0,Number(eq.data().loaned||0)-Number(loan.quantity))},{...snapshot,loans:others},loan.quantity,day,date,day);
   writeCapacityLock(api,tx,lock,id,'extension');
   tx.update(ref,{dueDate:date,previousDueDate:loan.dueDate||'',extendedBy:api.uid,extendedAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});
  });}catch(e){if(!e.capacityRetry||attempt===4)throw e;}
 }
}
