const assert=require('assert');
(async()=>{const {compareEquipment,orderedKeys}=await import('../www/display-order.js');
 const sorted=['storm 400x','STORM 1200X','storm 600x','ARRI M18','ARRI M90','18K PAR','12K PAR'].map(name=>({name})).sort(compareEquipment).map(e=>e.name);
 assert.deepEqual(sorted,['18K PAR','12K PAR','ARRI M90','ARRI M18','STORM 1200X','storm 600x','storm 400x']);
 const rows=[{name:'STORM 400X'},{name:'STORM 600X'},{name:'STORM 400X'}];const before=JSON.stringify(rows);[...rows].sort(compareEquipment);assert.equal(JSON.stringify(rows),before);
 assert.deepEqual(orderedKeys(['전체','LED','HMI','기타'],['LED','삭제된분류','전체','LED']),['LED','전체','HMI','기타']);
 assert.deepEqual(orderedKeys(['a','b'],null),['a','b']);
 console.log('PASS natural names, series numeric descending, deterministic duplicate names, immutable input and new/deleted category reconciliation');
})().catch(e=>{console.error(e);process.exit(1)});
