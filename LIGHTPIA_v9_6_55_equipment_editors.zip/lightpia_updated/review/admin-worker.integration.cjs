const assert=require('assert'),admin=require('firebase-admin');
(async()=>{
 if(!process.env.FIRESTORE_EMULATOR_HOST||!process.env.FIREBASE_AUTH_EMULATOR_HOST)throw Error('Both emulators required');
 const {processAdminOperations,ADMIN_UID}=await import('../push_sender/admin-core.mjs');
 admin.initializeApp({projectId:'demo-lightpia'});const db=admin.firestore(),auth=admin.auth(),FieldValue=admin.firestore.FieldValue,Timestamp=admin.firestore.Timestamp,ctx={db,auth,FieldValue,Timestamp};
 // Remove only emulator fixture queues left by rule tests.
 const old=await db.collection('adminOperations').get();for(const d of old.docs)await d.ref.delete();
 const op=async(type,id,overrides={})=>{const ref=db.collection('adminOperations').doc(type+'_'+id);await ref.set({type,targetId:id,targetName:'테스트',createdBy:ADMIN_UID,status:'pending',createdAt:FieldValue.serverTimestamp(),...overrides});return ref;};
 await auth.createUser({uid:ADMIN_UID,email:'admin@example.test',password:'test-password'});
 const uid='delete-employee';await auth.createUser({uid,email:'employee@example.test',password:'test-password'});await db.doc('members/'+uid).set({role:'team',active:true,displayName:'테스트 직원'});await db.doc('joinRequests/'+uid).set({name:'테스트 직원'});
 await db.doc('company/main/loans/history').set({ownerUid:uid,status:'active',quantity:2,team:'보존할 팀'});await db.doc('company/main/reservations/history').set({ownerUid:uid,status:'approved',note:'보존할 기록'});
 const userOp=await op('delete_user',uid);await processAdminOperations(ctx);assert.equal((await userOp.get()).data().status,'completed');await assert.rejects(auth.getUser(uid),e=>e.code==='auth/user-not-found');assert(!(await db.doc('members/'+uid).get()).exists);assert(!(await db.doc('joinRequests/'+uid).get()).exists);assert.equal((await db.doc('company/main/loans/history').get()).data().quantity,2);assert.equal((await db.doc('company/main/reservations/history').get()).data().note,'보존할 기록');
 await userOp.update({status:'pending'});await processAdminOperations(ctx);assert.equal((await userOp.get()).data().status,'completed');
 const self=await op('delete_user',ADMIN_UID);await processAdminOperations(ctx);assert.equal((await self.get()).data().status,'failed');assert.equal((await auth.getUser(ADMIN_UID)).uid,ADMIN_UID);
 await db.doc('members/spoof-target').set({role:'team',active:true});const spoof=await op('delete_user','spoof-target',{createdBy:'not-admin'});await processAdminOperations(ctx);assert.equal((await spoof.get()).data().status,'failed');assert((await db.doc('members/spoof-target').get()).exists);
 await db.doc('projects/ended').set({name:'종료 작품',active:false});await db.doc('teams/ended-team').set({projectId:'ended',active:true,name:'보존 팀'});await db.doc('company/main/loans/project-history').set({projectId:'ended',teamId:'ended-team',status:'returned',quantity:5});
 const projectOp=await op('delete_project','ended');await processAdminOperations(ctx);assert.equal((await projectOp.get()).data().status,'completed');assert(!(await db.doc('projects/ended').get()).exists);assert.equal((await db.doc('teams/ended-team').get()).data().active,false);assert.equal((await db.doc('company/main/loans/project-history').get()).data().quantity,5);
 await db.doc('projects/still-active').set({active:true});const active=await op('delete_project','still-active');await processAdminOperations(ctx);assert.equal((await active.get()).data().status,'failed');assert((await db.doc('projects/still-active').get()).exists);
 await db.doc('projects/blocked').set({active:false});await db.doc('company/main/loans/outstanding').set({projectId:'blocked',status:'active'});const blocked=await op('delete_project','blocked');await processAdminOperations(ctx);assert.equal((await blocked.get()).data().status,'failed');assert((await db.doc('projects/blocked').get()).exists);
 await db.doc('projects/booked').set({active:false});await db.doc('company/main/reservations/future').set({projectId:'booked',status:'approved',endDate:'2099-01-01'});const booked=await op('delete_project','booked');await processAdminOperations(ctx);assert.equal((await booked.get()).data().status,'failed');
 await db.doc('projects/legacy').set({active:false});await db.doc('teams/legacy-team').set({projectId:'legacy',active:false});await db.doc('company/main/loans/legacy-loan').set({teamId:'legacy-team',status:'active'});const legacy=await op('delete_project','legacy');await processAdminOperations(ctx);assert.equal((await legacy.get()).data().status,'failed');
 // A crashed Auth deletion is completed on retry without deleting any historical records.
 await db.doc('members/already-gone').set({role:'team',active:false});const partial=await op('delete_user','already-gone');await processAdminOperations(ctx);assert.equal((await partial.get()).data().status,'completed');assert(!(await db.doc('members/already-gone').get()).exists);
 // Team deletion preserves the running project, sibling team, history and employee account.
 await db.doc('projects/dash').set({active:true,name:'대시'});
 await db.doc('teams/dash-main').set({active:true,name:'대시',projectId:'dash'});
 await db.doc('teams/dash-b').set({active:false,name:'B팀',projectId:'dash'});
 await db.doc('members/b-employee').set({role:'team',active:true,teamId:'dash-b',projectId:'dash',teamName:'B팀'});
 await db.doc('company/main/loans/b-returned').set({teamId:'dash-b',projectId:'dash',team:'B팀',status:'returned',quantity:3});
 const bt=await op('delete_team','dash-b');await processAdminOperations(ctx);assert.equal((await bt.get()).data().status,'completed');
 assert(!(await db.doc('teams/dash-b').get()).exists);assert.equal((await db.doc('teams/dash-main').get()).data().active,true);assert.equal((await db.doc('projects/dash').get()).data().active,true);
 const employee=(await db.doc('members/b-employee').get()).data();assert.equal(employee.active,true);assert.equal(employee.teamName,'대기 직원');assert(!employee.teamId);assert(!employee.projectId);
 assert.equal((await db.doc('company/main/loans/b-returned').get()).data().quantity,3);
 await bt.update({status:'pending'});await processAdminOperations(ctx);assert.equal((await bt.get()).data().status,'completed');
 for(const mode of ['active','loan','reservation']){
 const id='blocked-team-'+mode;await db.doc('teams/'+id).set({active:mode==='active',projectId:'dash'});
 if(mode==='loan')await db.doc('company/main/loans/'+id).set({teamId:id,status:'active'});
 if(mode==='reservation')await db.doc('company/main/reservations/'+id).set({teamId:id,status:'approved',endDate:'2099-01-01'});
 const request=await op('delete_team',id);await processAdminOperations(ctx);assert.equal((await request.get()).data().status,'failed');assert((await db.doc('teams/'+id).get()).exists);
 }
 console.log('PASS: real Auth/profile deletion, preserved loan/reservation history, idempotent retry, admin/spoof protection, project deletion and team preservation, active/loan/reservation/legacy guards');await admin.app().delete();
})().catch(e=>{console.error(e);process.exit(1)});
