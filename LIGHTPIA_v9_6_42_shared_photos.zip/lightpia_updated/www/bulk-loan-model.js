// Three equipment/loan pairs leave room for member, team and project rule reads.
// Each pair is atomic; stable loan IDs make retry after an uncertain commit safe.
export async function submitBulkLoans(api,db,items,payload,onProgress=()=>{}) {
 if(!items.length||items.length>20||new Set(items.map(x=>x.equipmentId)).size!==items.length)throw Error('한 번에 1~20종을 선택해 주세요.');
 if(items.some(x=>!Number.isInteger(x.quantity)||x.quantity<1))throw Error('대여 수량은 1 이상의 정수여야 합니다.');
 const fields=['equipmentId','quantity','ownerUid','team','teamId','projectId','person','loanDate','dueDate','note','rentalType','equipmentGroup','externalTeam','externalPerson','projectName'];
 let completed=0;
 for(let start=0;start<items.length;start+=3){
  const chunk=items.slice(start,start+3);
  await api.runTransaction(db,async tx=>{
   const rows=[];
   for(const item of chunk){
    const loanRef=api.doc(db,'company/main/loans',item.loanId),eqRef=api.doc(db,'company/main/equipment',item.equipmentId);
    const loan=await tx.get(loanRef),eq=await tx.get(eqRef);
    const data={...payload,equipmentId:item.equipmentId,quantity:item.quantity};
    if(loan.exists()){
     const old=loan.data();
     if(!fields.every(k=>(old[k]??'')===(data[k]??'')))throw Error('이미 저장된 대여 건입니다. 대여 내역에서 확인해 주세요.');
     rows.push({saved:true});continue;
    }
    if(!eq.exists())throw Error('삭제된 장비가 있습니다.');
    const stock=eq.data(),available=Number(stock.total||0)-Number(stock.loaned||0)-Number(stock.repairing||0)-Number(stock.brokenStock||0);
    if(Number(stock.total||0)!==0&&item.quantity>available)throw Error(`${stock.name}: 가용 ${available}개, 신청 ${item.quantity}개`);
    rows.push({loanRef,eqRef,stock,data});
   }
   for(const row of rows){
    if(row.saved)continue;
    tx.update(row.eqRef,{loaned:Number(row.stock.loaned||0)+row.data.quantity,lastLoanId:row.loanRef.id});
    tx.set(row.loanRef,{...row.data,equipmentName:row.stock.name,status:'active',createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});
   }
  });
  completed+=chunk.length;onProgress(chunk,completed,items.length);
 }
 return completed;
}
