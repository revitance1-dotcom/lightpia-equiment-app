import {createEquipmentSchedule} from './equipment-schedule.js';
import {validScheduleDay} from './equipment-schedule-model.js';

// Reuse the read-only schedule; dates are committed only by the Apply button.
export function createScheduleDatePicker(ui){
 const pairs=[['cartDate','cartDue','대여일','반납 예정일'],['reserveStart','reserveEnd','시작일','종료일'],['fulfillmentDate','fulfillmentDue','실제 출고일','반납 예정일']];
 let layer=null,calendar=null,returnFocus=null,parent=null,parentWasInert=false,previousOverflow='',keyHandler=null;
 const find=id=>layer?.querySelector('#'+id);
 function close(restoreFocus=true){
  if(!layer)return false;
  calendar?.destroy();calendar=null;layer.remove();layer=null;
  if(parent?.isConnected)parent.inert=parentWasInert;
  document.body.style.overflow=previousOverflow;
  document.removeEventListener('keydown',keyHandler,true);
  if(restoreFocus&&returnFocus?.isConnected)returnFocus.focus({preventScroll:true});
  parent=null;return true;
 }
 function open(pair,trigger){
  if(layer||trigger.disabled)return;
  const [startId,endId,startLabel,endLabel]=pair,startInput=document.getElementById(startId),endInput=document.getElementById(endId);
  if(!startInput||!endInput||startInput.disabled||endInput.disabled)return;
  let start=validScheduleDay(startInput.value)?startInput.value:ui.today(),end=validScheduleDay(endInput.value)?endInput.value:start,active=trigger.id===endId?'end':'start';
  const min=startInput.min||startInput.dataset.scheduleMin||'';
  if(min&&start<min)start=min;if(end<start)end=start;
  returnFocus=trigger;parent=trigger.closest('.modalback');parentWasInert=parent?.inert||false;if(parent)parent.inert=true;
  previousOverflow=document.body.style.overflow;document.body.style.overflow='hidden';
  layer=document.createElement('div');layer.className='modalback schedule-picker-backdrop';layer.id='scheduleDatePickerBackdrop';
  layer.innerHTML=`<div class="modal stock-modal schedule-picker-modal" role="dialog" aria-modal="true" aria-labelledby="schedulePickerTitle"><div class="modalhead"><h2 id="schedulePickerTitle">일정 보며 날짜 선택</h2><button type="button" class="small secondary" data-picker-cancel>취소</button></div><p class="meta">${ui.esc(startLabel)}·${ui.esc(endLabel)}을 선택하세요. 기존 일정의 날짜를 눌러 장비도 확인할 수 있습니다.</p><div class="schedule-range-controls"><button type="button" data-range-part="start"><span>${ui.esc(startLabel)}</span><strong id="scheduleRangeStart"></strong></button><button type="button" data-range-part="end"><span>${ui.esc(endLabel)}</span><strong id="scheduleRangeEnd"></strong></button></div><p class="meta" id="scheduleRangeStatus" role="status" aria-live="polite"></p><section id="schedulePickerCalendar" aria-label="기간 선택 장비 스케줄"></section><footer class="schedule-picker-actions"><button type="button" class="secondary" data-picker-cancel>취소</button><button type="button" id="scheduleRangeApply">기간 적용</button></footer></div>`;
  document.body.append(layer);
  function renderRange(){
   find('scheduleRangeStart').textContent=start.replaceAll('-','.');find('scheduleRangeEnd').textContent=end.replaceAll('-','.');
   layer.querySelectorAll('[data-range-part]').forEach(b=>{const selected=b.dataset.rangePart===active;b.classList.toggle('secondary',!selected);b.setAttribute('aria-pressed',String(selected));});
   find('scheduleRangeStatus').textContent=(active==='start'?startLabel:endLabel)+' 선택 중 · '+start+' ~ '+end+' · 반납일 당일도 포함';
   calendar?.setRange({start,end,min});
  }
  calendar=createEquipmentSchedule(ui);
  calendar.mount(find('schedulePickerCalendar'),{selected:active==='start'?start:end,range:{start,end,min},onDaySelect:day=>{
   if(active==='start'){start=day;if(end<start)end=start;active='end';}
   else{end=day;if(end<start)start=end;}
   renderRange();
  }});
  renderRange();
  layer.addEventListener('click',event=>{
   if(event.target===layer||event.target.closest('[data-picker-cancel]')){close();return;}
   const part=event.target.closest('[data-range-part]');if(part){active=part.dataset.rangePart;renderRange();return;}
   if(event.target.closest('#scheduleRangeApply')){
    if(!validScheduleDay(start)||!validScheduleDay(end)||end<start||(min&&start<min))return;
    // Set both first: the original start-date handler may clamp the end date.
    startInput.value=start;endInput.value=end;
    startInput.dispatchEvent(new Event('input',{bubbles:true}));startInput.dispatchEvent(new Event('change',{bubbles:true}));
    endInput.dispatchEvent(new Event('input',{bubbles:true}));endInput.dispatchEvent(new Event('change',{bubbles:true}));close();
   }
  });
  keyHandler=event=>{
   if(event.key==='Escape'){event.preventDefault();event.stopImmediatePropagation();close();return;}
   if(event.key!=='Tab')return;
   const focusable=[...layer.querySelectorAll('button:not(:disabled),input:not(:disabled),[tabindex="0"]')].filter(el=>el.getClientRects().length),first=focusable[0],last=focusable.at(-1);
   if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
  };
  document.addEventListener('keydown',keyHandler,true);
  layer.querySelector('[data-range-part="'+active+'"]').focus({preventScroll:true});
 }
 function bind(){
  for(const pair of pairs)for(const id of pair.slice(0,2)){
   const input=document.getElementById(id);if(!input||input.dataset.scheduleBound)continue;
   input.dataset.scheduleBound='true';input.dataset.scheduleMin=input.min||'';
   input.type='text';input.readOnly=true;input.classList.add('schedule-date-input');input.setAttribute('role','button');input.setAttribute('aria-haspopup','dialog');
   input.setAttribute('aria-label',pair[id===pair[0]?2:3]+' · 장비 스케줄에서 선택');
   input.addEventListener('click',event=>{event.preventDefault();open(pair,input);});
   input.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open(pair,input);}});
  }
 }
 return {bind,close,refresh:()=>calendar?.refresh()};
}
