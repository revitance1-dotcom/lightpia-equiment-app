const assert=require('node:assert/strict'),fs=require('node:fs'),api=require('firebase/firestore');
const {initializeTestEnvironment,assertFails}=require('@firebase/rules-unit-testing');
(async()=>{
 const {extendLoan,validateExtension}=await import('../www/loan-extension.js');
 const {eventsFor}=await import('../push_sender/notification-events.mjs');
 const ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2';
 const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8')}});
 const path=(db,k,id)=>api.doc(db,'company/main/'+k,id),loan={equipmentId:'e',equipmentName:'LED',quantity:2,loanDate:'2026-11-01',dueDate:'2026-11-09',status:'active',ownerUid:ADMIN,teamId:'T',team:'T'};
 try{
  await env.clearFirestore();await env.withSecurityRulesDisabled(async c=>{const db=c.firestore();for(const [id,teamId]of [['staff','T'],['other','U']])await api.setDoc(api.doc(db,'members',id),{active:true,role:'team',teamId});await api.setDoc(api.doc(db,'teams/T'),{active:true,name:'T'});await api.setDoc(api.doc(db,'teams/U'),{active:true,name:'U'});await api.setDoc(path(db,'equipment','e'),{name:'LED',total:5,loaned:2,repairing:0});await api.setDoc(path(db,'loans','L'),loan);});
  const staff=env.authenticatedContext('staff').firestore(),other=env.authenticatedContext('other').firestore();
  const run=(db,uid,date,expected)=>extendLoan({...api,uid},db,'L',date,'2026-11-11',()=>true,expected);
  await assertFails(run(other,'other','2026-11-15',loan.dueDate));
  await assertFails(api.updateDoc(path(staff,'loans','L'),{dueDate:'2026-11-15'}));
  await run(staff,'staff','2026-11-15',loan.dueDate);
  let saved=(await api.getDoc(path(staff,'loans','L'))).data();assert.equal(saved.dueDate,'2026-11-15');assert.equal(saved.previousDueDate,loan.dueDate);assert.equal(saved.extendedBy,'staff');assert.equal((await api.getDoc(path(staff,'equipment','e'))).data().loaned,2);
  assert.throws(()=>validateExtension(saved,'2026-11-15','2026-11-11'));assert.throws(()=>validateExtension(saved,'2026-02-30','2026-01-01'));
  await assert.rejects(run(staff,'staff','2026-11-16',loan.dueDate),/변경/);
  const clock=Date.parse('2026-11-11T01:00:00Z');assert.equal(eventsFor('loans',[{id:'L',...saved}],{L:{status:'active'}},0,clock).events.filter(e=>e.kind==='due').length,0);
  await env.withSecurityRulesDisabled(async c=>api.setDoc(path(c.firestore(),'reservations','R'),{status:'approved',startDate:'2026-11-16',endDate:'2026-11-20',items:[{id:'e',qty:4}]}));
  await assert.rejects(run(staff,'staff','2026-11-18',saved.dueDate),/가용/);
  const admin=env.authenticatedContext(ADMIN).firestore();await run(admin,ADMIN,'2026-11-16',saved.dueDate).then(()=>assert.fail('conflict accepted'),e=>assert.match(e.message,/가용/));
  await env.withSecurityRulesDisabled(async c=>api.updateDoc(path(c.firestore(),'loans','L'),{status:'returned'}));await assert.rejects(run(staff,'staff','2026-11-20',saved.dueDate),/반납/);
  console.log('PASS extension: team/admin permissions, stale dates, reservation capacity, unchanged stock, returned rejection, future reminders suppressed');
 }finally{await env.cleanup();}
})().catch(e=>{console.error(e);process.exit(1)});
