import fs from 'node:fs';
export function patchSerialRegisterRules(source){
 if(source.includes('LNS_SERIAL_REGISTER_V1'))return source;
 if(/match\s+\/company\/main\/equipmentSerials/.test(source)||/match\s+\/company\/main\/appSettings\/serialAccess/.test(source))throw Error('Existing serial rules need review');
 const m=source.match(/match\s+\/databases\/\{database\}\/documents\s*\{/);if(!m)throw Error('Unexpected rules structure');
 const at=m.index+m[0].length;return source.slice(0,at)+'\n'+fs.readFileSync(new URL('./serial-register.rules',import.meta.url),'utf8')+source.slice(at);
}
