import {periodCapacity,capacityFailure,inventoryStock,quantityText} from './equipment-units.js';
const path=(api,db,kind,id)=>api.doc(db,'company','main',kind,id);
const revision=s=>s.exists()?Number(s.data().version||0):0;
const retry=()=>Object.assign(Error('예약·대여 수량이 변경되어 다시 확인합니다.'),{capacityRetry:true});
export async function loadCapacitySnapshot(api,db,ids,start){
 const locks=new Map();for(const id of ids)locks.set(id,revision(await api.getDoc(path(api,db,'availabilityLocks',id))));
 const [r,l]=await Promise.all([api.getDocsFromServer(api.query(api.collection(db,'company','main','reservations'),api.where('endDate','>=',start))),api.getDocsFromServer(api.query(api.collection(db,'company','main','loans'),api.where('status','==','active')))]);
 return {locks,reservations:r.docs.map(d=>({...d.data(),id:d.id})),loans:l.docs.map(d=>({...d.data(),id:d.id}))};
}
export async function readCapacityLock(api,db,tx,id,snapshot){const ref=path(api,db,'availabilityLocks',id),s=await tx.get(ref);if(revision(s)!==snapshot.locks.get(id))throw retry();return {ref,version:revision(s)+1};}
export function writeCapacityLock(api,tx,lock,operationId,operationType){tx.set(lock.ref,{version:lock.version,operationId,operationType,updatedAt:api.serverTimestamp()});}
export function checkCapacity(e,snapshot,quantity,start,end,now,exclude=''){const result=periodCapacity(e,snapshot.loans,snapshot.reservations,start,end,now,exclude);if(quantity>result.free)throw Error(capacityFailure(e,result,quantity,start,end));return result;}
export async function submitCheckedReservation(api,db,data,now){
 if(!Array.isArray(data.items)||data.items.length<1||data.items.length>20||data.items.some(i=>!i.id||!Number.isInteger(i.qty)||i.qty<1)||!data.startDate||!data.endDate||data.endDate<data.startDate||data.startDate<now)throw Error('예약 날짜와 수량을 확인해 주세요.');
 const ref=api.doc(api.collection(db,'company','main','reservations')),ids=data.items.map(i=>i.id);if(new Set(ids).size!==ids.length)throw Error('같은 장비가 중복 선택되었습니다.');
 for(let attempt=0;attempt<5;attempt++){
  const snapshot=await loadCapacitySnapshot(api,db,ids,data.startDate);
  try{return await api.runTransaction(db,async tx=>{const rows=[];for(const i of data.items){const lock=await readCapacityLock(api,db,tx,i.id,snapshot),eq=await tx.get(path(api,db,'equipment',i.id));if(!eq.exists())throw Error('삭제된 장비: '+i.name);checkCapacity({...eq.data(),id:i.id},snapshot,i.qty,data.startDate,data.endDate,now);rows.push(lock);}for(const lock of rows)writeCapacityLock(api,tx,lock,ref.id,'reservation');tx.set(ref,{...data,createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});return ref;});}catch(e){if(!e.capacityRetry||attempt===4)throw e;}
 }
}
