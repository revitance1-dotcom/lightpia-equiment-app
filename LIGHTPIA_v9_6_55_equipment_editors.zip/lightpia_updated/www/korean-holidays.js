import {KOREAN_LUNAR_HOLIDAY_DATES} from './korean-lunar-dates.js';
// Public-holiday rules checked against the current Korean Presidential Decree
// (effective 2026-05-11). Proclaimed one-off dates are intentionally explicit.
// https://www.law.go.kr/LSW/lsInfoP.do?ancYnChk=0&lsId=002404
// https://www.kasa.go.kr/prog/plcyBrf/brief/kor/sub01_01_04/view.do?plcyBrfNo=431
export const KOREAN_HOLIDAY_RANGE={min:2020,max:2050,checked:'2026-10-30'};
const holidayExtraDates={
 '2020-04-15':'국회의원 선거일','2020-08-17':'임시공휴일',
 '2022-03-09':'대통령 선거일','2022-06-01':'전국동시지방선거',
 '2023-10-02':'임시공휴일','2024-04-10':'국회의원 선거일','2024-10-01':'임시공휴일',
 '2025-01-27':'임시공휴일','2025-06-03':'대통령 선거일','2026-06-03':'전국동시지방선거'
};
const holidayCache=new Map();
const holidayShift=(day,n)=>new Date(Date.parse(day+'T00:00:00Z')+n*86400000).toISOString().slice(0,10);
const holidayWeekday=day=>new Date(day+'T00:00:00Z').getUTCDay();
export function koreanHolidays(year){
 year=Number(year);if(holidayCache.has(year))return holidayCache.get(year);
 if(!Number.isInteger(year)||!KOREAN_LUNAR_HOLIDAY_DATES[year])return new Map();
 const dates=new Map(),base=new Map();
 const add=(day,name,rule='none')=>{
  if(!dates.has(day))dates.set(day,{date:day,names:[],substitute:false});
  if(!dates.get(day).names.includes(name))dates.get(day).names.push(name);
  if(!base.has(day))base.set(day,[]);base.get(day).push({name,rule});
 };
 const national=day=>(day>='2021-08-04'?'weekend':'none');
 for(const [md,name,type] of [['01-01','신정','none'],['03-01','삼일절','national'],['05-05','어린이날','weekend'],['06-06','현충일','none'],['08-15','광복절','national'],['10-03','개천절','national'],['10-09','한글날','national'],['12-25','성탄절',year>=2023?'weekend':'none']]){
  const day=year+'-'+md;add(day,name,type==='national'?national(day):type);
 }
 if(year>=2026){add(year+'-05-01','노동절','weekend');add(year+'-07-17','제헌절','weekend');}
 const [newYear,buddha,chuseok]=KOREAN_LUNAR_HOLIDAY_DATES[year].map(md=>year+'-'+md);
 for(const [center,name] of [[newYear,'설날'],[chuseok,'추석']]){
  add(holidayShift(center,-1),name+' 연휴','sunday');add(center,name,'sunday');add(holidayShift(center,1),name+' 연휴','sunday');
 }
 add(buddha,'부처님오신날',year>=2023?'weekend':'none');
 for(const [day,name] of Object.entries(holidayExtraDates))if(day.startsWith(year+'-'))add(day,name);
 // One weekday collision produces one substitute day even when two names
 // share that original date (e.g. Children's/Buddha's Day on 2025-05-05).
 const triggers=[...base].filter(([day,items])=>{
  const weekday=holidayWeekday(day);
  return items.some(i=>(i.rule==='weekend'&&(weekday===0||weekday===6))||(i.rule==='sunday'&&weekday===0)||(i.rule!=='none'&&weekday!==0&&weekday!==6&&items.length>1));
 }).sort(([a],[b])=>a.localeCompare(b));
 for(const [original,items] of triggers){
  let day=holidayShift(original,1);
  while(holidayWeekday(day)===0||holidayWeekday(day)===6||dates.has(day))day=holidayShift(day,1);
  dates.set(day,{date:day,names:['대체공휴일'],substitute:true,forNames:[...new Set(items.filter(i=>i.rule!=='none').map(i=>i.name))]});
 }
 holidayCache.set(year,dates);return dates;
}
export function koreanHolidayForDay(day){return koreanHolidays(Number(String(day).slice(0,4))).get(day)||null;}
export function koreanHolidayText(holiday){return holiday?(holiday.substitute?'대체공휴일 ('+holiday.forNames.join('·')+')':holiday.names.join('·')):'';}
export function koreaToday(now=new Date()){
 const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now),get=type=>parts.find(p=>p.type===type).value;
 return get('year')+'-'+get('month')+'-'+get('day');
}
