export function patchLoanExtensionRules(source){
 if(source.includes('// LNS_LOAN_EXTENSION_V1'))return source;
 const anchor='match /company/main/loans/{loanId} {';
 const marker='match /company/main/availabilityLocks/{equipmentId} {';
 if(source.split(anchor).length!==2||source.split(marker).length!==2)throw Error('Unexpected loan/lock rules.');
 source=source.replace(anchor,()=>`// LNS_LOAN_EXTENSION_V1
 function lnsValidExtension(before,after) {
  return after.dueDate != before.get('dueDate','') && before.status == 'active'
   && (admin() || activeTeamMember()) && loanOwner(before)
   && after.diff(before).affectedKeys().hasOnly(['dueDate','previousDueDate','extendedBy','extendedAt','updatedAt'])
   && after.dueDate is string && after.dueDate.matches('^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
   && after.dueDate > before.get('dueDate','') && after.dueDate >= before.loanDate
   && after.previousDueDate == before.get('dueDate','') && after.extendedBy == request.auth.uid
   && after.extendedAt == request.time && after.updatedAt == request.time;
 }
 ${anchor}
 allow update: if lnsValidExtension(resource.data,request.resource.data)
  && lnsCapacityLockMatches(resource.data.equipmentId,loanId,'extension');
 `);
 source=source.replace(marker,()=>`${marker}
 function extension() {
  let d=request.resource.data; let p=loanPath(d.operationId);
  return d.operationType == 'extension' && get(p).data.equipmentId == equipmentId
   && lnsValidExtension(get(p).data,getAfter(p).data);
 }
 `);
 source=source.replace("request.resource.data.operationType in ['loan','reservation']","request.resource.data.operationType in ['loan','reservation','extension']");
 source=source.replace('&& operation();','&& (request.resource.data.operationType == \'extension\' ? extension() : operation());');
 return source;
}
