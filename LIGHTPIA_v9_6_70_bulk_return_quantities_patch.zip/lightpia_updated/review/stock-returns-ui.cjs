const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/www/app.js','utf8'),html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const rendering=s.slice(s.indexOf('let equipmentCategoryFilter='),s.indexOf('function modal(')),modal=s.slice(s.indexOf('function modal('),s.indexOf('function addEquipment(')),returns=s.slice(s.indexOf('let bulkReturnSubmitting='),s.indexOf('async function returnLoans('));
const singleReturn=s.slice(s.indexOf('function returnQuantityDialog('),s.indexOf('async function returnLoan(l,quantity)'));
const vm=require('node:vm');
const batchSource=s.slice(s.indexOf('async function returnLoans('),s.indexOf('async function returnLoanChunk('));
async function checkBatches(){
 const active=Array.from({length:8},(_,i)=>({id:String(i),quantity:34,equipmentId:i===6?'eq0':'eq'+i}));
 const full=l=>({id:l.id,quantity:l.quantity});
 const committed=[],attempted=[];
 let fail=true;
 const run=vm.runInNewContext(batchSource+';returnLoans',{activeLoans:()=>active,canHandleLoan:()=>true,
  returnLoanChunk:async rows=>{attempted.push(rows.map(r=>r.id).join(','));if(fail&&attempted.length===2)throw Error('save failed')},
  returnLoan:async (loan,count)=>{attempted.push(loan.id+':'+count);if(fail)throw Error('save failed')}
 });
 await assert.rejects(run(active.map(full),ids=>committed.push(...ids)),/save failed/);
 assert.deepEqual(committed,['0','1','2','3','4']);
 fail=false;
 await run(active.slice(5).map(full),ids=>committed.push(...ids));
 assert.deepEqual(committed,active.map(l=>l.id));
 attempted.length=0;
 await run([active[0],active[6],active[7]].map(full));
 assert.deepEqual(attempted,['0','6,7']);
 attempted.length=0;
 await run([full(active[1]),{id:'0',quantity:5},full(active[6]),full(active[7])]);
 assert.deepEqual(attempted,['1','0:5','6,7']);
 attempted.length=0;committed.length=0;fail=true;
 await assert.rejects(run([full(active[1]),{id:'0',quantity:5},full(active[6])],ids=>committed.push(...ids)),/save failed/);
 assert.deepEqual(committed,['1']);
 assert.deepEqual(attempted,['1','0:5']);
}
const historyBinding=s.match(/\$\("openLoanHistoryBtn"\)\.onclick=openLoanHistory;/)[0];
const returnClick=s.match(/if\(b\.dataset\.return\)returnQuantityDialog[^;]+;/)[0];
(async()=>{await checkBatches();const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{for(const width of [320,393,768,1280]){
 const page=await browser.newPage({viewport:{width,height:900},locale:'ko-KR'}),errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());await page.setContent(html);await page.addScriptTag({content:fs.readFileSync(require('path').resolve(__dirname,'../www/display-order.js'),'utf8').replace(/export /g,'')});await page.addScriptTag({content:fs.readFileSync(path.resolve(__dirname,'../www/equipment-units.js'),'utf8').replace(/export /g,'')});
 for(const module of ['equipment-search','search-input','loan-groups'])await page.addScriptTag({content:fs.readFileSync(root+'/www/'+module+'.js','utf8').replace(/export /g,'')});
 await page.addScriptTag({content:`const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const ADMIN_UID='admin',ready=true;let adminMode=true,teamId='A',currentUser={uid:'staff'};const isAdmin=()=>adminMode;
 const projects=[{id:'P',name:'언내추럴',active:true}],teamList=[{id:'A',name:'본팀',projectId:'P',active:true},{id:'B',name:'B팀',projectId:'P',active:true}],reservations=[];
 let equipment=[{id:'e',name:'18K COM',category:'HMI',total:5,loaned:1},{id:'u',name:'수량 모르는 장비',category:'그립',total:0,loaned:20},{id:'o',name:'잔여 없는 장비',category:'LED',total:2,loaned:2},{id:'r',name:'수리와 고장 장비',category:'HMI',total:10,loaned:2,repairing:3,brokenStock:1},{id:'long',name:'VERY_LONG_EQUIPMENT_NAME_WITHOUT_SPACES_'.repeat(3),total:0}];
 const borrowedQtyFor=id=>Number(equipment.find(e=>e.id===id)?.loaned||0),repairQtyFor=id=>Number(equipment.find(e=>e.id===id)?.repairing||0),brokenQtyFor=()=>0;
 const availableQtyFor=id=>{const e=equipment.find(e=>e.id===id);return e.total-(e.loaned||0)-(e.repairing||0)-(e.brokenStock||0)},untracked=id=>equipment.find(e=>e.id===id)?.total===0;
 const base={teamId:'A',team:'본팀',person:'직원',ownerUid:'staff',quantity:1,status:'active',equipmentName:'18K COM',loanDate:'2026-10-29'};
 let loans=[{...base,id:'stay',equipmentId:'e',equipmentGroup:'상주장비'},{...base,id:'set',equipmentId:'u',equipmentGroup:'세트장비'},{...base,id:'extra',equipmentId:'o',equipmentGroup:'추가장비'},{...base,id:'duplicate',equipmentId:'e',equipmentGroup:'추가장비'},{...base,id:'legacy',equipmentId:'r'},{...base,id:'foreign',equipmentId:'foreign',teamId:'B',team:'B팀',ownerUid:'other',equipmentGroup:'세트장비'},{...base,id:'external',equipmentId:'external',teamId:'admin',team:'관리자',ownerUid:'admin',rentalType:'external',externalTeam:'외부 촬영팀',externalPerson:'외부 담당자'},{...base,id:'done',equipmentId:'done',status:'returned'}];
 const partialReturnLimit=l=>l.quantity-Math.ceil(damageEa(l)/packSize(l));
 async function returnLoan(l,count){window.singleReturned=[l.id,count];l.quantity-=count;render();}
 document.addEventListener('click',event=>{const b=event.target.closest('button');if(!b)return;${returnClick}});
 const activeLoans=()=>loans.filter(l=>l.status!=='returned'),canHandleLoan=l=>adminMode||l.teamId===teamId||l.ownerUid===currentUser.uid,canReportDamage=()=>false,late=()=>false;
 function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}function showEquipmentDetail(){}
 async function returnLoans(requests,onCommit){
  window.returnRequests=requests;
  const ids=requests.map(r=>r.id);
  window.returnedIds=ids;
  loans=loans.flatMap(l=>{
   const request=requests.find(r=>r.id===l.id);
   if(!request)return [l];
   const history={...l,status:'returned',quantity:request.quantity,returnedAt:'2026-11-16T02:30:00Z'};
   return request.quantity===l.quantity?[history]:[{...l,quantity:l.quantity-request.quantity},{...history,id:l.id+'-partial'}];
  });
  onCommit(ids);render();
 }
 ${rendering}\n${modal}\n${returns}\n${singleReturn}
 ${historyBinding}
 show('app',true);show('loginGate',false);show('setupNotice',false);render();`});
 assert.equal(await page.locator('.operations-grid > button').count(),6);assert.equal(await page.locator('#statStock').textContent(),'4종');
 await page.evaluate(()=>showStockOverview());assert.equal(await page.locator('.stock-item').count(),4);assert.equal(await page.locator('#stockRows [data-equipment-detail="e"] .stock-qty').innerText(),'4\nEA 남음');assert.equal(await page.locator('#stockRows [data-equipment-detail="r"] .stock-qty').innerText(),'4\nEA 남음');assert((await page.locator('#stockRows [data-equipment-detail="u"]').innerText()).includes('보유'));assert((await page.locator('#stockRows [data-equipment-detail="u"]').innerText()).includes('수량 미집계'));
 await page.locator('[data-stock-filter=all]').click();assert.equal(await page.locator('.stock-item').count(),5);await page.locator('[data-stock-filter=out]').click();assert.equal(await page.locator('.stock-item').count(),1);
 await page.locator('[data-stock-filter=available]').click();await page.locator('[data-stock-category=HMI]').click();assert.equal(await page.locator('.stock-item').count(),2);
 await page.locator('#stockSearch').fill('18K');assert.equal(await page.locator('.stock-item').count(),1);await page.evaluate(()=>{equipment[0].loaned=3;render()});assert.equal(await page.locator('#stockRows [data-equipment-detail=e] .stock-qty').innerText(),'2\nEA 남음');assert.equal(await page.locator('#stockSearch').inputValue(),'18K');
 await page.locator('#stockSearch').fill('');await page.locator('[data-stock-category="전체"]').click();assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert(await page.locator('.stock-modal').evaluate(el=>el.scrollWidth<=el.clientWidth+1));
 if(width===393)await page.screenshot({path:root+'/review/stock-preview.png'});
 await page.evaluate(()=>{loans[0].quantity=4;openHeldLoanDetails(['stay'])});
 await page.locator('#modalRoot [data-return=stay]').click();
 const quantity=page.locator('#returnQuantity'),submit=page.locator('#returnQuantitySubmit');
 await quantity.fill('5');assert(await submit.isDisabled());
 await quantity.fill('1.5');assert(await submit.isDisabled());
 await page.locator('#returnQuantityAll').click();assert.equal(await quantity.inputValue(),'4');
 await quantity.fill('2');assert.equal(await page.locator('#returnQuantityPreview').textContent(),'이번 반납 2EA · 남은 대여 2EA');
 assert(await page.locator('#returnQuantityForm').evaluate(el=>el.scrollWidth<=el.clientWidth+1));
 await submit.click();assert.deepEqual(await page.evaluate(()=>singleReturned),['stay',2]);assert((await page.locator('#heldLoanDetailRows').innerText()).includes('2EA'));
 await page.locator('#closeModal').click();
 await page.evaluate(()=>bulkReturnDialog());assert.equal(await page.locator('#bulkReturnRows > details').count(),3);assert.equal(await page.locator('#bulkReturnRows details[open]').count(),0);
 const team=page.locator('[data-return-fold="team:A"]');await team.locator(':scope > summary').click();const stay=page.locator('[data-return-fold="team:A/상주장비"]');await stay.locator(':scope > summary').click();await page.locator('[value=stay]').check();
 await page.locator('#bulkReturnSearch').fill('세트장비');assert(await page.locator('[value=set]').isVisible());await page.locator('[value=set]').check();assert.equal(await page.locator('#bulkReturnCount').textContent(),'선택 2건');
 await page.locator('#bulkReturnSearch').fill('');assert(await stay.getAttribute('open')!==null);assert(await page.locator('[value=stay]').isChecked());await page.evaluate(()=>render());assert(await page.locator('[value=stay]').isChecked());
 await page.locator('#bulkReturnSearch').fill('추가장비');await page.locator('input.bulk-return-check[value=duplicate]').click();assert(await page.locator('input.bulk-return-check[value=duplicate]').isChecked());
 await page.locator('#bulkReturnSearch').fill('');await page.locator('#bulkReturnAll').click();assert.equal(await page.locator('#bulkReturnCount').textContent(),'선택 7건');
 await page.locator('#bulkReturnClear').click();assert.equal(await page.locator('#bulkReturnCount').textContent(),'선택 0건');assert(await page.locator('#bulkReturnSubmit').isDisabled());
 await page.evaluate(()=>{adminMode=false;bulkReturnDialog()});assert.equal(await page.locator('#bulkReturnRows > details').count(),1);assert.equal(await page.locator('[value=foreign]').count(),0);assert.equal(await page.locator('[value=done]').count(),0);
 await page.evaluate(()=>{loans[0].quantity=34;loans[0].damageEa=2;render()});
 await page.locator('#bulkReturnSearch').fill('상주장비');await page.locator('[value=stay]').check();
 const bulkQuantity=page.getByRole('spinbutton',{name:'18K COM 반납 수량 (EA)'});
 assert.equal(await bulkQuantity.inputValue(),'34');
 for(const invalid of ['','0','1.5','33','35']){
  await bulkQuantity.fill(invalid);assert(await page.locator('#bulkReturnSubmit').isDisabled());
 }
 await bulkQuantity.fill('5');
 assert((await page.locator('.bulk-return-field:visible').innerText()).includes('반납 후 29EA 대여 중'));
 await page.evaluate(()=>render());assert.equal(await bulkQuantity.inputValue(),'5');
 await page.locator('#bulkReturnSearch').fill('세트장비');await page.locator('[value=set]').check();
 await page.locator('#bulkReturnSearch').fill('상주장비');
 assert.equal(await bulkQuantity.inputValue(),'5');
 assert(await page.locator('.return-modal').evaluate(el=>el.scrollWidth<=el.clientWidth+1));
 if(width===393)await page.screenshot({path:root+'/review/return-preview.png'});
 await page.locator('#bulkReturnSubmit').click();await page.waitForFunction(()=>!!window.returnedIds);assert.deepEqual(await page.evaluate(()=>returnRequests),[{id:'stay',quantity:5},{id:'set',quantity:1}]);assert.equal(await page.evaluate(()=>loans.find(l=>l.id==='stay').quantity),29);assert.equal(await page.locator('#modalBack').count(),0);assert.equal(errors.length,0,errors.join('\n'));
 assert((await page.locator('#recentList .item').first().innerText()).includes('실제 반납'));
 await page.evaluate(()=>{$('loanFilter').value='late';$('loanSearch').value='검색 결과 없음'});
 await page.locator('#openLoanHistoryBtn').click();
 assert.equal(await page.locator('#view-loans').isVisible(),false);
 assert.equal(await page.locator('#loanHistoryRows .item').count(),9);
 assert((await page.locator('#loanHistoryRows .item').first().innerText()).includes('실제 반납'));
 await page.evaluate(()=>{loans.find(l=>l.id==='extra').status='returned';loans.find(l=>l.id==='extra').returnedAt='2026-11-17T02:30:00Z';render()});
 assert((await page.locator('#loanHistoryRows .item').first().innerText()).includes('2026. 11. 17.'));
 console.log('PASS stock and grouped returns',width,'5 dashboard cards, accurate available/unknown counts, filters/search/live update, folds and selections retained, 7 selected records including repeated equipment, team permissions, exact returned ids and no overflow');await page.close();
}}finally{await browser.close()}})().catch(e=>{console.error(e);process.exit(1)});
