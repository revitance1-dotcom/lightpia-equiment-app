# 조명장비 재고관리 Android APK 프로젝트

기존 개인용 웹 앱을 Capacitor Android 앱으로 패키징하고 GitHub Actions에서 APK를 빌드합니다.

## GitHub에서 빌드하기
1. 이 프로젝트의 압축을 풀고 파일과 폴더를 저장소 루트에 올립니다. ZIP 파일 자체만 저장소에 올리면 빌드되지 않습니다.
2. GitHub 저장소의 **Actions** 탭을 엽니다.
3. **Build Android APK** 워크플로를 선택하고 **Run workflow**를 누릅니다.
4. 실행이 완료되면 실행 기록에서 **Artifacts**의 `lightpia-equipment-debug-apk`를 다운로드합니다.
5. Artifact ZIP을 풀어 `app-debug.apk`를 Android 휴대폰에 설치합니다. Android에서 출처를 알 수 없는 앱 설치를 허용해야 할 수 있습니다.

## Firebase
- 앱 최초 실행 시 Firebase Web App 설정 JSON을 입력해야 합니다.
- Authentication에서 Anonymous 로그인이 활성화되어 있어야 합니다.
- Firestore에는 기존 개인용 규칙을 게시해야 합니다.
- Android 앱은 웹사이트의 브라우저 저장소와 별개이므로, 웹사이트에 있던 데이터가 자동으로 나타나지 않습니다. 웹 버전에서 JSON 백업을 다운로드하고 APK에서 JSON 백업 가져오기를 이용해 옮기세요.

## 참고
- 이 워크플로는 서명되지 않은 **debug APK**를 생성합니다. 개인 휴대폰에 설치해 시험하기 위한 빌드입니다.
- Firebase SDK는 현재 웹 앱처럼 Google의 Firebase CDN을 사용하므로 초기 연결과 데이터 동기화에는 인터넷이 필요합니다.
- APK는 실제 GitHub Actions 실행 후에 생성됩니다. 이 ZIP 자체는 APK가 아닙니다.
