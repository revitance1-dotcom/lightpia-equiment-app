# V9.6.8 JSON backup dry-run

Admin-only read-only validation of V9 format v2 JSON backup. No Firebase writes or restoration. Existing functionality retained.
