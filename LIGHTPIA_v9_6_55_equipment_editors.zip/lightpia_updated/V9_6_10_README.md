# V9.6.10 직원 계정 해제 및 재활성화

관리자 작품 운영 > 기존 직원 팀 재배정에서 계정 해제/재활성화 버튼을 제공합니다. 기존 기록을 보존하고 members.active를 false로 변경하여 앱 접근을 차단합니다. Firebase Authentication 사용자를 완전히 삭제하지는 않습니다. 기존 Firestore 규칙의 member()는 active == true를 요구하므로 별도 규칙 변경이 필요하지 않습니다.
