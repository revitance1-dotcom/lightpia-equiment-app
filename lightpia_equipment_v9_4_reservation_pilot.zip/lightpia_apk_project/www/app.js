import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, doc, addDoc, setDoc, updateDoc, deleteDoc, onSnapshot, query, orderBy, serverTimestamp, getDoc, runTransaction, enableIndexedDbPersistence } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $=id=>document.getElementById(id);
const ADMIN_UID="7iSB1gW9PAhYPgi253IUk4Dooyp2";
let member=null,role="",teamName="",teamId="",teamList=[],joinRequests=[],projects=[],membersList=[],reservations=[];
const isAdmin=()=>role==="admin";
const canHandleLoan=l=>isAdmin()||(role==="team"&&(l.ownerUid===currentUser?.uid || (teamId && l.teamId===teamId)));
let app,auth,db,currentUser=null,ready=false,unsubs=[],equipment=[],loans=[],repairs=[],activeTab="home",busy=false;
const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const activeLoans=()=>loans.filter(x=>x.status!=="returned");
const late=x=>x.status!=="returned"&&x.dueDate&&x.dueDate<today();
const BUILTIN_FIREBASE_CONFIG={"apiKey":"AIzaSyDsEYnXz66SI3X2BVQGBtdO1gxGgZEWJD8","authDomain":"light-4e07d.firebaseapp.com","projectId":"light-4e07d","storageBucket":"light-4e07d.firebasestorage.app","messagingSenderId":"668941084388","appId":"1:668941084388:web:1b0d169e7ccfec46946ef1"};
const cfg=()=>JSON.stringify(BUILTIN_FIREBASE_CONFIG);
const eqCol=()=>collection(db,"company","main","equipment");
const loanCol=()=>collection(db,"company","main","loans");
const repairCol=()=>collection(db,"company","main","repairs");
const reservationCol=()=>collection(db,"company","main","reservations");
const eqDoc=id=>doc(db,"company","main","equipment",id);
const loanDoc=id=>doc(db,"company","main","loans",id);
const repairDoc=id=>doc(db,"company","main","repairs",id);
const activeRepairs=()=>repairs.filter(x=>x.status!=="completed");
const repairQtyFor=id=>Number(equipment.find(x=>x.id===id)?.repairing||0);
const borrowedQtyFor=id=>Number(equipment.find(x=>x.id===id)?.loaned||0);
const availableQtyFor=id=>Number(equipment.find(x=>x.id===id)?.total||0)-borrowedQtyFor(id)-repairQtyFor(id);
const untracked=id=>Number(equipment.find(x=>x.id===id)?.total||0)===0;
function status(text,ok=false){$("connection").textContent=text;$("connection").className="status"+(ok?" ok":"")}
function show(el,on=true){const node=$(el);if(node)node.classList.toggle("hidden",!on)}
function cfgShow(){show("configPanel",true)}
function clearSubs(){unsubs.forEach(f=>f());unsubs=[]}
function subscribe(){clearSubs();if(!isAdmin()&&teamId)unsubs.push(onSnapshot(doc(db,"teams",teamId),snap=>{if(snap.exists())teamList=[{id:snap.id,...snap.data()}]},()=>{}));unsubs.push(onSnapshot(collection(db,"projects"),snap=>{projects=snap.docs.map(d=>({id:d.id,...d.data()}));renderProjects();render()},e=>status("작품 읽기 오류")));if(isAdmin()){unsubs.push(onSnapshot(collection(db,"members"),snap=>{membersList=snap.docs.map(d=>({id:d.id,...d.data()}));renderProjects()},e=>status("직원 목록 읽기 오류")));unsubs.push(onSnapshot(collection(db,"teams"),snap=>{teamList=snap.docs.map(d=>({id:d.id,...d.data()}));renderTeamAdmin();renderProjects()},e=>status("팀 목록 읽기 오류")));unsubs.push(onSnapshot(collection(db,"joinRequests"),snap=>{joinRequests=snap.docs.map(d=>({id:d.id,...d.data()}));renderTeamAdmin()},e=>status("가입 신청 읽기 오류")))}unsubs.push(onSnapshot(query(eqCol(),orderBy("name")),s=>{equipment=s.docs.map(d=>({id:d.id,...d.data()}));render();},e=>status("장비 읽기 오류")));unsubs.push(onSnapshot(query(loanCol(),orderBy("createdAt","desc")),s=>{loans=s.docs.map(d=>({id:d.id,...d.data()}));render();renderProjects();},e=>status("대여 기록 읽기 오류")));unsubs.push(onSnapshot(reservationCol(),s=>{reservations=s.docs.map(d=>({id:d.id,...d.data()}));renderReservations();render();},e=>status("예약 읽기 오류: "+e.message)));unsubs.push(onSnapshot(repairCol(),s=>{repairs=s.docs.map(d=>({id:d.id,...d.data()}));render();},e=>status("수리 기록 읽기 오류")))}
function updateAccountUI(u){
 const info=$("accountInfo");if(!info)return;
 info.textContent=`${isAdmin()?"관리자":teamName} · ${u.email||"계정"} · 회사 공용 재고`;
 show("emailLoginPanel",false);
 show("emailAccountPanel",!u.isAnonymous);
 if(!u.isAnonymous)$("signedInEmail").textContent=u.email||"이메일 계정";
 show("addEquipmentBtn",isAdmin());show("importJsonBtn",isAdmin());
 show("projectsPanel",isAdmin());const teamPanel=$("teamAdminPanel");if(teamPanel)teamPanel.classList.toggle("hidden",!isAdmin());
}
function initConfig(raw){
 const c=JSON.parse(raw);if(!c.apiKey||!c.projectId||!c.appId)throw Error("apiKey, projectId, appId 설정이 필요합니다.");
 app=initializeApp(c);auth=getAuth(app);db=getFirestore(app);enableIndexedDbPersistence(db).catch(()=>{});
 onAuthStateChanged(auth,async u=>{
  clearSubs();ready=false;currentUser=null;member=null;role="";teamName="";teamId="";
  equipment=[];loans=[];repairs=[];show("app",false);show("loginGate",true);
  if(!u){status("로그인 필요");return}
  if(u.isAnonymous){status("V7에서는 이메일 로그인이 필요합니다");await signOut(auth);return}
  try{
   const profile=await getDoc(doc(db,"members",u.uid));
   if(u.uid===ADMIN_UID){role="admin";teamName="관리자";teamId="admin"}
   else if(profile.exists()&&profile.data().active===true&&profile.data().role==="team"){
    role="team";teamName=profile.data().teamName;teamId=profile.data().teamId||"";member=profile.data();
   }else{status("등록되지 않은 팀 계정");status("관리자 승인 대기 중");$("pendingNotice").textContent="가입 신청을 완료했다면 관리자 승인을 기다려 주세요. 승인 후 로그아웃하고 다시 로그인하세요.";show("pendingNotice",true);show("pendingSignOutBtn",true);return}
   currentUser=u;ready=true;subscribe();show("app",true);show("loginGate",false);show("setupNotice",false);show("configPanel",false);
   updateAccountUI(u);status(`${teamName} · 공용 재고 연결됨`,true);render();
  }catch(e){status("계정 권한 확인 실패");alert("팀 권한 확인 실패: "+e.message)}
 });
}
async function loginEmail(){
 const gate=!auth.currentUser;const email=$(gate?"gateLoginEmail":"loginEmail").value.trim(),password=$(gate?"gateLoginPassword":"loginPassword").value;
 if(!email||!password)return alert("이메일과 비밀번호를 입력해 주세요.");
 if(auth.currentUser?.isAnonymous && !confirm("현재 익명 저장소에서 이메일 계정으로 전환합니다. 기존 장비 데이터는 자동으로 옮겨지지 않습니다. 설정 → 전체 백업 다운로드(JSON)를 먼저 완료했나요?"))return;
 try{await signInWithEmailAndPassword(auth,email,password);$(gate?"gateLoginPassword":"loginPassword").value="";alert("로그인 성공! 회사 공용 재고에 연결합니다.")}
 catch(e){alert("이메일 로그인 실패: "+e.message)}
}

function render(){if(!ready)return;const al=activeLoans();$("statKinds").textContent=teamList.filter(t=>t.active!==false&&projects.some(p=>p.id===t.projectId&&p.active!==false)).length;$("statTotal").textContent=reservations.filter(r=>r.status==="pending").length;$("statLoan").textContent=reservations.filter(r=>r.status==="approved").length;$("statLate").textContent=al.filter(late).length;
 const due=al.filter(x=>x.dueDate).sort((a,b)=>a.dueDate.localeCompare(b.dueDate)).slice(0,5);$("dueList").innerHTML=due.length?due.map(loanCard).join(""):'<div class="empty">반납 예정 기록이 없습니다.</div>';
 $("recentList").innerHTML=loans.length?loans.slice(0,4).map(loanCard).join(""):'<div class="empty">대여 기록이 없습니다.</div>';
 const search=($("equipmentSearch")?.value||"").toLowerCase();const es=equipment.filter(x=>[x.name,x.category,x.model,x.note].join(" ").toLowerCase().includes(search));$("equipmentList").innerHTML=es.length?es.map(e=>{const borrowed=borrowedQtyFor(e.id),repairing=repairQtyFor(e.id),available=availableQtyFor(e.id);return `<div class="item"><div class="equipment-summary" data-equipment-detail="${e.id}" role="button" tabindex="0" style="flex:1;cursor:pointer;min-width:0"><div class="itemtitle">${esc(e.name)} <span class="muted" style="font-size:11px;font-weight:500">상세 보기 ›</span></div><div class="meta">${esc(e.category||"미분류")} ${e.model?"· "+esc(e.model):""}<br>전체 ${Number(e.total||0)} · 대여 ${borrowed} · 수리 ${repairing} · <b>${untracked(e.id)?`수량 미확정 (잔여 ${available})`:`가용 ${available}`}</b>${e.note?"<br>"+esc(e.note):""}</div></div>${isAdmin()?`<div class="actions"><button class="small secondary" data-edit-equipment="${e.id}">수정</button><button class="small danger" data-delete-equipment="${e.id}">삭제</button></div>`:""}</div>`}).join(""):'<div class="empty">등록된 장비가 없습니다. 장비를 등록해 주세요.</div>';
 const q=($("loanSearch")?.value||"").toLowerCase(),filter=$("loanFilter")?.value||"active";const ls=loans.filter(l=>{const match=[l.equipmentName,l.team,l.person,l.note].join(" ").toLowerCase().includes(q);return match&&(filter==="all"||(filter==="active"&&l.status!=="returned")||(filter==="late"&&late(l))||(filter==="returned"&&l.status==="returned"))});$("loanList").innerHTML=ls.length?ls.map(loanCard).join(""):'<div class="empty">조건에 맞는 기록이 없습니다.</div>';
}
function loanCard(l){const returned=l.status==="returned",isLate=late(l);return `<div class="item"><div><div class="itemtitle">${esc(l.equipmentName||"삭제된 장비")} · ${Number(l.quantity||0)}개</div><div class="meta">${esc(l.team||"팀 미입력")} ${l.person?"· "+esc(l.person):""}<br>대여 ${esc(l.loanDate||"")} · 반납 예정 ${esc(l.dueDate||"미정")}${l.note?"<br>"+esc(l.note):""}</div><div style="margin-top:7px"><span class="pill ${returned?"green":isLate?"red":"amber"}">${returned?"반납 완료":isLate?"반납 지연":"대여 중"}</span></div></div><div class="actions">${!returned&&canHandleLoan(l)?`<button class="small" data-return="${l.id}">반납</button>`:""}</div></div>`}
function modal(title,body){$("modalRoot").innerHTML=`<div class="modalback" id="modalBack"><div class="modal"><div class="modalhead"><h2>${title}</h2><button class="secondary small" id="closeModal">닫기</button></div>${body}</div></div>`;$("closeModal").onclick=closeModal;$("modalBack").onclick=e=>{if(e.target.id==="modalBack")closeModal()}}
function closeModal(){$("modalRoot").innerHTML=""}
function field(label,id,placeholder="",type="text",value="",required=false){return `<div class="field"><label>${label}${required?" *":""}</label><input id="${id}" type="${type}" placeholder="${placeholder}" value="${esc(value)}" ${required?"required":""} ${type==="number"?'min="0" step="1"':""}></div>`}
function addEquipment(old={}){modal(old.id?"장비 수정":"장비 등록",`<form id="equipmentForm"><div class="formgrid">${field("장비명","eqName","예: Aputure 600d Pro","text",old.name||"",true)}${field("분류","eqCategory","예: LED / HMI","text",old.category||"")}${field("모델 / 규격","eqModel","모델명","text",old.model||"")}${field("전체 수량","eqTotal","수량","number",old.total??1,true)}<div class="field wide"><label>비고</label><input id="eqNote" value="${esc(old.note||"")}" placeholder="보관 위치, 구성품 등"></div></div><div class="modalbuttons"><button type="submit">저장</button></div></form>`);$("equipmentForm").onsubmit=async e=>{e.preventDefault();const data={name:$("eqName").value.trim(),category:$("eqCategory").value.trim(),model:$("eqModel").value.trim(),total:Number($("eqTotal").value),note:$("eqNote").value.trim(),updatedAt:serverTimestamp()};const borrowed=borrowedQtyFor(old.id),repairing=repairQtyFor(old.id);if(!data.name||!Number.isInteger(data.total)||data.total<0)return alert("장비명과 0 이상의 정수 수량을 입력해 주세요.");if(old.id&&data.total!==0&&data.total<borrowed+repairing)return alert(`현재 대여 ${borrowed}개와 수리 ${repairing}개가 있어 전체 수량을 ${borrowed+repairing}개 미만으로 설정할 수 없습니다.`);try{if(old.id)await updateDoc(eqDoc(old.id),data);else await addDoc(eqCol(),{...data,loaned:0,repairing:0,createdAt:serverTimestamp()});closeModal()}catch(err){alert("저장 실패: "+err.message)}}}
let cartItems={},cartCategory="전체",cartSearch="";
function addLoan(old={}){
 if(old.id)return alert("기존 대여 기록은 수정할 수 없습니다. 반납 후 다시 대여해 주세요.");
 cartItems={};cartCategory="전체";cartSearch="";
 if(old.equipmentId)cartItems[old.equipmentId]=1;
 const name=isAdmin()?"관리자":(member?.displayName||teamName);
 modal("빠른 일괄 대여",equipment.length?`<div class="notice">${esc(teamName)} · 대여자 <b>${esc(name)}</b> 자동 입력 · 여러 품목을 한 번에 선택하세요.</div>
 <input class="search" id="cartSearch" placeholder="⌕ 장비명 / 모델 / 분류 검색" autocomplete="off">
 <div id="cartCategories" class="cart-filter"></div><div id="cartEquipmentList" style="max-height:40dvh;overflow:auto"></div>
 <div class="cart-summary"><div id="cartSummary"></div><div class="formgrid" style="margin-top:10px">${field("대여일","cartDate","","date",today(),true)}${field("반납 예정일","cartDue","","date",today(),true)}</div><div class="field"><label>비고</label><input id="cartNote" placeholder="촬영 현장 / 참고 사항"></div><button id="cartSubmit">선택 장비 일괄 대여</button></div>`:'<div class="empty">관리자가 장비를 먼저 등록해 주세요.</div>');
 if(!equipment.length)return;
 $("cartSearch").oninput=e=>{cartSearch=e.target.value.toLowerCase();renderCart()};
 $("cartSubmit").onclick=submitCart;
 renderCart();
}
function renderCart(){
 const cats=["전체",...new Set(equipment.map(x=>x.category||"미분류"))];
 $("cartCategories").innerHTML=cats.map(c=>`<button class="secondary ${cartCategory===c?'selected':''}" data-cart-cat="${esc(c)}">${esc(c)}</button>`).join("");
 const filtered=equipment.filter(x=>(cartCategory==="전체"||(x.category||"미분류")===cartCategory)&&[x.name,x.model,x.category].join(" ").toLowerCase().includes(cartSearch));
 $("cartEquipmentList").innerHTML=filtered.length?filtered.map(x=>`<div class="cart-row"><div style="flex:1;min-width:0"><b>${esc(x.name)}</b><div class="meta">${esc(x.category||"미분류")} · ${untracked(x.id)?`수량 미확정 · 잔여 ${availableQtyFor(x.id)}개`:`가용 ${availableQtyFor(x.id)}개`}</div></div><div class="qty-control"><button class="secondary" data-cart-minus="${esc(x.id)}">−</button><strong>${cartItems[x.id]||0}</strong><button class="secondary" data-cart-plus="${esc(x.id)}" ${!untracked(x.id)&&availableQtyFor(x.id)<=(cartItems[x.id]||0)?'disabled':''}>＋</button></div></div>`).join(""):'<div class="empty">검색 결과가 없습니다.</div>';
 if(!isAdmin()&&teamList.some(t=>t.id===teamId&&t.active===false))return alert("종료된 팀은 대여할 수 없습니다.");const chosen=Object.entries(cartItems).filter(([,n])=>n>0),total=chosen.reduce((s,[,n])=>s+n,0);
 $("cartSummary").innerHTML=`<span class="cart-count">${chosen.length}종 · ${total}개 선택</span>`+(chosen.length?`<div class="meta">${chosen.map(([id,n])=>`${esc(equipment.find(x=>x.id===id)?.name||'장비')} ${n}개`).join(' · ')}</div>`:'<div class="meta">장비를 선택해 주세요.</div>');
 $("cartSubmit").disabled=!chosen.length;
}
async function submitCart(){
 if(!isAdmin()&&teamList.some(t=>t.id===teamId&&t.active===false))return alert("종료된 팀은 대여할 수 없습니다.");const chosen=Object.entries(cartItems).filter(([,n])=>n>0),loanDate=$("cartDate").value,dueDate=$("cartDue").value,note=$("cartNote").value.trim();
 if(!chosen.length||!loanDate||!dueDate||dueDate<loanDate)return alert("장비 수량과 날짜를 확인해 주세요.");
 if(chosen.length>20)return alert("한 번에 최대 20종까지 대여할 수 있어요. 나누어 등록해 주세요.");
 const btn=$("cartSubmit");btn.disabled=true;btn.textContent="재고 확인 및 대여 처리 중...";
 const items=chosen.map(([id,qty])=>({id,qty,ref:doc(loanCol()),eqRef:eqDoc(id)}));
 try{
  await runTransaction(db,async tx=>{
   const snaps=await Promise.all(items.map(x=>tx.get(x.eqRef)));
   for(let i=0;i<items.length;i++){
    const x=items[i],snap=snaps[i];if(!snap.exists())throw Error("삭제된 장비가 있습니다.");
    const d=snap.data(),avail=Number(d.total||0)-Number(d.loaned||0)-Number(d.repairing||0);
    if(Number(d.total||0)!==0&&x.qty>avail)throw Error(`${d.name}: 가용 ${avail}개, 신청 ${x.qty}개`);
   }
   for(let i=0;i<items.length;i++){
    const x=items[i],d=snaps[i].data();
    tx.update(x.eqRef,{loaned:Number(d.loaned||0)+x.qty,lastLoanId:x.ref.id});
    tx.set(x.ref,{...(teamId&&teamList.find(t=>t.id===teamId)?.projectId?{projectId:teamList.find(t=>t.id===teamId).projectId}:{}),equipmentId:x.id,equipmentName:d.name,quantity:x.qty,team:teamName,ownerUid:currentUser.uid,...(teamId?{teamId}:{}),person:isAdmin()?"관리자":(member?.displayName||teamName),loanDate,dueDate,note,status:"active",createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
   }
  });closeModal();alert(`${chosen.length}종 ${chosen.reduce((n,[,q])=>n+q,0)}개 대여가 완료됐습니다.`);
 }catch(e){alert("일괄 대여 실패: "+e.message);btn.disabled=false;btn.textContent="선택 장비 일괄 대여";}
}
function showEquipmentDetail(id){const e=equipment.find(x=>x.id===id);if(!e)return;const active=activeLoans().filter(l=>l.equipmentId===id),teamMap=new Map();active.forEach(l=>teamMap.set(l.team||"팀 미입력",(teamMap.get(l.team||"팀 미입력")||0)+Number(l.quantity||0)));const teamRows=[...teamMap.entries()].sort((a,b)=>a[0].localeCompare(b[0],"ko")).map(([team,qty])=>`<div class="item"><div class="itemtitle">${esc(team)}</div><strong>${qty}개</strong></div>`).join("");const rr=repairs.filter(r=>r.equipmentId===id).sort((a,b)=>(b.repairDate||"").localeCompare(a.repairDate||""));const repairRows=rr.map(r=>`<div class="item"><div style="flex:1;min-width:0"><div class="itemtitle">${Number(r.quantity||1)}개 · ${esc(r.status==="completed"?"수리 완료":"수리 중")}</div><div class="meta">고장 증상: ${esc(r.symptom||"미입력")}<br>수리 업체: ${esc(r.vendor||"미입력")}<br>수리 날짜: ${esc(r.repairDate||"미입력")}${r.note?"<br>메모: "+esc(r.note):""}</div></div><div class="actions"></div></div>`).join("");const borrowed=borrowedQtyFor(id),repairing=repairQtyFor(id),available=availableQtyFor(id);modal(`${esc(e.name)} 상세`, `<div class="grid detailstats"><div class="stat"><div class="k">전체 수량</div><div class="v">${Number(e.total||0)}</div></div><div class="stat"><div class="k">사용 가능</div><div class="v" style="color:var(--green)">${available}</div></div><div class="stat"><div class="k">대여 중</div><div class="v">${borrowed}</div></div><div class="stat"><div class="k">수리 중</div><div class="v" style="color:var(--red)">${repairing}</div></div></div><div class="panel"><div class="panelhead"><h2>장비 정보</h2>${isAdmin()?`<button class="small secondary" data-edit-equipment="${e.id}">장비 수정</button>`:""}</div><div class="meta">분류: ${esc(e.category||"미분류")}<br>모델 / 규격: ${esc(e.model||"미입력")}<br>비고: ${esc(e.note||"없음")}</div></div><div class="panel"><div class="panelhead"><h2>팀별 대여 현황</h2><button class="small" data-loan-equipment="${e.id}">+ 대여 등록</button></div><div class="list">${teamRows||'<div class="empty">현재 대여 중인 팀이 없습니다.</div>'}</div>${active.length?`<hr><div class="list">${active.map(l=>`<div class="item"><div><div class="itemtitle">${esc(l.team||"팀 미입력")} · ${Number(l.quantity||0)}개</div><div class="meta">${esc(l.person||"담당자 미입력")} · 반납 예정 ${esc(l.dueDate||"미정")}</div></div></div>`).join("")}`:""}</div><div class="panel"><div class="panelhead"><h2>수리 기록</h2></div><div class="list">${repairRows||'<div class="empty">등록된 수리 기록이 없습니다.</div>'}</div></div>`);}
function addRepair(equipmentId,old={}){alert("V7에서는 재고 정확성을 위해 수리 등록을 일시 제한했습니다. 후속 버전에서 트랜잭션 방식으로 복구합니다.");return;const eq=equipment.find(e=>e.id===equipmentId);if(!eq)return;modal(old.id?`${esc(eq.name)} 수리 기록 수정`:`${esc(eq.name)} 수리 등록`, `<form id="repairForm"><div class="formgrid">${field("수리 수량","repairQty","수량","number",old.quantity??1,true)}${field("수리 날짜","repairDate","","date",old.repairDate||today(),true)}${field("수리 업체","repairVendor","예: 업체명","text",old.vendor||"")}<div class="field"><label>수리 상태</label><select id="repairStatus"><option value="active" ${old.status!=="completed"?"selected":""}>수리 중</option><option value="completed" ${old.status==="completed"?"selected":""}>수리 완료</option></select></div><div class="field wide"><label>고장 증상 *</label><textarea id="repairSymptom" rows="2" required placeholder="예: 전원 불량, 깜빡임">${esc(old.symptom||"")}</textarea></div><div class="field wide"><label>메모</label><textarea id="repairNote" rows="2" placeholder="접수 번호, 수리 내용 등">${esc(old.note||"")}</textarea></div></div><div class="notice">수리 중인 수량은 사용 가능 수량에서 자동으로 제외됩니다. 완료 처리하면 다시 사용 가능 수량에 포함됩니다.</div><div class="modalbuttons"><button type="submit">저장</button></div></form>`);$("repairForm").onsubmit=async ev=>{ev.preventDefault();const qty=Number($("repairQty").value),statusValue=$("repairStatus").value==="completed"?"completed":"active";if(!Number.isInteger(qty)||qty<1)return alert("수리 수량은 1 이상의 정수로 입력해 주세요.");const currentRepairing=repairQtyFor(equipmentId)-(old.id&&old.status!=="completed"?Number(old.quantity||1):0);const availableForRepair=Number(eq.total||0)-borrowedQtyFor(equipmentId)-currentRepairing;if(statusValue!=="completed"&&qty>availableForRepair)return alert(`현재 수리 등록 가능한 수량은 ${Math.max(0,availableForRepair)}개입니다. 대여 중인 수량과 다른 수리 중 수량을 확인해 주세요.`);const data={equipmentId,equipmentName:eq.name,quantity:qty,repairDate:$("repairDate").value,vendor:$("repairVendor").value.trim(),symptom:$("repairSymptom").value.trim(),note:$("repairNote").value.trim(),status:statusValue,updatedAt:serverTimestamp()};if(!data.repairDate||!data.symptom)return alert("수리 날짜와 고장 증상을 입력해 주세요.");try{if(old.id){await updateDoc(repairDoc(old.id),data);repairs=repairs.map(r=>r.id===old.id?{...r,...data}:r)}else{const ref=await addDoc(repairCol(),{...data,createdAt:serverTimestamp()});repairs.push({id:ref.id,...data})}showEquipmentDetail(equipmentId)}catch(err){alert("수리 기록 저장 실패: "+err.message)}}}
function bulkReturnDialog(){
 const selectable=activeLoans().filter(canHandleLoan);
 if(!selectable.length)return alert("반납할 대여 기록이 없습니다.");
 modal("일괄 반납",`<div class="notice">같은 팀의 대여도 반납할 수 있어요. 선택한 기록은 모두 전량 반납됩니다. 한 번에 최대 5건씩 처리합니다.</div><input class="search" id="bulkReturnSearch" placeholder="장비명 / 팀 / 대여자 검색"><div style="margin:12px 0"><label><input type="checkbox" id="bulkReturnAll"> 현재 표시된 기록 전체 선택</label></div><div id="bulkReturnRows" style="max-height:48dvh;overflow:auto"></div><div class="modalbuttons"><button id="bulkReturnSubmit">선택한 기록 일괄 반납</button></div>`);
 const renderRows=()=>{const q=$("bulkReturnSearch").value.toLowerCase();const filtered=selectable.filter(l=>[l.equipmentName,l.team,l.person].join(" ").toLowerCase().includes(q));$("bulkReturnRows").innerHTML=filtered.map(l=>`<label class="item" style="display:flex;align-items:center;gap:12px"><input type="checkbox" class="bulk-return-check" value="${esc(l.id)}"><span><b>${esc(l.equipmentName)}</b> · ${Number(l.quantity)}개<br><span class="meta">${esc(l.team||"")} · ${esc(l.person||"")}</span></span></label>`).join("")||'<div class="empty">검색 결과 없음</div>';};
 $("bulkReturnSearch").oninput=renderRows;renderRows();
 $("bulkReturnAll").onchange=e=>document.querySelectorAll("#bulkReturnRows .bulk-return-check").forEach(c=>c.checked=e.target.checked);
 $("bulkReturnSubmit").onclick=async()=>{const ids=[...document.querySelectorAll("#bulkReturnRows .bulk-return-check:checked")].map(x=>x.value);if(!ids.length)return alert("반납할 기록을 선택해 주세요.");if(ids.length>5)return alert("보안 규칙 처리 제한을 고려해 5건 이하로 나누어 반납해 주세요.");if(!confirm(`${ids.length}건을 모두 전량 반납할까요?`))return;const btn=$("bulkReturnSubmit");btn.disabled=true;try{await returnLoans(ids);closeModal();alert(`${ids.length}건 일괄 반납 완료`)}catch(e){btn.disabled=false;alert("일괄 반납 실패: "+e.message)}};
}
async function returnLoans(ids){
 const unique=[...new Set(ids)];if(!unique.length||unique.length>5)throw Error("한 번에 1~5건을 선택해 주세요.");
 await runTransaction(db,async tx=>{
  const rows=[];for(const id of unique){const ref=loanDoc(id),snap=await tx.get(ref);if(!snap.exists()||snap.data().status!=="active")throw Error("이미 반납된 기록이 있습니다.");const l={id,...snap.data()};if(!canHandleLoan(l))throw Error("다른 팀 기록은 반납할 수 없습니다.");rows.push({ref,l})}
  // Each equipment document can carry only one lastLoanId per transaction.
  const eqIds=rows.map(x=>x.l.equipmentId);if(new Set(eqIds).size!==eqIds.length)throw Error("동일 장비의 여러 대여 건은 한 번에 반납할 수 없습니다. 각각 나누어 처리해 주세요.");
  const eqs=[];for(const row of rows){const ref=eqDoc(row.l.equipmentId),snap=await tx.get(ref);if(!snap.exists())throw Error("삭제된 장비가 있습니다.");if(Number(snap.data().loaned||0)<Number(row.l.quantity))throw Error("대여 수량이 일치하지 않습니다.");eqs.push({ref,snap,row})}
  for(const {ref,snap,row} of eqs){tx.update(ref,{loaned:Number(snap.data().loaned||0)-Number(row.l.quantity),lastLoanId:row.l.id});tx.update(row.ref,{status:"returned",returnedAt:serverTimestamp(),updatedAt:serverTimestamp()})}
 });
}
async function returnLoan(l){
 if(!canHandleLoan(l))throw Error("다른 팀의 대여를 반납할 수 없습니다.");
 await runTransaction(db,async tx=>{const loanRef=loanDoc(l.id),snap=await tx.get(loanRef);if(!snap.exists()||snap.data().status!=="active")throw Error("이미 반납되었거나 기록이 없습니다.");const loan=snap.data(),eqRef=eqDoc(loan.equipmentId),eqSnap=await tx.get(eqRef);if(!eqSnap.exists())throw Error("장비가 없습니다.");
  tx.update(eqRef,{loaned:Number(eqSnap.data().loaned||0)-Number(loan.quantity),lastLoanId:l.id});tx.update(loanRef,{status:"returned",returnedAt:serverTimestamp(),updatedAt:serverTimestamp()});
 });
}
async function signup(){
 const email=$("signupEmail").value.trim(),password=$("signupPassword").value,name=$("signupName").value.trim(),requestedTeam=$("signupTeam").value.trim();
 if(!email||password.length<8||!name||!requestedTeam)return alert("이메일, 8자리 이상 비밀번호, 이름, 희망 팀을 입력해 주세요.");
 try{const result=await createUserWithEmailAndPassword(auth,email,password);await setDoc(doc(db,"joinRequests",result.user.uid),{email,name,requestedTeam,status:"pending",createdAt:serverTimestamp()});alert("가입 신청 완료! 관리자가 팀을 배정한 뒤 다시 로그인해 주세요.");}
 catch(e){alert("가입 신청 실패: "+e.message)}
}
function projectArchiveHTML(p){
 const history=loans.filter(l=>l.projectId===p.id);
 const groups=new Map();
 for(const l of history){const key=l.teamId||('legacy:'+String(l.team||'미확인 팀'));if(!groups.has(key))groups.set(key,{name:l.team||'미확인 팀',records:[]});groups.get(key).records.push(l)}
 const contents=[...groups.values()].map(g=>`<div class="archive-team"><b>${esc(g.name)}</b><div class="meta">대여 ${g.records.length}건</div>${g.records.map(l=>`<div class="archive-loan"><div><b>${esc(l.equipmentName||'이름 없는 장비')}</b><div class="meta">${esc(l.person||'담당자 미기록')} · 대여 ${esc(l.loanDate||'미기록')} · 반납 예정 ${esc(l.dueDate||'미기록')}</div><div class="meta">${l.status==='returned'?'반납 완료':'미반납'}</div></div><strong>${Number(l.quantity||0)}개</strong></div>`).join('')}</div>`).join('');
 return `<details class="project-archive"><summary><span><b>${esc(p.name)}</b><span class="meta">대여 ${history.length}건 · ${history.reduce((n,l)=>n+Number(l.quantity||0),0)}개</span></span><span class="pill green">종료 · 이력 보기</span></summary><div class="archive-content">${contents||'<div class="empty">이 작품으로 저장된 대여 기록이 없습니다.</div>'}<div class="meta">※ 구버전에서 작품 ID 없이 생성된 대여 기록은 자동 연결되지 않습니다.</div></div></details>`;
}
function renderProjects(){
 const target=$("projectsPanel");if(!target||!isAdmin())return;
 const active=projects.filter(p=>p.active!==false),closed=projects.filter(p=>p.active===false);
 const teamOptions=teamList.filter(t=>t.active!==false).map(t=>{const project=projects.find(p=>p.id===t.projectId);const label=project?`${project.name} · ${t.name}`:`미연결 팀 · ${t.name}`;return `<option value="${esc(t.id)}">${esc(label)}</option>`}).join("");
 target.innerHTML=`<h2>작품 운영 · 관리자 전용</h2><p class="muted">직원 계정은 유지하고 작품과 팀 배정만 바꿉니다. 종료된 작품의 기록은 보관됩니다.</p><div class="field"><label>새 작품 이름</label><input id="newProjectName" placeholder="예: 드라마 2026"></div><button id="createProjectBtn">+ 작품 등록</button><h3>진행 중 작품 (${active.length})</h3><div class="list">${active.map(p=>{const ts=teamList.filter(t=>t.projectId===p.id);const count=activeLoans().filter(l=>l.projectId===p.id).length;return `<div class="item"><div style="flex:1"><b>${esc(p.name)}</b><div class="meta">소속 팀 ${ts.map(t=>esc(t.name)).join(', ')||'없음'} · 미반납 ${count}건</div><div class="field"><label>새 팀 생성</label><input id="newProjectTeam-${esc(p.id)}" placeholder="예: A팀, B팀"></div><button class="small" data-create-project-team="${esc(p.id)}">+ 이 작품에 팀 추가</button><div class="field"><label>기존 팀 연결</label><select id="projectTeam-${esc(p.id)}"><option value="">팀 선택</option>${teamOptions}</select></div><button class="small secondary" data-link-project="${esc(p.id)}">팀 연결</button></div><button class="small danger" data-close-project="${esc(p.id)}">종료</button></div>`}).join('')||'<div class="empty">진행 중인 작품이 없습니다.</div>'}</div><h3>종료된 작품 (${closed.length})</h3><div class="list">${closed.length?closed.map(p=>projectArchiveHTML(p)).join(''):'<div class="empty">없음</div>'}}</div><hr><h3>기존 직원 팀 재배정</h3><div class="list">${membersList.filter(m=>m.role==='team').map(m=>`<div class="item"><div style="flex:1"><b>${esc(m.displayName||m.teamName||"이름 미등록")}</b><div class="field"><label>직원 이름 (수정 가능)</label><input id="memberName-${esc(m.id)}" value="${esc(m.displayName||"")}" placeholder="실명 입력"></div><button class="small secondary" data-save-member-name="${esc(m.id)}">이름 저장</button><div class="meta">현재: ${esc(m.teamName||'미배정')}</div><select id="memberTeam-${esc(m.id)}"><option value="">새 팀 선택</option>${teamOptions}</select></div><button class="small secondary" data-move-member="${esc(m.id)}">배정</button></div>`).join('')||'<div class="empty">등록된 직원 없음</div>'}</div><div class="notice">이전 버전에서 생성된 대여 기록에는 작품 ID가 없을 수 있습니다. 그런 기록은 자동 종료 대상으로 추정하지 않으며, 먼저 직접 반납해야 합니다.</div>`;
}
async function createProjectTeam(id){
 const p=projects.find(x=>x.id===id),name=$("newProjectTeam-"+id)?.value.trim();
 if(!p||p.active===false||!name)return alert("진행 중 작품과 팀 이름을 확인해 주세요.");
 if(teamList.some(t=>t.projectId===id&&t.name===name))return alert("이 작품에 같은 이름의 팀이 있습니다.");
 await addDoc(collection(db,"teams"),{name,projectId:id,active:true,createdAt:serverTimestamp()});
 alert(p.name+" · "+name+" 생성 완료. 이제 직원 소속을 배정할 수 있어요.");
}
async function saveMemberName(uid){
 const m=membersList.find(x=>x.id===uid),name=$("memberName-"+uid)?.value.trim();
 if(!m||!name)return alert("직원 이름을 입력해 주세요.");
 if(name.length>80)return alert("이름은 80자 이내로 입력해 주세요.");
 await updateDoc(doc(db,"members",uid),{displayName:name,updatedAt:serverTimestamp()});
 alert(name+" 이름 저장 완료");
}
async function createProject(){const name=$("newProjectName")?.value.trim();if(!name)return alert("작품명을 입력하세요.");if(projects.some(p=>p.active!==false&&p.name===name))return alert("같은 이름의 진행 중 작품이 있습니다.");await addDoc(collection(db,"projects"),{name,active:true,createdAt:serverTimestamp()});}
async function linkProject(id){const team=teamList.find(t=>t.id===$("projectTeam-"+id)?.value),p=projects.find(x=>x.id===id);if(!team||!p||p.active===false)return alert("활성 팀을 선택하세요.");if(activeLoans().some(l=>l.teamId===team.id&&!l.projectId))return alert("이 팀에 이전 버전의 미반납 기록이 있습니다. 먼저 반납 처리한 뒤 작품을 연결해 주세요.");await updateDoc(doc(db,"teams",team.id),{projectId:id});alert(`${team.name}을 ${p.name}에 연결했습니다.`)}
async function moveMember(uid){const t=teamList.find(x=>x.id===$("memberTeam-"+uid)?.value);if(!t||t.active===false)return alert("활성 팀을 선택하세요.");await updateDoc(doc(db,"members",uid),{teamId:t.id,teamName:t.name,updatedAt:serverTimestamp()});alert("팀 배정 완료. 직원은 다시 로그인하면 새 소속이 적용됩니다.")}
async function closeProject(id){const p=projects.find(x=>x.id===id);if(!p||p.active===false)return;const ts=teamList.filter(t=>t.projectId===id),legacy=activeLoans().filter(l=>ts.some(t=>t.id===l.teamId)&&!l.projectId);if(legacy.length)return alert(`작품 ID가 없는 이전 대여 ${legacy.length}건이 있습니다. 오반납 방지를 위해 해당 기록을 먼저 수동 반납해 주세요.`);const records=activeLoans().filter(l=>l.projectId===id);if(!confirm(`${p.name} 종료: 미반납 ${records.length}건을 자동 반납하고 재고를 복구합니다. 실제 장비 입고 여부는 별도 확인해야 합니다. 계속할까요?`))return;
 // One transaction per loan: rules require each equipment update to match its loan's return.
 // A failure leaves the project active; rerunning processes only remaining active loans.
 try{for(const l of records){await returnLoan(l)}await updateDoc(doc(db,"projects",id),{active:false,closedAt:serverTimestamp()});for(const t of ts)await updateDoc(doc(db,"teams",t.id),{active:false});alert("작품 종료 완료. 미반납 기록 자동 반납 및 재고 복구를 처리했습니다. 기존 직원 계정은 유지됩니다.")}catch(e){alert("종료 처리 중 일부 작업이 실패했습니다. 작품과 미반납 기록을 확인하고 다시 종료를 시도하세요: "+e.message)}}
function renderTeamAdmin(){
 const t=$("teamsList"),r=$("requestsList");if(!t||!r)return;
 t.innerHTML=teamList.length?teamList.map(x=>`<div class="item"><div><b>${esc(x.name)}</b><div class="meta">${x.active===false?"비활성":"활성"} · 팀 ID ${esc(x.id)}</div></div><button class="small secondary" data-toggle-team="${esc(x.id)}">${x.active===false?"활성화":"비활성화"}</button></div>`).join(""):'<div class="empty">등록된 팀이 없습니다.</div>';
 const pending=joinRequests.filter(x=>x.status==="pending");
 r.innerHTML=pending.length?pending.map(x=>`<div class="item"><div><b>${esc(x.name)}</b><div class="meta">${esc(x.email)}<br>희망 팀: ${esc(x.requestedTeam)}</div><select id="assign-${esc(x.id)}"><option value="">팀 선택</option>${teamList.filter(t=>t.active!==false).map(t=>{const project=projects.find(p=>p.id===t.projectId);return `<option value="${esc(t.id)}">${esc(project?`${project.name} · ${t.name}`:`미연결 팀 · ${t.name}`)}</option>`}).join("")}</select></div><button class="small" data-approve="${esc(x.id)}">승인</button><button class="small secondary" data-reject="${esc(x.id)}">거절</button></div>`).join(""):'<div class="empty">대기 중인 가입 신청이 없습니다.</div>';
}
async function createTeam(){if(!isAdmin())return;const name=$("newTeamName").value.trim();if(!name)return alert("팀 이름을 입력해 주세요.");if(teamList.some(t=>t.name===name))return alert("동일한 팀 이름이 있습니다.");await addDoc(collection(db,"teams"),{name,active:true,createdAt:serverTimestamp()});$("newTeamName").value=""}
async function approveUser(uid){if(!isAdmin())return;const id=$("assign-"+uid)?.value,t=teamList.find(x=>x.id===id),r=joinRequests.find(x=>x.id===uid);if(!t||!r||t.active===false)return alert("소속 팀을 선택해 주세요.");await setDoc(doc(db,"members",uid),{role:"team",teamId:id,teamName:t.name,active:true,displayName:r.name,updatedAt:serverTimestamp()});await updateDoc(doc(db,"joinRequests",uid),{status:"approved",updatedAt:serverTimestamp()});alert(r.name+" 님을 "+t.name+"에 승인했어요.")}
async function saveTeam(){
 if(!isAdmin())return;
 const uid=$("teamUid").value.trim(),name=$("teamName").value.trim();
 if(!/^[a-zA-Z0-9]{20,128}$/.test(uid)||!name)return alert("Firebase Authentication에서 만든 팀 계정의 UID와 팀 이름을 입력해 주세요.");
 if(uid===ADMIN_UID)return alert("관리자 UID는 팀으로 등록할 수 없습니다.");
 await setDoc(doc(db,"members",uid),{role:"team",teamName:name,active:true,updatedAt:serverTimestamp()});
 alert(`${name} 등록 완료! 팀 계정으로 로그인할 수 있습니다.`);$("teamUid").value="";$("teamName").value="";
}
async function downloadBlob(name,blob){
 // Native Android/iOS: write the file into app storage and open the system share/save sheet.
 // Browser/PWA: prefer the platform share sheet when available; otherwise download normally.
 const native=window.Capacitor?.isNativePlatform?.();
 if(native){
  const plugins=window.Capacitor?.Plugins||{};
  const filesystem=plugins.Filesystem,share=plugins.Share;
  if(!filesystem||!share)throw Error("파일 저장 플러그인을 찾지 못했습니다. 새 버전 APK를 설치해 주세요.");
  const bytes=new Uint8Array(await blob.arrayBuffer());
  let binary="";for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  const base64=btoa(binary);
  const result=await filesystem.writeFile({path:name,data:base64,directory:"CACHE",recursive:true});
  await share.share({title:name,text:"Lightpia & Softsun 장비 관리 백업",url:result.uri,dialogTitle:"파일 저장 또는 공유"});
  return;
 }
 if(navigator.canShare&&navigator.share){
  const file=new File([blob],name,{type:blob.type||"application/octet-stream"});
  if(navigator.canShare({files:[file]})){
   try{await navigator.share({files:[file],title:name});return}catch(e){if(e.name==="AbortError")return;}
  }
 }
 const a=document.createElement("a"),url=URL.createObjectURL(blob);
 a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),10000);
}
async function exportJSON(){const data={format:"lightpia-equipment-backup",version:2,exportedAt:new Date().toISOString(),equipment:equipment.map(x=>({...x,createdAt:null,updatedAt:null})),loans:loans.map(x=>({...x,createdAt:null,updatedAt:null,returnedAt:null})),repairs:repairs.map(x=>({...x,createdAt:null,updatedAt:null,returnedAt:null}))};await downloadBlob(`조명장비_백업_${today()}.json`,new Blob([JSON.stringify(data,null,2)],{type:"application/json;charset=utf-8"}))}
async function exportCSV(){const rows=[["종류","장비명","분류/팀","모델/담당자","수량","대여일","반납예정일","상태","비고"],...loans.map(l=>["대여",l.equipmentName,l.team,l.person,l.quantity,l.loanDate,l.dueDate,l.status==="returned"?"반납완료":"대여중",l.note]),...equipment.map(e=>["재고",e.name,e.category,e.model,e.total,"","","",e.note]),...repairs.map(r=>["수리",r.equipmentName,r.vendor,r.symptom,r.quantity,r.repairDate,"",r.status==="completed"?"수리완료":"수리중",r.note])];const csv="\uFEFF"+rows.map(r=>r.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");await downloadBlob(`조명장비_목록_${today()}.csv`,new Blob([csv],{type:"text/csv;charset=utf-8;"}))}
async function importJSON(file){alert("V7에서는 기존 백업을 직접 복원하면 공용 재고 수량이 어긋날 수 있어 복원을 잠시 차단했습니다. 이전은 별도 검증 절차로 진행해 주세요.");return;if(!file)return;try{const data=JSON.parse(await file.text());if(data.format!=="lightpia-equipment-backup"||!Array.isArray(data.equipment)||!Array.isArray(data.loans))throw Error("이 앱에서 만든 JSON 백업 파일이 아닙니다.");const backupRepairs=Array.isArray(data.repairs)?data.repairs:[];if(!confirm(`백업 파일에서 장비 ${data.equipment.length}종, 대여 기록 ${data.loans.length}건, 수리 기록 ${backupRepairs.length}건을 가져옵니다. 현재 데이터는 유지하고 가져온 항목을 추가할까요?`))return;for(const x of data.equipment){const {id,...item}=x;if(!id)throw Error("백업 장비 항목에 ID가 없습니다.");await setDoc(eqDoc(id),{...item,createdAt:serverTimestamp(),updatedAt:serverTimestamp()})}for(const x of data.loans){const {id,...item}=x;if(!id)throw Error("백업 대여 항목에 ID가 없습니다.");await setDoc(loanDoc(id),{...item,createdAt:serverTimestamp(),updatedAt:serverTimestamp()})}for(const x of backupRepairs){const {id,...item}=x;if(!id)throw Error("백업 수리 항목에 ID가 없습니다.");await setDoc(repairDoc(id),{...item,createdAt:serverTimestamp(),updatedAt:serverTimestamp()})}alert("백업 데이터를 복원했습니다. 백업에 포함된 동일 ID 항목은 갱신되었고, 나머지 기존 데이터는 유지됩니다.")}catch(e){alert("백업 복원 실패: "+e.message)}finally{$("importFile").value=""}}
document.addEventListener("click",e=>{
 const cat=e.target.closest("[data-cart-cat]");if(cat){cartCategory=cat.dataset.cartCat;renderCart();return}
 const plus=e.target.closest("[data-cart-plus]"),minus=e.target.closest("[data-cart-minus]");
 if(plus||minus){const id=(plus||minus).dataset[plus?"cartPlus":"cartMinus"];const old=cartItems[id]||0;cartItems[id]=Math.max(0,Math.min(untracked(id)?9999:Math.max(0,availableQtyFor(id)),old+(plus?1:-1)));renderCart();return}
});
document.addEventListener("click",async e=>{const detail=e.target.closest("[data-equipment-detail]");if(detail&&!e.target.closest("button")){showEquipmentDetail(detail.dataset.equipmentDetail);return}const b=e.target.closest("button");if(!b)return;try{if(b.dataset.tab){activeTab=b.dataset.tab;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===activeTab));["home","equipment","loans","reservations","settings"].forEach(x=>show("view-"+x,x===activeTab));render()}if(b.dataset.goto){document.querySelector(`[data-tab="${b.dataset.goto}"]`).click()}if(b.id==="addEquipmentBtn"){if(!isAdmin())throw Error("관리자 전용입니다.");addEquipment()}if(b.dataset.equipmentDetail)showEquipmentDetail(b.dataset.equipmentDetail);if(b.dataset.editEquipment){if(!isAdmin())throw Error("관리자 전용입니다.");const item=equipment.find(x=>x.id===b.dataset.editEquipment);closeModal();addEquipment(item)}if(b.dataset.deleteEquipment){if(!isAdmin())throw Error("관리자 전용입니다.");const id=b.dataset.deleteEquipment;if(borrowedQtyFor(id)>0)return alert("대여 중인 장비는 삭제할 수 없습니다.");if(repairs.some(r=>r.equipmentId===id))return alert("수리 이력이 있는 장비는 삭제할 수 없습니다. 수리 이력을 먼저 정리해 주세요.");if(confirm("이 장비를 삭제할까요?"))await deleteDoc(eqDoc(id))}if(b.id==="addLoanBtn")addLoan();if(b.id==="bulkReturnBtn")bulkReturnDialog();if(b.dataset.loanEquipment){const id=b.dataset.loanEquipment;closeModal();addLoan({equipmentId:id})}if(b.dataset.editLoan){const item=loans.find(x=>x.id===b.dataset.editLoan);closeModal();addLoan(item)}if(b.dataset.addRepair){const id=b.dataset.addRepair;closeModal();addRepair(id)}if(b.dataset.editRepair){const item=repairs.find(x=>x.id===b.dataset.editRepair);closeModal();if(item)addRepair(item.equipmentId,item)}if(b.dataset.completeRepair){throw Error("수리 기록 변경은 현재 제한됩니다.");const item=repairs.find(x=>x.id===b.dataset.completeRepair);if(item&&confirm("이 수리를 완료 처리할까요? 완료 처리하면 사용 가능 수량에 다시 포함됩니다.")){await updateDoc(repairDoc(item.id),{status:"completed",updatedAt:serverTimestamp()});repairs=repairs.map(r=>r.id===item.id?{...r,status:"completed"}:r);showEquipmentDetail(item.equipmentId)}}if(b.dataset.deleteRepair){throw Error("수리 기록 변경은 현재 제한됩니다.");const item=repairs.find(x=>x.id===b.dataset.deleteRepair);if(item&&confirm("이 수리 기록을 삭제할까요?")){await deleteDoc(repairDoc(item.id));repairs=repairs.filter(r=>r.id!==item.id);showEquipmentDetail(item.equipmentId)}}if(b.dataset.return){const l=loans.find(x=>x.id===b.dataset.return);if(confirm(`${l.equipmentName} ${l.quantity}개를 반납 처리할까요?`))await returnLoan(l)}if(b.id==="loginEmailBtn")await loginEmail();if(b.id==="signOutBtn"){if(confirm("로그아웃할까요? 같은 이메일로 다시 로그인할 수 있습니다."))await signOut(auth)}if(b.id==="showConfigBtn")cfgShow();if(b.id==="hideConfigBtn")show("configPanel",false);if(b.id==="saveConfigBtn"){const raw=$("firebaseConfig").value.trim();const c=JSON.parse(raw);if(!c.apiKey||!c.projectId||!c.appId)throw Error("apiKey, projectId, appId 항목이 필요합니다.");localStorage.setItem("lpPersonalFirebaseConfig",JSON.stringify(c));location.reload()}if(b.id==="exportJsonBtn")await exportJSON();if(b.id==="exportBtn")await exportCSV();if(b.id==="importJsonBtn")alert("V7 공용 재고는 안전한 데이터 이전 절차가 필요합니다. 현재 직접 가져오기는 제한됩니다.");if(b.id==="createTeamBtn")await createTeam();if(b.id==="createProjectBtn")await createProject();if(b.dataset.createProjectTeam)await createProjectTeam(b.dataset.createProjectTeam);if(b.dataset.saveMemberName)await saveMemberName(b.dataset.saveMemberName);if(b.dataset.linkProject)await linkProject(b.dataset.linkProject);if(b.dataset.moveMember)await moveMember(b.dataset.moveMember);if(b.dataset.closeProject)await closeProject(b.dataset.closeProject);if(b.dataset.approve)await approveUser(b.dataset.approve);if(b.dataset.reject&&confirm("가입 신청을 거절할까요?"))await updateDoc(doc(db,"joinRequests",b.dataset.reject),{status:"rejected",updatedAt:serverTimestamp()});if(b.dataset.toggleTeam){const t=teamList.find(x=>x.id===b.dataset.toggleTeam);if(t&&confirm("팀 활성 상태를 변경할까요?"))await updateDoc(doc(db,"teams",t.id),{active:t.active===false})}}catch(err){alert("처리 중 오류: "+err.message)}});

$("gateLoginBtn").addEventListener("click",loginEmail);
$("gateLoginPassword").addEventListener("keydown",e=>{if(e.key==="Enter")$("gateLoginBtn").click()});
$("equipmentSearch").addEventListener("input",render);$("loanSearch").addEventListener("input",render);$("loanFilter").addEventListener("change",render);$("importFile").addEventListener("change",e=>importJSON(e.target.files?.[0]));
if(cfg()){try{$("firebaseConfig").value=cfg();initConfig(cfg())}catch(e){show("configPanel",true);status("설정 확인 필요");alert("Firebase 설정을 확인해 주세요: "+e.message)}}else{show("configPanel",true);show("setupNotice",true);status("초기 설정 필요")}
if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{});

$("signupBtn").addEventListener("click",signup);$("pendingSignOutBtn").addEventListener("click",()=>signOut(auth));

// V9.4: Team operations follow active project/team membership, not loan counts.
document.getElementById('activeTeamsCard')?.addEventListener('click',()=>{
 const active=teamList.filter(t=>t.active!==false&&projects.some(p=>p.id===t.projectId&&p.active!==false));
 const content=active.map(t=>{const p=projects.find(x=>x.id===t.projectId);const records=activeLoans().filter(l=>l.teamId===t.id);const staff=isAdmin()?membersList.filter(m=>m.teamId===t.id&&m.active!==false).map(m=>m.displayName||'이름 미등록').join(', '):'팀 소속 직원은 관리자 화면에서 확인';return `<div class="item" style="display:block;margin-bottom:9px"><div class="itemtitle">${esc(p?.name||'미연결 작품')} · ${esc(t.name)}</div><div class="meta">촬영 중 · 대여 ${records.length}건 / ${records.reduce((n,l)=>n+Number(l.quantity||0),0)}개<br>직원: ${esc(staff||'없음')}</div></div>`}).join('');
 modal('현재 촬영 중인 팀',content||'<div class="empty">진행 중인 작품에 연결된 활성 팀이 없습니다.</div>');
});

// Reservation pilot: independent reservation requests, admin review, and date overlap warnings.
const dateOverlap=(a,b,c,d)=>a<=d&&c<=b;
function reservationCard(r){const project=projects.find(p=>p.id===r.projectId),team=teamList.find(t=>t.id===r.teamId);const label={pending:'승인 대기',approved:'승인 완료',rejected:'거절',cancelled:'취소'}[r.status]||r.status;return `<div class="item"><div style="flex:1;min-width:0"><div class="itemtitle">${esc(project?.name||r.projectName||'작품 미지정')} · ${esc(team?.name||r.teamName||'팀 미지정')} <span class="pill ${r.status==='approved'?'green':r.status==='pending'?'amber':'red'}">${esc(label)}</span></div><div class="meta">${esc(r.startDate)} ~ ${esc(r.endDate)} · ${esc(r.person||'담당자 미등록')}<br>${(r.items||[]).map(i=>esc(i.name)+' '+Number(i.qty)+'개').join(' / ')}${r.note?'<br>'+esc(r.note):''}</div></div><div class="actions">${isAdmin()&&r.status==='pending'?`<button class="small" data-approve-reservation="${esc(r.id)}">승인</button><button class="small secondary" data-reject-reservation="${esc(r.id)}">거절</button>`:''}${r.status==='pending'&&(isAdmin()||r.ownerUid===currentUser?.uid)?`<button class="small secondary" data-cancel-reservation="${esc(r.id)}">취소</button>`:''}</div></div>`}
function renderReservations(){const target=$('reservationList');if(!target)return;const sorted=[...reservations].sort((a,b)=>(b.startDate||'').localeCompare(a.startDate||''));target.innerHTML=sorted.length?sorted.map(reservationCard).join(''):'<div class="empty">예약 내역이 없습니다.</div>';}
function openReservation(){const activeTeams=teamList.filter(t=>t.active!==false&&projects.some(p=>p.id===t.projectId&&p.active!==false));if(!activeTeams.length)return alert('먼저 작품에 활성 팀을 등록해 주세요.');const options=(isAdmin()?activeTeams:activeTeams.filter(t=>t.id===teamId)).map(t=>{const p=projects.find(p=>p.id===t.projectId);return `<option value="${esc(t.id)}">${esc(p?.name||'작품 미지정')} · ${esc(t.name)}</option>`}).join('');if(!options)return alert('현재 소속된 활성 촬영팀이 없습니다. 관리자에게 문의해 주세요.');const items=equipment.map(e=>`<div class="item"><div style="flex:1"><b>${esc(e.name)}</b><div class="meta">${Number(e.total||0)===0?'수량 미확정':`보유 ${Number(e.total||0)}개`}</div></div><input style="width:75px" type="number" min="0" max="9999" value="0" data-reserve-qty="${esc(e.id)}"></div>`).join('');modal('장비 일괄 예약 신청',`<div class="notice">예약 기간은 시작일·종료일 모두 포함해요. 승인된 예약과 일정이 겹치면 승인 시 재확인합니다. 예약 승인만으로 재고가 출고 처리되지는 않습니다.</div><div class="field"><label>작품 · 팀</label><select id="reserveTeam">${options}</select></div><div class="field"><label>시작일 *</label><input id="reserveStart" type="date" min="${today()}" value="${today()}"></div><div class="field"><label>종료일 *</label><input id="reserveEnd" type="date" min="${today()}" value="${today()}"></div><div class="field"><label>메모</label><input id="reserveNote" placeholder="촬영 장소, 요청 사항"></div><h3>예약 장비 수량</h3><div class="list">${items}</div><button id="submitReservation">예약 신청</button>`)}
async function submitReservation(){const t=teamList.find(x=>x.id===$('reserveTeam')?.value),p=projects.find(x=>x.id===t?.projectId),startDate=$('reserveStart')?.value,endDate=$('reserveEnd')?.value,note=$('reserveNote')?.value.trim();const items=[...document.querySelectorAll('[data-reserve-qty]')].map(x=>({id:x.dataset.reserveQty,qty:Number(x.value),name:equipment.find(e=>e.id===x.dataset.reserveQty)?.name||''})).filter(x=>Number.isInteger(x.qty)&&x.qty>0);if(!t||!p||p.active===false||t.active===false)return alert('진행 중인 작품과 팀을 선택하세요.');if(!startDate||!endDate||startDate<today()||endDate<startDate)return alert('예약 날짜를 확인해 주세요.');if(!items.length||items.length>20)return alert('1~20종의 장비를 선택하세요.');if(items.some(i=>i.qty>9999))return alert('수량은 9999개 이하로 입력하세요.');const btn=$('submitReservation');btn.disabled=true;try{await addDoc(reservationCol(),{projectId:p.id,projectName:p.name,teamId:t.id,teamName:t.name,ownerUid:currentUser.uid,person:isAdmin()?'관리자':member?.displayName||teamName,startDate,endDate,note,items,status:'pending',createdAt:serverTimestamp(),updatedAt:serverTimestamp()});closeModal();alert('예약 신청 완료! 관리자 승인을 기다려 주세요.')}catch(e){alert('예약 신청 실패: '+e.message);btn.disabled=false}}
async function reviewReservation(id,decision){const r=reservations.find(x=>x.id===id);if(!isAdmin()||!r||r.status!=='pending')return;const p=projects.find(x=>x.id===r.projectId),t=teamList.find(x=>x.id===r.teamId);if(decision==='approved'&&(!p||p.active===false||!t||t.active===false))return alert('종료된 작품 또는 비활성 팀은 승인할 수 없습니다.');if(decision==='approved'){const conflicts=[];for(const i of r.items||[]){const eq=equipment.find(x=>x.id===i.id);if(!eq){conflicts.push(i.name+' (삭제된 장비)');continue}if(Number(eq.total||0)===0)continue;const reserved=reservations.filter(x=>x.id!==id&&x.status==='approved'&&dateOverlap(x.startDate,x.endDate,r.startDate,r.endDate)).reduce((sum,x)=>sum+(x.items||[]).filter(z=>z.id===i.id).reduce((n,z)=>n+Number(z.qty||0),0),0);const free=Number(eq.total||0)-Number(eq.loaned||0)-Number(eq.repairing||0)-reserved;if(i.qty>free)conflicts.push(`${i.name}: 요청 ${i.qty}개 / 추정 가용 ${free}개`)}if(conflicts.length)return alert('예약 충돌 또는 수량 부족: '+conflicts.join(' / ')+' 다른 예약·대여 현황을 확인하세요.');}if(!confirm(decision==='approved'?'예약을 승인할까요?':'예약을 거절할까요?'))return;await updateDoc(doc(reservationCol(),id),{status:decision,updatedAt:serverTimestamp()})}
async function cancelReservation(id){const r=reservations.find(x=>x.id===id);if(!r||r.status!=='pending'||!(isAdmin()||r.ownerUid===currentUser?.uid))return;if(confirm('예약 신청을 취소할까요?'))await updateDoc(doc(reservationCol(),id),{status:'cancelled',updatedAt:serverTimestamp()})}
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;try{if(b.id==='openReservationBtn')openReservation();if(b.id==='submitReservation')await submitReservation();if(b.dataset.approveReservation)await reviewReservation(b.dataset.approveReservation,'approved');if(b.dataset.rejectReservation)await reviewReservation(b.dataset.rejectReservation,'rejected');if(b.dataset.cancelReservation)await cancelReservation(b.dataset.cancelReservation)}catch(err){alert('예약 처리 오류: '+err.message)}});
