const assert=require('assert');
(async()=>{
 const h=await import('../www/loan-groups.js'),m=await import('../www/equipment-schedule-model.js');
 const base={teamId:'A',team:'본팀',projectId:'P',equipmentId:'par',equipmentName:'18K PAR',equipmentGroup:'상주장비',status:'active',quantity:1,loanDate:'2026-10-01',dueDate:'2027-02-28',person:'기사1',ownerUid:'coworker'};
 const loans=[{...base,id:'one'},{...base,id:'two',projectId:undefined,loanDate:'2026-10-31',person:'기사2'},{...base,id:'extra',equipmentGroup:'추가장비'},{...base,id:'other',teamId:'B',projectId:'Q',quantity:7},{...base,id:'done',status:'returned',quantity:100},{...base,id:'external',rentalType:'external',externalTeam:'외부'}];
 const held=h.teamHeldLoans(loans,'A');assert.deepEqual(held.map(l=>l.id),['one','two','extra']);const summary=h.summarizeHeldEquipment(held);assert.equal(summary.length,1);assert.equal(summary[0].quantity,3);assert.deepEqual(summary[0].groups,{'상주장비':2,'추가장비':1});assert.equal(h.teamHeldLoans(loans,'').length,0);
 const units=h.summarizeHeldEquipment([{...base,id:'ea'},{...base,id:'box',unit:'BOX',unitsPerBox:2},{...base,id:'box2',unit:'BOX',unitsPerBox:4},{...base,id:'sameName',equipmentId:'different'}]);assert.equal(units.length,4);
 const teams=[{id:'A',name:'본팀',projectId:'P'},{id:'B',name:'본팀',projectId:'Q'}],projects=[{id:'P',name:'언내추럴'},{id:'Q',name:'다른작품'}];
 const before=JSON.stringify(loans),events=m.buildEquipmentSchedule({loans:loans.slice(0,5),teams,projects,today:'2026-10-31',through:'2027-02-28'});assert.equal(JSON.stringify(loans),before);
 const own=day=>m.scheduleEventsOnDay(events,day).filter(e=>e.kind==='loan'&&e.state!=='returned'&&e.team==='언내추럴 · 본팀');
 assert.equal(own('2027-01-05').length,2);const resident=own('2027-01-05').find(e=>e.group==='상주장비');assert.equal(resident.items.length,1);assert.equal(resident.items[0].qty,2);assert.equal(resident.sourceEvents.length,2);assert(resident.person.includes('기사1')&&resident.person.includes('기사2'));
 assert.equal(own('2026-10-15').find(e=>e.group==='상주장비').items[0].qty,1);assert.equal(own('2027-03-01').length,0);
 assert.equal(events.filter(e=>e.kind==='returnDue'&&e.team==='언내추럴 · 본팀'&&e.group==='상주장비').length,1);
 const gaps=m.buildEquipmentSchedule({loans:[{...base,id:'gap1',dueDate:'2026-10-02'},{...base,id:'gap2',loanDate:'2026-10-05',dueDate:'2026-10-06'}],teams,projects,today:'2026-10-01',through:'2026-10-31'});assert.equal(gaps.filter(e=>e.kind==='loan').length,2);assert.equal(m.scheduleEventsOnDay(gaps,'2026-10-03').length,0);
 console.log('PASS team holdings: exact team scope, coworker records, returned/external exclusion, group sums, distinct IDs and BOX snapshots, calendar team/category merging, date-specific quantities, return-day grouping, no gap events and immutable inputs');
})().catch(e=>{console.error(e);process.exit(1)});
