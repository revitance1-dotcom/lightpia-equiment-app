export const ADMIN_UID='7iSB1gW9PAhYPgi253IUk4Dooyp2';
export function validateOperation(id,data){
 if(data.createdBy!==ADMIN_UID||!['delete_user','delete_project','delete_team'].includes(data.type)||typeof data.targetId!=='string'||!data.targetId||data.targetId.length>128||data.targetId.includes('/')||id!==data.type+'_'+data.targetId)throw Error('허용되지 않은 삭제 요청입니다.');
 if(data.type==='delete_user'&&data.targetId===ADMIN_UID)throw Error('관리자 계정은 삭제할 수 없습니다.');
}
export async function deleteUserAccount({db,auth,FieldValue},op){
 const uid=op.targetId,member=db.collection('members').doc(uid),request=db.collection('joinRequests').doc(uid);
 const [m,r]=await Promise.all([member.get(),request.get()]);
 if(m.exists&&m.data().role!=='team')throw Error('직원 계정만 삭제할 수 있습니다.');
 // A retry after Auth deletion may only have the profile or join request left.
 if(!m.exists&&!r.exists){
  try{await auth.getUser(uid);throw Error('등록된 직원 정보가 없는 계정입니다.');}catch(e){if(e.code!=='auth/user-not-found')throw e;}
  return;
 }
 if(m.exists)await member.update({active:false,updatedAt:FieldValue.serverTimestamp()});
 try{await auth.updateUser(uid,{disabled:true});await auth.revokeRefreshTokens(uid);await auth.deleteUser(uid);}catch(e){if(e.code!=='auth/user-not-found')throw e;}
 const batch=db.batch();batch.delete(member);batch.delete(request);await batch.commit();
}
export async function deleteClosedProject({db},op){
 const ref=db.collection('projects').doc(op.targetId);
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 await db.runTransaction(async tx=>{
  const p=await tx.get(ref);if(!p.exists)return;
  if(p.data().active!==false)throw Error('종료된 작품만 삭제할 수 있습니다.');
  const teams=await tx.get(db.collection('teams').where('projectId','==',op.targetId));
  if(teams.size>400)throw Error('연결된 팀이 너무 많습니다. 관리자 점검이 필요합니다.');
  const loans=await tx.get(db.collection('company/main/loans').where('projectId','==',op.targetId));
  const bookings=await tx.get(db.collection('company/main/reservations').where('projectId','==',op.targetId));
  if(loans.docs.some(d=>d.data().status!=='returned'))throw Error('미반납 장비를 먼저 반납해 주세요.');
  if(bookings.docs.some(d=>['pending','approved'].includes(d.data().status)&&(!d.data().endDate||d.data().endDate>=today)))throw Error('유효한 예약을 먼저 취소해 주세요.');
  for(const t of teams.docs){
   const legacy=await tx.get(db.collection('company/main/loans').where('teamId','==',t.id));
   if(legacy.docs.some(d=>!d.data().projectId&&d.data().status!=='returned'))throw Error('연결 팀의 이전 미반납 기록을 먼저 반납해 주세요.');
  }
  // Team documents remain as historical references. Disable them before removing the project.
  for(const t of teams.docs)if(t.data().active!==false)tx.update(t.ref,{active:false});
  tx.delete(ref);
 });
}
export async function deleteClosedTeam({db,FieldValue},op){
 const ref=db.collection('teams').doc(op.targetId);
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 await db.runTransaction(async tx=>{
  const team=await tx.get(ref);if(!team.exists)return;
  if(team.data().active!==false)throw Error('종료·보관된 팀만 삭제할 수 있습니다.');
  const loans=await tx.get(db.collection('company/main/loans').where('teamId','==',op.targetId));
  const bookings=await tx.get(db.collection('company/main/reservations').where('teamId','==',op.targetId));
  const members=await tx.get(db.collection('members').where('teamId','==',op.targetId));
  if(loans.docs.some(d=>d.data().status!=='returned'))throw Error('이 팀의 미반납 장비를 먼저 반납해 주세요.');
  if(bookings.docs.some(d=>['pending','approved'].includes(d.data().status)&&(!d.data().endDate||d.data().endDate>=today)))throw Error('이 팀의 유효 예약을 먼저 취소해 주세요.');
  if(members.size>400)throw Error('소속 직원이 너무 많습니다. 관리자 점검이 필요합니다.');
  for(const m of members.docs)tx.update(m.ref,{teamId:FieldValue.delete(),projectId:FieldValue.delete(),teamName:'대기 직원',updatedAt:FieldValue.serverTimestamp()});
  tx.delete(ref);
 });
}
export async function processAdminOperations(ctx){
 const {db,FieldValue,Timestamp}=ctx;
 const snapshots=await Promise.all(['pending','processing'].map(status=>db.collection('adminOperations').where('status','==',status).limit(30).get()));
 let done=0,failed=0;
 for(const item of snapshots.flatMap(s=>s.docs)){
  const token=crypto.randomUUID();
  const op=await db.runTransaction(async tx=>{
   const snap=await tx.get(item.ref);if(!snap.exists)return null;const d=snap.data();
   if(d.status!=='pending'&&!(d.status==='processing'&&(d.lockUntil?.toMillis()||0)<Date.now()))return null;
   tx.update(item.ref,{status:'processing',workerToken:token,lockUntil:Timestamp.fromMillis(Date.now()+10*60*1000),updatedAt:FieldValue.serverTimestamp(),attempts:FieldValue.increment(1)});
   return d;
  });
  if(!op)continue;
  try{
   validateOperation(item.id,op);
   if(op.type==='delete_user')await deleteUserAccount(ctx,op);else if(op.type==='delete_team')await deleteClosedTeam(ctx,op);else await deleteClosedProject(ctx,op);
   await finish('completed','');done++;
  }catch(e){await finish('failed',String(e.message||e).slice(0,400));failed++;}
  async function finish(status,error){await db.runTransaction(async tx=>{const snap=await tx.get(item.ref);if(snap.exists&&snap.data().workerToken===token)tx.update(item.ref,{status,error,updatedAt:FieldValue.serverTimestamp(),completedAt:status==='completed'?FieldValue.serverTimestamp():null,lockUntil:Timestamp.fromMillis(0)});});}
 }
 console.log('Admin operations:',done,'completed,',failed,'failed');return {done,failed};
}
