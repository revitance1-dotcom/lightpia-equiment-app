# Lightpia & Softsun V7 — Spark shared team inventory (pilot)

## Important: deploy rules BEFORE using V7
1. Keep your V6 JSON backup safe. V7 uses a NEW shared database path, so existing V6 data will NOT automatically appear.
2. In Firebase Console > Firestore Database > Rules, replace the old rules with `www/firestore.rules`, then Publish. This REPLACES V6 per-user access; use V6 only for reading saved backups, not for further production writes.
3. Firebase Console > Authentication > Sign-in method: enable Email/Password. The admin Firebase Auth UID must be `7iSB1gW9PAhYPgi253IUk4Dooyp2`.
4. Sign in to V7 with the admin account. Under Settings > Team accounts, register teams by name and UID.
5. For each team, create an Email/Password user in Firebase Console > Authentication > Users; copy that user's UID into the V7 admin team form. Share that team's email/password privately.
6. Team members sign in with their assigned account. They can see company equipment, borrow, and return their OWN team's loans. A loan is tagged with authenticated UID and team name.
7. Test with 1 dummy equipment item, 2 separate team accounts, and concurrent borrowing before company use.

## Security and known limitations
- Firebase Spark: no Cloud Functions required. Access is enforced by Firestore Security Rules, not hidden UI controls.
- Borrow/return uses Firestore transactions and an inventory counter. Firestore rules check paired loan+equipment writes.
- Repair record modifications are temporarily DISABLED, so `repairing` remains zero for new items. This is a pilot, not a finished repair workflow.
- JSON export and CSV export work; V7 JSON import is intentionally disabled to prevent bypassing shared inventory counters. To migrate V6 data, use a reviewed one-time migration script or manually register inventory in V7.
- Admin registers team UID after creating the Firebase Auth user; the app does not create Auth users automatically.
- Team credential sharing means all users of that team account have the same privileges and activity cannot be attributed to individuals.
- iOS requires HTTPS PWA hosting, or a separate signed iOS build. APK workflow is Android only.
- The ZIP is source code. An actual Android APK is built by GitHub Actions. No device test has been performed here.
