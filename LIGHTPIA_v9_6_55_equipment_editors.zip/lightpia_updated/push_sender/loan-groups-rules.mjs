import fs from 'node:fs';
export function patchLoanGroupsRules(source){
 if(source.includes('LNS_LOAN_GROUPS_V1'))return patchRegisteredLoanTeams(source);
 const anchor='match /company/main/loans/{loanId}',start=source.indexOf(anchor),end=source.indexOf('match /company/main/reservations/',start);
 if(start<0||end<0||source.indexOf(anchor,start+anchor.length)>=0)throw Error('Unexpected loan rule layout');
 let block=source.slice(start,end);
 const old="'teamId','projectId'])";
 if(!block.includes(old)||!block.includes('   allow delete:'))throw Error('Unexpected loan create rules');
 block=block.replace(old,"'teamId','projectId','rentalType','equipmentGroup','externalTeam','externalPerson']) && lnsLoanClassification(request.resource.data)");
 block=block.replace('   allow delete:',`   allow update: if admin() && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['rentalType','equipmentGroup','externalTeam','externalPerson','updatedAt']) && lnsLoanClassification(request.resource.data);
   allow delete:`);
 const helper=fs.readFileSync(new URL('./loan-groups.rules',import.meta.url),'utf8');
 return patchRegisteredLoanTeams(source.slice(0,start)+helper+'  '+block+source.slice(end));
}
export function patchRegisteredLoanTeams(source){
 if(source.includes('LNS_REGISTERED_LOAN_TEAMS_V2'))return source;
 const old="function validTeamForCreate(d) { return admin() ? d.get('teamId', 'admin') == 'admin' : (activeTeamMember() && d.get('teamId', '') == profile().teamId); }";
 if(!source.includes(old))throw Error('Unexpected team assignment permission rule');
 source=source.replace(old,"function validTeamForCreate(d) { return admin() ? (d.get('teamId', 'admin') == 'admin' || lnsRegisteredTeamLoan(d)) : (activeTeamMember() && d.get('teamId', '') == profile().teamId); }");
 const start=source.indexOf('match /company/main/loans/{loanId}'),end=source.indexOf('match /company/main/reservations/',start);
 let block=source.slice(start,end);
 if(!block.includes("'externalPerson'])")||!block.includes('request.resource.data.team == teamName()'))throw Error('Unexpected loan data rules');
 block=block.replace("'externalPerson'])","'externalPerson','projectName'])").replace('&& lnsLoanClassification(request.resource.data)','&& lnsLoanClassification(request.resource.data) && lnsLoanProjectNameMatches(request.resource.data)').replace('request.resource.data.team == teamName()','lnsLoanTeamNameMatches(request.resource.data)');
 // Only the first classification predicate belongs to create; metadata updates keep snapshot fields immutable.
 const helper=fs.readFileSync(new URL('./registered-loan-teams.rules',import.meta.url),'utf8');
 return source.slice(0,start)+helper+'  '+block+source.slice(end);
}
