import admin from 'firebase-admin';
const json=process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
if(!json)throw Error('Missing FIREBASE_SERVICE_ACCOUNT_JSON secret');
const serviceAccount=JSON.parse(json);
admin.initializeApp({credential:admin.credential.cert(serviceAccount)});
const db=admin.firestore();
const messaging=admin.messaging();
const now=Date.now();
// Ignore older reservations: prevents sending alerts for historical data at rollout.
const earliest=admin.firestore.Timestamp.fromMillis(now-24*3600*1000);
const reservations=await db.collection('company/main/reservations').where('status','==','pending').where('createdAt','>=',earliest).get();
const devices=await db.collection('adminPushDevices').where('enabled','==',true).get();
console.log('DIAG pending reservations in last 24h:',reservations.size);
console.log('DIAG enabled admin devices:',devices.size);
console.log('DIAG reservation IDs:',reservations.docs.map(d=>d.id).join(', ')||'(none)');
if(devices.empty){console.log('No registered admin device; skipping.');process.exit(0);}
for(const item of reservations.docs){
 const reservation=item.data();
 const receipt=db.collection('adminPushDispatch').doc(item.id);
 // Lock to avoid duplicate sends across overlapping scheduled/manual runs.
 const claimed=await db.runTransaction(async tx=>{
  const snap=await tx.get(receipt);
  const data=snap.exists?snap.data():{};
  if(data.state==='sent'||(data.state==='sending'&&data.lockUntil?.toMillis()>now))return false;
  tx.set(receipt,{state:'sending',lockUntil:admin.firestore.Timestamp.fromMillis(now+10*60*1000),attempts:admin.firestore.FieldValue.increment(1),updatedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});
  return true;
 });
 if(!claimed){console.log('DIAG already sent or locked:',item.id);continue;}
 const items=Array.isArray(reservation.items)?reservation.items:[];
 const title='Lightpia · 새 장비 예약';
 const body=`${reservation.projectName||'작품'} · ${reservation.teamName||'팀'} / ${items.length}종 / ${reservation.startDate||''} ~ ${reservation.endDate||''}`.slice(0,220);
 let success=0, failures=[];
 for(const device of devices.docs){
  try{
   await messaging.send({token:device.data().token,notification:{title,body},data:{type:'reservation',reservationId:item.id},android:{priority:'high',notification:{channelId:'reservation_alerts',clickAction:'FCM_PLUGIN_ACTIVITY'}}});
   success++;
  }catch(e){
   console.error('Push failed',device.id,e.code||e.message);
   failures.push(String(e.code||e.message));
   if(['messaging/registration-token-not-registered','messaging/invalid-registration-token'].includes(e.code))await device.ref.update({enabled:false});
  }
 }
 if(success>0)await receipt.set({state:'sent',sentAt:admin.firestore.FieldValue.serverTimestamp(),successCount:success},{merge:true});
 else await receipt.set({state:'failed',error:failures.join('; ').slice(0,500),updatedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});
 console.log('Reservation',item.id,'success',success,'failed',failures.length);
}

console.log('DIAG sender completed');
