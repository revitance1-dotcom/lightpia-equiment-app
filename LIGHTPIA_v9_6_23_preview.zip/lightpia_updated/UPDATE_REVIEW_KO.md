# LIGHTPIA V9.6.23 초기 수정본 — 검토 및 구현 현황

기준: lightpia_equipment_v9_6_22_push_spark(3).zip. 전체 14개 완료본이 아닌 첫 구현본입니다.
실제 Firebase 접근, 데이터 변경, 규칙 배포, APK 빌드는 수행하지 않았습니다.

## 구조
- www/index.html: 화면, 스타일. www/app.js: Firebase 인증, 실시간 구독, 장비/대여/예약/직원/작품 기능이 집중된 ES 모듈.
- Firebase JS SDK 10.14.1 CDN, Firestore 실시간 구독, 대여/반납 runTransaction, 승인 writeBatch.
- Capacitor 6 Android 래퍼. Android 네이티브 폴더와 google-services.json은 ZIP에 없음. build-apk.yml과 설정 문서를 통해 생성하는 구조.
- push_sender/send.mjs: 별도 관리자 푸시 발송 작업. 관리자 UID는 클라이언트 및 규칙에 고정됨.
- 수량 0은 재고 미확정으로 취급하는 기존 정책. 기존 문서 ID와 collection 경로 유지.

## 14개 요청의 구현 위치 및 현황
| 요청 | 위치 및 처리 |
|---|---|
| 1 로고 업스케일 | company-logo.png, brand-hero.jpg, 아이콘 세트 및 index.html 브랜드 CSS. 미구현. 원본 이미지 검토 후 교체 필요. |
| 2 알림 설정창 반복 | enableAdminPush(), index.html adminPushPanel. 코드상 권한 요청은 등록 버튼 클릭 때만 발생. 자동 호출은 발견되지 않음. Android 기기 재현 필요. 규칙 사본 불일치 수정은 이 증상 해결을 보장하지 않음. |
| 3 종료 작품 관리자 삭제 | renderProjects(), closeProject(), projects 규칙. 미구현. 팀/대여/예약의 참조를 보존하는 숨김 또는 보관 삭제 설계 권장. 현재 실제 삭제는 규칙에서 차단. |
| 4 관리자 계정 삭제 | renderProjects() 직원 목록, members/joinRequests, Firebase Auth. 미구현. 프로필 삭제만으로 Auth 계정이 삭제되지 않음. 관리자 인증을 검증하는 Admin SDK 서버 엔드포인트 필요. 과거 대여 ownerUid 보존 필요. |
| 5 날짜 선택 화면 가림 | modal(), index.html 모달 CSS. 스크롤 여백과 날짜 입력 폭 보정 적용. Android 기본 날짜 선택창과 키보드 가림은 기기 검증 필요. |
| 6 관리자 장비 일괄 등록 | addEquipment(), importJSON(). 미구현. 기존 JSON 복원은 신규 장비만 지원. 별도 입력 미리보기/중복검사 후 한정된 batch 쓰기 필요. |
| 7 관리자 수리 등록 | addRepair(), repairDoc(), equipment.repairing, repairs 규칙. 미구현. 현재 함수 앞 조기 return 및 쓰기 금지. 단순 차단 해제로는 재고가 틀어짐. 양 문서를 원자적으로 변경하는 트랜잭션과 대응 규칙 필요. |
| 8 수리/고장 역할 분리 | showEquipmentDetail(), addRepair(), repairs 규칙. 미구현. 직원 고장 신고와 관리자 수리 이관을 구분하고 재고 중복 차감 방지 필요. |
| 9 관리자 이미지 추가 | addEquipment(), showEquipmentDetail(). 미구현. 장비 이미지로 해석하였으나 대상 확인 필요. Storage 업로드/용량/권한 규칙 및 기존 이미지 없는 문서 호환 필요. |
| 10 구인글 등록 | 신규 게시판 UI와 collection/rules 필요. 미구현. 직책/팀명/날짜/페이/비고 및 작성·삭제 권한 설계 필요. |
| 11 검색어 강화 | addEquipment(), render(), renderCart(), 예약 검색. searchTags 문자열 입력 및 검색 반영 완료. 기존 문서는 필드 없이도 동작. #sun 입력 가능. 현재 단순 부분문자열 검색. |
| 12 팀 없이 가입/승인 | signup(), renderTeamAdmin(), approveUser(), joinRequests 규칙. 희망 팀 선택 입력으로 변경. 팀 미배정 대기 직원 승인 가능. members와 joinRequests를 단일 batch로 승인. 기존 activeTeamMember 규칙에 따라 대기 직원은 열람 가능하나 대여/예약 불가. |
| 13 수량 0 장비 대여 표시 | render(), renderCart(), borrowedQtyFor(). 목록과 대여 선택 화면에서 음수 잔여 대신 미확정 상태와 실제 대여 집계 표시. 기존 거래 정책 유지. 장비 상세의 수량 표현은 추가 정리 필요. |
| 14 대여일/반납예정일 연결 | addLoan() cartDate/cartDue. 대여일 변경 시 반납일 최솟값 갱신, 비어 있거나 앞선 반납일 자동 보정, 반납일로 초점 이동. 이미 더 늦은 반납일은 보존. 저장 시 역전 날짜 차단 유지. |

## 추가 수정
루트 firestore.rules에는 adminPushDevices 규칙이 있으나 www/firestore.rules에는 빠져 있었습니다. 루트의 기존 권한을 유지하며 두 사본을 동일하게 맞췄습니다. 서비스워커 캐시 버전을 갱신했습니다.

## 검증
- Node ES 모듈 문법 검사 통과.
- 격리된 모의 실행: 팀 미배정 승인, 활성 팀 승인, 비활성 팀 승인 거부 통과.
- 날짜 보정: 앞선 날짜, 빈 날짜, 이미 뒤인 날짜 3개 사례 통과.
- 두 규칙 파일 일치 확인 통과.
- Firebase Emulator 권한 테스트, Android 화면 검증, APK 빌드는 미실행. 운영 배포 준비 완료로 간주하면 안 됩니다.

## 적용 전
팀 선택 가입을 허용하려면 동봉된 루트 firestore.rules 변경을 별도로 검토·배포해야 합니다. 현재 운영 규칙은 변경하지 않았습니다. 기존 Firebase 설정, 관리자 UID, 대여/반납 트랜잭션, 데이터 경로를 유지했습니다. 기존 데이터의 자동 마이그레이션/삭제는 없습니다.
검증 재현 파일은 review/check.cjs에 포함. 프로젝트 폴더에서 node review/check.cjs 실행.
