import {patchLoanExtensionRules} from './loan-extension-rules.mjs';
import {patchPartialReturnRules} from './partial-return-rules.mjs';
import {patchSerialRegisterRules} from './serial-register-rules.mjs';
import {patchTeamDirectoryRules} from './team-directory-rules.mjs';
import {patchNotificationRules} from './notifications-rules.mjs';
import {patchEquipmentEditorRules} from './equipment-editors-rules.mjs';
import {patchDisplayOrderRules} from './display-order-rules.mjs';
import {patchReservationFulfillmentRules} from './reservation-fulfillment-rules.mjs';
import {patchAvailabilityRules} from './availability-rules.mjs';
import {patchDamageEaRules} from './damage-ea-rules.mjs';
import {patchEquipmentUnitsRules} from './equipment-units-rules.mjs';
import {patchExternalReservationRules} from './external-reservations-rules.mjs';
import {patchLoanGroupsRules} from "./loan-groups-rules.mjs";
import {patchSignupRules} from "./signup-rules.mjs";
import {patchPhotosCrewRules} from './photos-crew-rules.mjs';
import admin from 'firebase-admin';
import fs from 'node:fs';
import {patchMaintenanceRules,patchReportCancellationRules} from './maintenance-rules.mjs';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');
if(!account||account.project_id!=='light-4e07d')throw Error('Expected configured Lightpia service account.');
admin.initializeApp({credential:admin.credential.cert(account)});
const active=await admin.securityRules().getFirestoreRuleset();
if(active.source.length!==1)throw Error('Expected a single active Firestore rules file.');
const before=active.source[0].content;
const addition=fs.readFileSync(new URL('./admin-operations.rules',import.meta.url),'utf8');
let after=before;
if(!before.includes('LNS_ADMIN_OPERATIONS_V1')){
 if(/match\s+\/adminOperations\//.test(before))throw Error('Existing adminOperations rules require manual review.');
 const match=before.match(/match\s+\/databases\/\{([^}]+)\}\/documents\s*\{/);
 if(!match||match[1]!=='database')throw Error('Unexpected rules structure.');
 const at=match.index+match[0].length;after=before.slice(0,at)+'\n'+addition+before.slice(at);
}
// Upgrade only the existing queue target predicate; preserve unrelated rules.
if(!after.includes("d.type == 'delete_team'")){
 const old="&& get(/databases/$(database)/documents/projects/$(d.targetId)).data.active == false));";
 if(!after.includes(old))throw Error('Unexpected administrator queue predicate.');
 after=after.replace(old,"&& get(/databases/$(database)/documents/projects/$(d.targetId)).data.active == false)\n      || (d.type == 'delete_team' && exists(/databases/$(database)/documents/teams/$(d.targetId))\n       && get(/databases/$(database)/documents/teams/$(d.targetId)).data.active == false));");
}
after=patchLoanGroupsRules(patchSignupRules(patchPhotosCrewRules(patchReportCancellationRules(patchMaintenanceRules(after)))));
after=patchReservationFulfillmentRules(patchAvailabilityRules(patchDamageEaRules(patchEquipmentUnitsRules(patchExternalReservationRules(after)))));
after=patchEquipmentEditorRules(patchDisplayOrderRules(after));
after=patchTeamDirectoryRules(patchNotificationRules(after));
after=patchSerialRegisterRules(after);
after=patchLoanExtensionRules(patchPartialReturnRules(after));
fs.mkdirSync('/tmp/lightpia-rules',{recursive:true});
fs.writeFileSync('/tmp/lightpia-rules/before.rules',before);fs.writeFileSync('/tmp/lightpia-rules/candidate.rules',after);
fs.writeFileSync('/tmp/lightpia-rules/base.json',JSON.stringify({rulesetName:active.name,changed:after!==before}));
console.log(after===before?'Admin queue rules already enabled.':'Prepared maintenance-aware inventory rules; unrelated access rules preserved.');
