import fs from 'node:fs';
function block(s,anchor,replacement){const start=s.indexOf(anchor);if(start<0||s.indexOf(anchor,start+anchor.length)>=0)throw Error('Unexpected damage EA anchor '+anchor);const open=s.indexOf('{',start+anchor.length);let d=1,q='',esc=false;for(let i=open+1;i<s.length;i++){const c=s[i];if(q){if(esc)esc=false;else if(c==='\\')esc=true;else if(c===q)q='';continue;}if(c==='"'||c==="'"){q=c;continue;}if(c==='{')d++;if(c==='}'&&--d===0)return s.slice(0,start)+replacement+s.slice(i+1);}throw Error('Unbalanced rules');}
export function patchDamageEaRules(source){
 if(source.includes('LNS_DAMAGE_EA_V1'))return source;
 if(!source.includes('LNS_EQUIPMENT_UNITS_V1'))throw Error('Equipment units rules required');
 source=source.replace('function validQty(d) {',fs.readFileSync(new URL('./damage-ea.rules',import.meta.url),'utf8')+'\n  function validQty(d) {');
 source=source.replace('return lnsUnit(d) && d.total is int','return lnsUnit(d) && lnsEaStockValid(d) && d.total is int');
 source=block(source,'function lnsUnitChangeAllowed(a,b)',"function lnsUnitChangeAllowed(a,b) { return lnsSameUnit(a,b) || (admin() && a.loaned == 0 && a.repairing == 0 && a.get('brokenStock',0) == 0 && a.get('brokenEa',0) == 0 && a.get('repairingEa',0) == 0); }");
 source=block(source,'function lnsDamageLoanChange(id)',`function lnsDamageLoanChange(id) {
   let b=resource.data;let a=request.resource.data;let p=lnsReportPath(a.lastDamageId);let r=getAfter(p).data;let key=lnsDamageKey(r);
   return a.diff(b).affectedKeys().hasOnly([key,'lastDamageId','updatedAt'])
    && a.get(key,0) is int && a.get(key,0) >= 0 && lnsDamageTotal(a) <= b.quantity*lnsPack(b)
    && r.loanId == id && r.equipmentId == b.equipmentId && r.quantity is int && r.quantity > 0
    && ((!exists(p) && b.status == 'active' && loanOwner(b) && r.status == 'reported' && r.reporterUid == request.auth.uid && (b.get('unit','EA') != 'BOX' || r.get('quantityUnit','') == 'EA') && a.get(key,0) == b.get(key,0)+r.quantity)
      || (exists(p) && get(p).data.status in ['reported','repairing'] && ((r.status == 'cancelled' && lnsCanCancelReport(get(p).data)) || (r.status == 'completed' && admin())) && a.get(key,0) == b.get(key,0)-r.quantity));
  }`);
 source=block(source,'function lnsMaintenanceStockChange(equipmentId)',`function lnsMaintenanceStockChange(equipmentId) {
   let b=resource.data;let a=request.resource.data;let p=lnsReportPath(a.lastMaintenanceId);let r=get(p).data;let n=getAfter(p).data;let l=get(loanPath(r.loanId)).data;let bk=lnsBrokenKey(r);let rk=lnsRepairKey(r);let pk=lnsReportRepairKey(r);
   return (admin() || (n.status == 'cancelled' && lnsCanCancelReport(r))) && a.diff(b).affectedKeys().hasOnly([bk,rk,pk,'lastMaintenanceId','updatedAt'])
    && lnsOtherStockSame(a,b,r) && r.equipmentId == equipmentId && r.quantity is int && r.quantity > 0 && l.status == 'returned'
    && ((r.status == 'reported' && n.status == 'repairing' && a.get(bk,0) == b.get(bk,0)-r.quantity && a.get(rk,0) == b.get(rk,0)+r.quantity && a.get(pk,0) == b.get(pk,0)+r.quantity)
      || (r.status == 'repairing' && n.status in ['completed','cancelled'] && a.get(bk,0) == b.get(bk,0) && a.get(rk,0) == b.get(rk,0)-r.quantity && a.get(pk,0) == b.get(pk,0)-r.quantity)
      || (r.status == 'reported' && n.status == 'cancelled' && a.get(bk,0) == b.get(bk,0)-r.quantity && a.get(rk,0) == b.get(rk,0) && a.get(pk,0) == b.get(pk,0)));
  }`);
 const start=source.indexOf('match /company/main/damageReports/{reportId}'),end=source.indexOf('\n  }',start)+4;let reports=source.slice(start,end);if(!reports.includes('allow delete: if false;'))throw Error('Report block not found');
 reports=reports.replace("'unit','unitsPerBox'])","'unit','unitsPerBox','quantityUnit'])");
 const cut=reports.indexOf('   allow update:');let create=reports.slice(0,cut),update=reports.slice(cut);
 create=create.replace("&& request.resource.data.quantity is int", "&& (request.resource.data.get('quantityUnit','') == '' || (request.resource.data.quantityUnit == 'EA' && request.resource.data.get('unit','EA') == 'BOX'))\n    && (request.resource.data.get('unit','EA') != 'BOX' || request.resource.data.get('quantityUnit','') == 'EA')\n    && request.resource.data.quantity is int");
 create=create.replaceAll(".get('damageQuantity',0)",'.get(lnsDamageKey(request.resource.data),0)');
 create=create.replace('getAfter(loanPath(request.resource.data.loanId)).data.damageQuantity <= get(loanPath(request.resource.data.loanId)).data.quantity','lnsDamageTotal(getAfter(loanPath(request.resource.data.loanId)).data) <= get(loanPath(request.resource.data.loanId)).data.quantity*lnsPack(get(loanPath(request.resource.data.loanId)).data)');
 for(const [k,fn]of [['damageQuantity','lnsDamageKey'],['brokenStock','lnsBrokenKey'],['reportRepairing','lnsReportRepairKey']])update=update.replaceAll(".get('"+k+"',0)",'.get('+fn+'(resource.data),0)');
 update=update.replaceAll('.data.repairing','.data.get(lnsRepairKey(resource.data),0)');
 source=source.slice(0,start)+create+update+source.slice(end);
 const es=source.indexOf('match /company/main/equipment/{equipmentId}'),ee=source.indexOf('match /company/main/loans/{loanId}',es);let equipment=source.slice(es,ee);
 equipment=equipment.replace('allow create: if admin() && validQty(request.resource.data)',"allow create: if admin() && request.resource.data.get('brokenEa',0) == 0 && request.resource.data.get('repairingEa',0) == 0 && request.resource.data.get('reportRepairingEa',0) == 0 && validQty(request.resource.data)");
 equipment=equipment.replace('allow delete: if admin() &&',"allow delete: if admin() && resource.data.get('brokenEa',0) == 0 && resource.data.get('repairingEa',0) == 0 &&");
 equipment=equipment.replace('(admin() && request.resource.data.loaned ==','(admin() && lnsEaStockSame(request.resource.data,resource.data) && request.resource.data.loaned ==');
 equipment=equipment.replace("(admin() && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['repairing','updatedAt'])", "(admin() && lnsEaStockSame(request.resource.data,resource.data) && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['repairing','updatedAt'])");
 equipment=equipment.replace("['loaned','lastLoanId','brokenStock']","['loaned','lastLoanId','brokenStock','brokenEa']");
 equipment=equipment.replace('loanCreateMatches(request.resource.data.lastLoanId,equipmentId) &&','loanCreateMatches(request.resource.data.lastLoanId,equipmentId) && lnsEaStockSame(request.resource.data,resource.data) &&');
 equipment=equipment.replace('loanReturnMatches(request.resource.data.lastLoanId,equipmentId) &&','loanReturnMatches(request.resource.data.lastLoanId,equipmentId) && lnsEaReturn(request.resource.data,resource.data,get(loanPath(request.resource.data.lastLoanId)).data) &&');
 equipment=equipment.replace('|| lnsMaintenanceStockChange(equipmentId)','|| lnsEaManualRepair(request.resource.data,resource.data) || lnsMaintenanceStockChange(equipmentId)');
 source=source.slice(0,es)+equipment+source.slice(ee);
 const ls=source.indexOf('match /company/main/loans/{loanId}'),le=source.indexOf('match /company/main/reservations/',ls);let loan=source.slice(ls,le);
 loan=loan.replace("&& getAfter(eqPath(resource.data.equipmentId)).data.lastLoanId == loanId", "&& lnsEaReturn(getAfter(eqPath(resource.data.equipmentId)).data,get(eqPath(resource.data.equipmentId)).data,resource.data)\n     && getAfter(eqPath(resource.data.equipmentId)).data.lastLoanId == loanId");
 loan=loan.replace("resource.data.get('damageQuantity',0) == 0;","resource.data.get('damageQuantity',0) == 0 && resource.data.get('damageEa',0) == 0;");
 source=source.slice(0,ls)+loan+source.slice(le);return source;
}
