import admin from 'firebase-admin';
import {processAdminOperations} from './admin-core.mjs';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');
if(!account||account.project_id!=='light-4e07d')throw Error('Expected configured Lightpia service account.');
admin.initializeApp({credential:admin.credential.cert(account)});
await processAdminOperations({db:admin.firestore(),auth:admin.auth(),FieldValue:admin.firestore.FieldValue,Timestamp:admin.firestore.Timestamp});
