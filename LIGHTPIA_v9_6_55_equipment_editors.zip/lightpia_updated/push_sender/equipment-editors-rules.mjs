import fs from 'node:fs';
export function patchEquipmentEditorRules(source){
 if(source.includes('LNS_EQUIPMENT_EDITORS_V1'))return source;
 const memberStart=source.indexOf('match /members/{uid}'),memberEnd=source.indexOf('\n  match ',memberStart+10);
 if(memberStart<0||memberEnd<0)throw Error('Unexpected member rules');
 let block=source.slice(memberStart,memberEnd);
 const keys="['role','teamName','teamId','displayName','active','updatedAt']";
 if(!block.includes(keys))throw Error('Unexpected member fields');
 block=block.replace(keys,"['role','teamName','teamId','displayName','active','updatedAt','equipmentEditor']");
 const active='&& request.resource.data.active is bool';
 if(!block.includes(active))throw Error('Missing member validation');
 block=block.replace(active,active+" && request.resource.data.get('equipmentEditor',false) is bool");
 source=source.slice(0,memberStart)+block+source.slice(memberEnd);
 for(const name of ['equipmentPhotos','equipmentPhotoDetails']){
  const start=source.indexOf('match /company/main/'+name+'/{id}'),end=source.indexOf('\n  }',start);
  if(start<0||end<0)throw Error('Missing photo rules');
  let photo=source.slice(start,end);
  if(!photo.includes('allow create, update: if admin() && validEquipmentPhoto')||!photo.includes('allow delete: if admin();'))throw Error('Unexpected photo permissions');
  photo=photo.replace('if admin() && validEquipmentPhoto','if lnsEquipmentEditor() && validEquipmentPhoto').replace('allow delete: if admin();','allow delete: if lnsEquipmentEditor();');
  source=source.slice(0,start)+photo+source.slice(end);
 }
 const match=source.match(/match\s+\/databases\/\{database\}\/documents\s*\{/);
 if(!match)throw Error('Unexpected rules structure');
 const at=match.index+match[0].length;
 return source.slice(0,at)+'\n'+fs.readFileSync(new URL('./equipment-editors.rules',import.meta.url),'utf8')+source.slice(at);
}
