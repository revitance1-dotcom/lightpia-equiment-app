const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'../www'),shots=process.env.UI_SCREENSHOT_DIR||'/tmp/lightpia-ui/screenshots';fs.mkdirSync(shots,{recursive:true});
let html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
for(const name of ['brand-banner.svg','studio-atmosphere.svg'])html=html.split(name).join('data:image/svg+xml;base64,'+fs.readFileSync(path.join(root,name)).toString('base64'));
function luminance(rgb){return rgb.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4}).reduce((n,v,i)=>n+v*[.2126,.7152,.0722][i],0)}
function contrast(a,b){const l=[luminance(a),luminance(b)].sort((a,b)=>b-a);return (l[0]+.05)/(l[1]+.05)}
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 for(const [width,height] of [[320,850],[393,1000],[768,1024],[1280,1000]]){
  const page=await browser.newPage({viewport:{width,height},locale:'ko-KR',deviceScaleFactor:2});await page.setContent(html);
  await page.evaluate(()=>{document.querySelector('#app').classList.remove('hidden');document.querySelector('#loginGate')?.classList.add('hidden');document.querySelector('#setupNotice').classList.add('hidden');const status=document.querySelector('#connection');status.textContent='관리자 · 공용 재고 연결됨';status.classList.add('ok');for(const [id,n] of Object.entries({statKinds:8,statTotal:3,statLoan:12,statLate:1}))document.getElementById(id).textContent=n;document.getElementById('dueList').innerHTML='<div class="empty">반납 예정 기록이 없습니다.</div>';document.getElementById('recentList').innerHTML='<div class="empty">최근 대여 기록이 없습니다.</div>';});
  await page.locator('.brand-banner-image').evaluate(img=>img.decode());
  const x=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,client:document.documentElement.clientWidth,svg:document.querySelector('.brand-banner-image').naturalWidth,labels:[...document.querySelectorAll('.stat-action .k,.stat-action .s')].map(e=>({width:e.clientWidth,scroll:e.scrollWidth,color:getComputedStyle(e).color})),tab:document.querySelector('.tabs').getBoundingClientRect().toJSON()}));
  assert(x.scroll<=x.client+1,`horizontal overflow ${width}`);assert(x.svg>=1280);assert(x.labels.every(e=>e.scroll<=e.width+1),`card label overflow ${width}`);
  for(const l of x.labels){const c=l.color.match(/[\d.]+/g).slice(0,3).map(Number);assert(contrast(c,[38,48,52])>=4.5,'card text contrast');}
  await page.screenshot({path:path.join(shots,`studio-dashboard-${width}.png`),fullPage:true});
  await page.evaluate(()=>{document.getElementById('view-home').classList.add('hidden');document.getElementById('view-equipment').classList.remove('hidden');document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.tab==='equipment'));document.querySelector('#equipmentList').innerHTML='<section class="equipment-group"><div class="equipment-group-head"><b>HMI</b><span>2종</span></div><div class="item"><div><div class="itemtitle">ARRI M90</div><div class="meta">전체 8 · 대여 3 · 수리 0 · 가용 5</div></div><button class="small secondary">수정</button></div></section>';});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'equipment overflow');
  if(width===393)await page.screenshot({path:path.join(shots,'studio-equipment.png'),fullPage:true});
  console.log('PASS studio',width,height,'vector loaded, no horizontal/label overflow, readable card text');await page.close();
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
