import {unitSnapshot,sameUnit,inventoryStock,quantityText,remainingReservationItems} from './equipment-units.js';
import {loadCapacitySnapshot,readCapacityLock,writeCapacityLock,checkCapacity} from './availability-model.js';
const ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2';
const ref=(api,db,c,id)=>api.doc(db,'company','main',c,id);
export const reservationLoanId=(id,index)=>'reservation_'+id+'_'+index;
export async function fulfillReservation(api,db,id,options,actor,onProgress=()=>{}){
 if(actor?.uid!==ADMIN||!actor.isAdmin)throw Error('관리자만 출고 처리할 수 있습니다.');
 if(!options.loanDate||!options.dueDate||options.dueDate<options.loanDate||!['상주장비','세트장비','추가장비'].includes(options.equipmentGroup))throw Error('출고일·반납 예정일·장비 구분을 확인해 주세요.');
 let completed=0;
 for(let iteration=0;iteration<60;iteration++){
  const initial=await api.getDoc(ref(api,db,'reservations',id));if(!initial.exists())throw Error('예약이 삭제되었습니다.');const current=initial.data();if(current.status==='fulfilled')return {completed:(current.items||[]).length};if(current.status!=='approved')throw Error('승인 완료 예약만 출고할 수 있습니다.');
  const remaining=remainingReservationItems(current);if(!remaining.length)throw Error('예약 수량을 확인해 주세요.');if(new Set((current.items||[]).map(i=>i.id)).size!==(current.items||[]).length)throw Error('중복 장비가 있는 예약은 출고할 수 없습니다.');
  const selected=remaining.slice(0,1),dates=Object.keys(current.fulfilledItems||{}).length?{loanDate:current.fulfillmentLoanDate,dueDate:current.fulfillmentDueDate,equipmentGroup:current.fulfillmentGroup}:options;
  const snapshot=await loadCapacitySnapshot(api,db,selected.map(i=>i.id),dates.loanDate);
  try{await api.runTransaction(db,async tx=>{
   const rr=ref(api,db,'reservations',id),rs=await tx.get(rr);if(!rs.exists())throw Error('예약이 삭제되었습니다.');const r=rs.data();if(r.status==='fulfilled')return;if(r.status!=='approved')throw Error('예약 상태가 변경되었습니다.');
   const done={...(r.fulfilledItems||{})},ids={...(r.fulfillmentLoanIds||{})},rows=[];let destination;
   if(r.rentalType==='external')destination={team:'관리자',teamId:'admin',rentalType:'external',externalTeam:r.externalTeam||'',externalPerson:r.externalPerson||''};
   else{const ts=await tx.get(api.doc(db,'teams',r.teamId)),ps=await tx.get(api.doc(db,'projects',r.projectId));if(!ts.exists()||!ps.exists()||ts.data().active===false||ps.data().active===false||ts.data().projectId!==r.projectId)throw Error('종료된 작품 또는 팀의 예약은 출고할 수 없습니다.');destination={team:ts.data().name,teamId:r.teamId,projectId:r.projectId,projectName:ps.data().name,rentalType:'internal',externalTeam:'',externalPerson:''};}
   for(const item of selected){if(Number(done[item.index]||0)>=Number(r.items[item.index].qty))continue;const lock=await readCapacityLock(api,db,tx,item.id,snapshot),er=ref(api,db,'equipment',item.id),es=await tx.get(er),lr=ref(api,db,'loans',reservationLoanId(id,item.index)),ls=await tx.get(lr);if(!es.exists())throw Error('삭제된 장비: '+item.name);if(ls.exists())throw Error('이미 연결된 대여 기록을 확인해 주세요.');const e={...es.data(),id:item.id},quantity=Number(r.items[item.index].qty)-Number(done[item.index]||0);if(!sameUnit(item,e))throw Error(item.name+': 관리 단위가 변경되었습니다.');if(e.total!==0&&inventoryStock(e).available<quantity)throw Error(item.name+': 현재 창고 가용 '+quantityText(Math.max(0,inventoryStock(e).available),e)+'로 출고 수량이 부족합니다.');checkCapacity(e,snapshot,quantity,dates.loanDate,dates.dueDate,options.today||dates.loanDate,id);rows.push({lock,er,lr,e,quantity,index:item.index});done[item.index]=Number(r.items[item.index].qty);ids[item.index]=lr.id;}
   if(!rows.length)return;
   const all=r.items.every((i,index)=>Number(done[index]||0)>=i.qty);
   for(const row of rows){writeCapacityLock(api,tx,row.lock,row.lr.id,'loan');tx.update(row.er,{loaned:Number(row.e.loaned||0)+row.quantity,lastLoanId:row.lr.id});tx.set(row.lr,{...destination,...unitSnapshot(row.e),equipmentId:row.e.id,equipmentName:row.e.name,quantity:row.quantity,ownerUid:actor.uid,person:String(r.person||'관리자').slice(0,80),loanDate:dates.loanDate,dueDate:dates.dueDate,equipmentGroup:dates.equipmentGroup,note:r.note||'',reservationId:id,reservationItemIndex:row.index,status:'active',createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});}
   tx.update(rr,{fulfilledItems:done,fulfillmentLoanIds:ids,lastFulfillmentIndex:rows[0].index,fulfillmentLoanDate:dates.loanDate,fulfillmentDueDate:dates.dueDate,fulfillmentGroup:dates.equipmentGroup,fulfilledBy:actor.uid,fulfilledAt:all?api.serverTimestamp():null,status:all?'fulfilled':'approved',updatedAt:api.serverTimestamp()});
  });}catch(e){if(e.capacityRetry)continue;e.message='출고 중단: '+e.message+' 이미 출고된 장비는 유지됩니다. 예약에서 남은 장비만 다시 출고할 수 있습니다.';throw e;}
  completed=Object.keys((await api.getDoc(ref(api,db,'reservations',id))).data().fulfilledItems||{}).length;onProgress(completed,current.items.length);if(completed===current.items.length)return {completed};
 }
 throw Error('수량이 계속 변경되고 있습니다. 잠시 후 남은 장비 출고를 다시 실행해 주세요.');
}
