import admin from 'firebase-admin';import webpush from 'web-push';
import {ADMIN,digest,eventsFor,recipients,shouldPush} from './notification-events.mjs';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');if(account?.project_id!=='light-4e07d')throw Error('Unexpected project');
admin.initializeApp({credential:admin.credential.cert(account)});const db=admin.firestore(),stamp=()=>admin.firestore.FieldValue.serverTimestamp(),now=Date.now();
const [cfg,keyDoc]=await Promise.all([db.doc('notificationState/config').get(),db.doc('notificationSecrets/vapid').get()]);if(!cfg.exists||!keyDoc.exists){console.log('Notification rollout not active; existing app remains available.');process.exit(0);}
const keys=keyDoc.data();webpush.setVapidDetails('https://light-4e07d.web.app',keys.publicKey,keys.privateKey);
const activated=cfg.data().activatedAt.toMillis();
const members=(await db.collection('members').get()).docs.map(d=>({id:d.id,...d.data()}));
const profiles=new Map(members.map(m=>[m.id,m]));
const paths={joinRequests:'joinRequests',reservations:'company/main/reservations',loans:'company/main/loans',announcements:'notificationAnnouncements',tests:'notificationTests'};
for(const [source,path] of Object.entries(paths)){
 const clock=(await import('./notification-events.mjs')).koreaClock(now),config=cfg.data();
 const since=admin.firestore.Timestamp.fromMillis(Math.max(activated,Number(config['scan_'+source]||activated)-300000));
 const batches=[await db.collection(path).where('createdAt','>=',since).get()];
 if(['joinRequests','reservations','loans'].includes(source))batches.push(await db.collection(path).where('updatedAt','>=',since).get());
 const daily=['loans','reservations'].includes(source)&&clock.hour>=9&&config['daily_'+source]!==clock.day;
 if(daily)batches.push(await db.collection(path).where('status','in',source==='loans'?['active']:['approved']).get());
 const documents=new Map();for(const batch of batches)for(const d of batch.docs)documents.set(d.id,d);
 const rows=[...documents.values()],refs=rows.map(d=>db.doc('notificationSourceState/'+digest(source+':'+d.id)));
 const old=refs.length?await db.getAll(...refs):[];
 const previous=Object.fromEntries(old.filter(d=>d.exists).map(d=>[d.data().sourceId,d.data()]));
 const {events,state}=eventsFor(source,rows.map(d=>({id:d.id,...d.data()})),previous,activated,now);
 for(const e of events){const ref=db.doc('notificationEvents/'+e.id);await db.runTransaction(async tx=>{const s=await tx.get(ref);if(!s.exists)tx.create(ref,{...e,createdAt:stamp(),completed:false});});}
 // State advances only after all generated events have been persisted.
 const changes=Object.entries(state).filter(([id,s])=>!previous[id]||previous[id].status!==s.status||previous[id].updated!==s.updated);
 for(let i=0;i<changes.length;i+=400){const batch=db.batch();for(const [id,s] of changes.slice(i,i+400))batch.set(db.doc('notificationSourceState/'+digest(source+':'+id)),{...s,source,sourceId:id});await batch.commit();}
 await cfg.ref.set({['scan_'+source]:now,...(daily?{['daily_'+source]:clock.day}:{})},{merge:true});
}
const pending=await db.collection('notificationEvents').where('completed','==',false).get();
const deviceDocs=(await db.collection('notificationDevices').where('enabled','==',true).get()).docs;
const legacy=(await db.collection('adminPushDevices').where('enabled','==',true).get()).docs;
for(const eventDoc of pending.docs){const e=eventDoc.data();
 // Drop delayed pushes after three days; retain existing inbox entries.
 if(e.createdAt?.toMillis()<now-3*86400000){await eventDoc.ref.update({completed:true,expired:true});continue;}
 let failed=false;
 for(const uid of recipients(e,members)){
  // No delivery to inactive/deleted accounts. Signup approval recipients must exist as active members.
  if(uid!==ADMIN&&profiles.get(uid)?.active!==true&&e.kind!=='test')continue;
  const inbox=db.doc(`notificationInboxes/${uid}/items/${eventDoc.id}`);
  await db.runTransaction(async tx=>{const s=await tx.get(inbox);if(!s.exists)tx.create(inbox,{title:e.title,body:e.body,kind:e.kind,tab:e.tab,read:false,createdAt:stamp()});});
  const pref=await db.doc('notificationPreferences/'+uid).get();const p=pref.exists?pref.data():null;
  let targets=deviceDocs.filter(d=>d.data().ownerUid===uid);
  // Preserve the existing administrator's opt-in until they choose the new master switch.
  if(uid===ADMIN){const tokens=new Set(targets.map(d=>d.data().token).filter(Boolean));targets=[...targets,...legacy.filter(d=>!tokens.has(d.data().token))];}
  for(const d of targets){const legacyDevice=d.ref.parent.id==='adminPushDevices';if(!shouldPush(p,e,uid))continue;
   const delivery=db.doc('notificationDeliveries/'+digest(eventDoc.id+':'+d.ref.path));const token=d.data().token;
   const claimed=await db.runTransaction(async tx=>{const s=await tx.get(delivery);if(s.data()?.sent||s.data()?.lockUntil?.toMillis()>now)return false;tx.set(delivery,{lockUntil:admin.firestore.Timestamp.fromMillis(now+600000),updatedAt:stamp()},{merge:true});return true;});
   if(!claimed){const s=await delivery.get();if(!s.data()?.sent)failed=true;continue;}
   try{
    // Reload preferences and device immediately before delivery to respect a recent opt-out.
    const [live,livePref]=await Promise.all([d.ref.get(),db.doc('notificationPreferences/'+uid).get()]);
    if(live.data()?.enabled!==true||(livePref.exists&&!shouldPush(livePref.data(),e,uid))){await delivery.set({sent:true,skipped:true,lockUntil:admin.firestore.Timestamp.fromMillis(0)},{merge:true});continue;}
    if(d.data().platform==='web'){
     const sub=d.data().subscription;const u=new URL(sub.endpoint);if(u.protocol!=='https:'||!(u.hostname==='fcm.googleapis.com'||u.hostname.endsWith('.push.apple.com')||u.hostname==='web.push.apple.com'||u.hostname==='updates.push.services.mozilla.com'))throw Error('Unsupported push endpoint');
     await webpush.sendNotification(sub,JSON.stringify({id:eventDoc.id,title:e.title,body:e.body.slice(0,220),tab:e.tab}),{TTL:86400,timeout:15000});
    }else await admin.messaging().send({token,notification:{title:e.title,body:e.body.slice(0,220)},data:{type:e.kind,tab:e.tab,eventId:eventDoc.id},android:{priority:'high',notification:{channelId:'reservation_alerts',clickAction:'FCM_PLUGIN_ACTIVITY'}}});
    await delivery.set({sent:true,sentAt:stamp(),lockUntil:admin.firestore.Timestamp.fromMillis(0)},{merge:true});
   }catch(err){const invalid=[404,410].includes(err.statusCode)||['messaging/registration-token-not-registered','messaging/invalid-registration-token'].includes(err.code);if(invalid)await d.ref.update({enabled:false});else failed=true;await delivery.set({sent:invalid,error:String(err.code||err.message).slice(0,250),lockUntil:admin.firestore.Timestamp.fromMillis(0)},{merge:true});console.error('Notification delivery failed:',err.code||err.statusCode||'transport');}
  }
 }
 if(!failed)await eventDoc.ref.update({completed:true,completedAt:stamp()});
}
console.log('Notification pass complete:',pending.size,'events');
