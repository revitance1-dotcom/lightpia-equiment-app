const fs=require('fs'),assert=require('assert'),vm=require('vm');
const {initializeTestEnvironment}=require('@firebase/rules-unit-testing');
const api=require('firebase/firestore');
(async()=>{
 if(!process.env.FIRESTORE_EMULATOR_HOST)throw Error('Emulator required');
 const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8')}});
 const ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2';
 const source=fs.readFileSync('www/app.js','utf8');
 const submit=source.slice(source.indexOf('async function submitCart(){'),source.indexOf('function showEquipmentDetail('));
 try{
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async c=>{const db=c.firestore();await api.setDoc(api.doc(db,'members','staff'),{active:true,role:'team',teamId:'A',teamName:'A',displayName:'직원'});await api.setDoc(api.doc(db,'teams','A'),{active:true,name:'A',projectId:'P'});await api.setDoc(api.doc(db,'projects','P'),{active:true,name:'작품'});});
  for(const uid of [ADMIN,'staff'])for(const count of [1,3,5,20]){
   const db=env.authenticatedContext(uid).firestore(),ids=Array.from({length:count},(_,i)=>`${uid}-${count}-${i}`),messages=[];
   await env.withSecurityRulesDisabled(async c=>{const db=c.firestore();for(const id of ids)await api.setDoc(api.doc(db,'company/main/equipment',id),{name:id,total:10,loaned:0,repairing:1});});
   const elements={cartDate:{value:'2026-10-27'},cartDue:{value:'2026-10-28'},cartNote:{value:'회귀 테스트'},cartSubmit:{}};
   const context={...api,db,cartItems:Object.fromEntries(ids.map(id=>[id,2])),teamId:uid===ADMIN?'admin':'A',teamName:uid===ADMIN?'관리자':'A',teamList:[{id:'A',projectId:'P',active:true}],currentUser:{uid},member:{displayName:'직원'},isAdmin:()=>uid===ADMIN,$:id=>elements[id],loanCol:()=>api.collection(db,'company/main/loans'),eqDoc:id=>api.doc(db,'company/main/equipment',id),closeModal:()=>{},alert:m=>messages.push(m)};
   vm.createContext(context);vm.runInContext(submit,context);await context.submitCart();
   console.log('BULK REPRO',uid===ADMIN?'admin':'staff',count,JSON.stringify(messages));
   assert(!messages.some(m=>m.includes('실패')),`Bulk ${count} failed: ${messages}`);
   for(const id of ids)assert.equal((await api.getDoc(api.doc(db,'company/main/equipment',id))).data().loaned,2);
  }
  console.log('PASS actual submitCart: admin/staff 1,3,5,20 equipment');
 }finally{await env.cleanup();}
})().catch(e=>{console.error(e);process.exit(1)});
