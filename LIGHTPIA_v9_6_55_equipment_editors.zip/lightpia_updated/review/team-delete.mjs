import assert from 'node:assert/strict';
import {deleteClosedTeam,validateOperation,ADMIN_UID} from '../push_sender/admin-core.mjs';
for(const scenario of ['success','active','loan','reservation','missing']){
 const rows=new Map(Object.entries({
  'projects/dash':{active:true},'teams/A':{active:true,projectId:'dash'},
  'teams/B':{active:scenario==='active',projectId:'dash'},
  'members/staff':{active:true,role:'team',teamId:'B',projectId:'dash',teamName:'B팀'},
  'company/main/loans/B':{teamId:'B',status:scenario==='loan'?'active':'returned',quantity:3},
  'company/main/reservations/B':{teamId:'B',status:scenario==='reservation'?'approved':'revoked',endDate:'2099-01-01'}
 }));if(scenario==='missing')rows.delete('teams/B');
 const ref=path=>({path}),snap=path=>({id:path.split('/').at(-1),ref:ref(path),exists:rows.has(path),data:()=>rows.get(path)});
 const db={collection:path=>({doc:id=>ref(path+'/'+id),where:(key,op,value)=>({path,key,value})}),runTransaction:async fn=>fn({get:async target=>target.key?{docs:[...rows.keys()].filter(k=>k.slice(0,k.lastIndexOf('/'))===target.path&&rows.get(k)[target.key]===target.value).map(snap),get size(){return this.docs.length}}:snap(target.path),update:(r,data)=>{const d=rows.get(r.path);for(const [k,v] of Object.entries(data)){if(v===remove)delete d[k];else d[k]=v}},delete:r=>rows.delete(r.path)})},remove=Symbol(),FieldValue={delete:()=>remove,serverTimestamp:()=>1};
 const task=()=>deleteClosedTeam({db,FieldValue},{targetId:'B'});
 if(['active','loan','reservation'].includes(scenario)){await assert.rejects(task);assert(rows.has('teams/B'));assert.equal(rows.get('members/staff').teamId,'B');}
 else{await task();assert(!rows.has('teams/B'));if(scenario==='success'){assert.equal(rows.get('members/staff').teamName,'대기 직원');assert(!rows.get('members/staff').teamId);await task();}}
 assert.equal(rows.get('projects/dash').active,true);assert.equal(rows.get('teams/A').active,true);assert.equal(rows.get('members/staff').active,true);assert.equal(rows.get('company/main/loans/B').quantity,3);assert(rows.has('company/main/reservations/B'));
}
validateOperation('delete_team_B',{createdBy:ADMIN_UID,type:'delete_team',targetId:'B'});
assert.throws(()=>validateOperation('delete_team_B',{createdBy:'employee',type:'delete_team',targetId:'B'}));
console.log('PASS team deletion transaction guards, history/account/sibling preservation, standby assignment, retry and admin identity');
