export function unitSnapshot(e={}){return {unit:e.unit==='BOX'?'BOX':'EA',unitsPerBox:e.unit==='BOX'?Number(e.unitsPerBox??1):1};}
export function validateUnit(e={}){if(e.unit!==undefined&&!['EA','BOX'].includes(e.unit))throw Error('관리 단위는 EA 또는 BOX를 선택해 주세요.');const s=unitSnapshot(e);if((e.unitsPerBox!==undefined&&!Number.isSafeInteger(e.unitsPerBox))||!Number.isSafeInteger(s.unitsPerBox)||s.unitsPerBox<1||s.unitsPerBox>9999||(s.unit==='EA'&&e.unitsPerBox!==undefined&&e.unitsPerBox!==1))throw Error('1BOX 구성 수량은 1~9,999EA의 정수로 입력해 주세요.');return s;}
export function sameUnit(a,b){const x=unitSnapshot(a),y=unitSnapshot(b);return x.unit===y.unit&&x.unitsPerBox===y.unitsPerBox;}
export function quantityText(n,e={}){return Number(n||0)+unitSnapshot(e).unit;}
export function unitHint(e={}){const s=unitSnapshot(e);return s.unit==='BOX'?`1BOX = ${s.unitsPerBox}EA`:'EA 단위';}
export function sumUnitQuantities(rows,key='quantity'){let box=0,ea=0;for(const r of rows){if(unitSnapshot(r).unit==='BOX')box+=Number(r[key]||0);else ea+=Number(r[key]||0);}return [box?box+'BOX':'',ea?ea+'EA':''].filter(Boolean).join(' · ')||'0EA';}
export function unitFields(prefix,e={}){const s=unitSnapshot(e);return `<div class="field"><label for="${prefix}unit">관리 단위</label><select id="${prefix}unit"><option value="EA" ${s.unit==='EA'?'selected':''}>EA · 낱개 관리</option><option value="BOX" ${s.unit==='BOX'?'selected':''}>BOX · 통박스 관리</option></select></div><div class="field ${s.unit==='BOX'?'':'hidden'}" id="${prefix}packField"><label for="${prefix}unitsPerBox">1BOX 구성 수량 (EA)</label><input id="${prefix}unitsPerBox" type="number" min="1" max="9999" step="1" value="${s.unitsPerBox}"><small class="meta">재고와 대여 수량은 BOX 기준입니다.</small></div>`;}
export function bindUnitFields(prefix,totalId,clearOnChange=false){const select=document.getElementById(prefix+'unit'),pack=document.getElementById(prefix+'unitsPerBox'),field=document.getElementById(prefix+'packField'),total=document.getElementById(totalId);if(!select)return;const refresh=()=>{const box=select.value==='BOX';field?.classList.toggle('hidden',!box);if(pack)pack.disabled=!box;if(total){const label=total.closest('.field')?.querySelector('label');if(label)label.textContent='전체 수량 ('+select.value+') *';total.placeholder=box?'보유한 박스 수':'보유한 낱개 수';}};select.onchange=()=>{if(clearOnChange&&total)total.value='';refresh();};refresh();}
export function readUnitFields(prefix){const unit=document.getElementById(prefix+'unit')?.value||'EA';return validateUnit({unit,unitsPerBox:unit==='BOX'?Number(document.getElementById(prefix+'unitsPerBox')?.value):1});}
export async function saveUnitEquipment(api,db,id,data){validateUnit(data);await api.runTransaction(db,async tx=>{const ref=api.doc(db,'company/main/equipment',id),snap=await tx.get(ref);if(!snap.exists())throw Error('장비를 찾을 수 없습니다.');const old=snap.data(),used=Number(old.loaned||0)+Number(old.repairing||0)+Number(old.brokenStock||0)+Math.ceil((Number(old.brokenEa||0)+Number(old.repairingEa||0))/packSize(old));if(!sameUnit(old,data)&&used)throw Error('대여·수리·고장 수량을 먼저 정리한 뒤 단위를 변경해 주세요.');if(data.total!==0&&data.total<used)throw Error('현재 사용 중인 수량보다 전체 수량이 작습니다.');tx.update(ref,data);});}

// Rental counters remain BOX/EA; partial BOX damage is tracked separately in EA.
export function packSize(e={}){return unitSnapshot(e).unitsPerBox;}
export function loanEa(l={}){return Number(l.quantity||0)*packSize(l);}
export function damageEa(l={}){return Number(l.damageQuantity||0)*packSize(l)+Number(l.damageEa||0);}
export function reportEa(r={}){return Number(r.quantity||0)*(r.quantityUnit==='EA'?1:packSize(r));}
export function loanQuantityText(n,e={}){return quantityText(n,e)+(unitSnapshot(e).unit==='BOX'?' · '+Number(n||0)*packSize(e)+'EA':'');}
export function inventoryStock(e={}){const p=packSize(e),total=Number(e.total||0),loaned=Number(e.loaned||0),repairing=Number(e.repairing||0),brokenStock=Number(e.brokenStock||0),repairingEa=Number(e.repairingEa||0),brokenEa=Number(e.brokenEa||0),reportRepairingEa=Number(e.reportRepairingEa||0),availableEa=(total-loaned-repairing-brokenStock)*p-repairingEa-brokenEa;return {total,loaned,repairing,brokenStock,reportRepairing:Number(e.reportRepairing||0),repairingEa,brokenEa,reportRepairingEa,availableEa,available:Math.floor(availableEa/p),looseEa:Math.max(0,availableEa)%p,repairTotalEa:repairing*p+repairingEa,brokenTotalEa:brokenStock*p+brokenEa};}
export function stockRemainderText(e={}){const s=inventoryStock(e);return e.unit==='BOX'&&s.looseEa?' · 정상 낱개 '+s.looseEa+'EA (BOX 미구성)':'';}
// Inclusive day ranges; only the peak simultaneous use blocks a period.
export function capacityOverlap(a,b,c,d){return a<=d&&c<=b;}
export function capacityNextDay(day){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+1);return d.toISOString().slice(0,10);}
export function periodCapacity(e,loans=[],reservations=[],start,end,now='',excludeReservation=''){
 const stock=inventoryStock(e),holds=[];let incompatible=false;if(!/^\d{4}-\d{2}-\d{2}$/.test(start||'')||!/^\d{4}-\d{2}-\d{2}$/.test(end||'')||end<start)return {free:0,peak:0,peakDate:start,holds,incompatible:false};
 const add=(from,to,quantity,source,kind)=>{if(!quantity||!from||!to||!capacityOverlap(from,to,start,end))return;if(!sameUnit(source,e))incompatible=true;holds.push({start:from<start?start:from,end:to>end?end:to,quantity:Number(quantity||0),source,kind});};
 for(const l of loans)if(l.equipmentId===e.id&&l.status!=='returned'){const from=l.loanDate||'0000-01-01',to=!l.dueDate||(now&&l.dueDate<now)?'9999-12-30':l.dueDate;add(from,to,l.quantity,l,'loan');}
 for(const r of reservations)if(r.id!==excludeReservation&&['pending','approved'].includes(r.status))for(const [index,i] of (r.items||[]).entries())if(i.id===e.id)add(r.startDate,r.endDate,reservationRemaining(r,i,index),i,'reservation');
 const points=new Map();for(const h of holds){points.set(h.start,(points.get(h.start)||0)+h.quantity);const day=capacityNextDay(h.end);points.set(day,(points.get(day)||0)-h.quantity);}
 let current=0,peak=0,peakDate=start;for(const [day,n]of [...points].sort(([a],[b])=>a.localeCompare(b))){current+=n;if(current>peak){peak=current;peakDate=day;}}
 const knownLoans=loans.filter(l=>l.equipmentId===e.id&&l.status!=='returned').reduce((n,l)=>n+Number(l.quantity||0),0),unknownLoaned=Math.max(0,stock.loaned-knownLoans),base=Number(e.total||0)-Math.ceil((stock.repairTotalEa+stock.brokenTotalEa)/packSize(e))-unknownLoaned;
 return {free:incompatible?0:Number(e.total||0)===0?9999:Math.max(0,base-peak),peak,peakDate,holds,incompatible};
}
export function capacityFailure(e,result,quantity,start,end){return `${e.name}: ${start} ~ ${end} 요청 ${quantityText(quantity,e)} / 기간 내 가용 ${quantityText(result.free,e)}${result.incompatible?' (관리 단위가 다른 예약·대여 있음)':''}${result.holds.length?' · 겹치는 예약·대여 '+result.holds.map(h=>h.start+'~'+h.end+' '+quantityText(h.quantity,e)).join(', '):''}`;}
export function upcomingReservationText(e,reservations=[],now=''){
 const rows=reservations.filter(r=>['pending','approved'].includes(r.status)&&r.endDate>=now).flatMap(r=>remainingReservationItems(r).filter(i=>i.id===e.id).map(i=>({r,i}))).sort((a,b)=>a.r.startDate.localeCompare(b.r.startDate));
 if(!rows.length)return '';return '예약 '+rows.length+'건 · '+rows.slice(0,2).map(({r,i})=>r.startDate+'~'+r.endDate+' '+quantityText(i.qty,i)).join(' / ')+(rows.length>2?' 외 '+(rows.length-2)+'건':'');
}
export function reservationRemaining(r,i,index){return Math.max(0,Number(i.qty||0)-Number(r.fulfilledItems?.[String(index)]||0));}
export function remainingReservationItems(r){return (r.items||[]).map((i,index)=>({...i,index,qty:reservationRemaining(r,i,index)})).filter(i=>i.qty>0);}
export function overdueUnshippedReservations(rows,day){return rows.filter(r=>['pending','approved'].includes(r.status)&&r.startDate<day&&remainingReservationItems(r).length>0).sort((a,b)=>a.startDate.localeCompare(b.startDate));}
