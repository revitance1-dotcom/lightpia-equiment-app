// Recover an Auth account whose first Firestore application write failed.
export async function submitSignup(api,auth,db,fields){
 const {email,username,password,name,requestedTeam}=fields;
 let result;
 try { result=await api.createUserWithEmailAndPassword(auth,email,password); }
 catch(error){
  if(error.code!=="auth/email-already-in-use")throw error;
  // The original password must authenticate before any existing account is used.
  result=await api.signInWithEmailAndPassword(auth,email,password);
 }
 const ref=api.doc(db,"joinRequests",result.user.uid);
 return api.runTransaction(db,async tx=>{
  const previous=await tx.get(ref);
  if(previous.exists())return previous.data().status;
  tx.set(ref,{email,username,name,requestedTeam,status:"pending",createdAt:api.serverTimestamp()});
  return "pending";
 });
}
