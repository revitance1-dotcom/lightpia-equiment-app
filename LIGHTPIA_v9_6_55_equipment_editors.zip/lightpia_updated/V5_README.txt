Lightpia & Softsun Cinematic V5
- New safe-area launcher icon and branded hero banner
- Keeps existing Firebase/app code unchanged
- Upload ZIP to GitHub repository root; replace .github/workflows/build-apk.yml with included build-apk.yml
- Run GitHub Actions to produce APK; APK not built locally.
