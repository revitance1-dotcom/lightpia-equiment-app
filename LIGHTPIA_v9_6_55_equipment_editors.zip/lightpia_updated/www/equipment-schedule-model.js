import {remainingReservationItems,unitSnapshot} from './equipment-units.js';
import {loanTeamLabel} from './loan-groups.js';
import {compareEquipment} from './display-order.js';
const scheduleDayMs=86400000;
export function validScheduleDay(value){
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;
 const time=Date.parse(value+'T00:00:00Z');return Number.isFinite(time)&&new Date(time).toISOString().slice(0,10)===value;
}
export function shiftScheduleDay(day,n){return new Date(Date.parse(day+'T00:00:00Z')+n*scheduleDayMs).toISOString().slice(0,10);}
export function shiftScheduleMonth(month,n){const [y,m]=month.split('-').map(Number);return new Date(Date.UTC(y,m-1+n,1)).toISOString().slice(0,7);}
export function scheduleTimestampDay(value){
 try{
  const date=value?.toDate?value.toDate():value instanceof Date?value:typeof value?.seconds==='number'?new Date(value.seconds*1000):null;
  if(!date||!Number.isFinite(date.getTime()))return '';
  const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(date),get=type=>parts.find(p=>p.type===type).value;
  return get('year')+'-'+get('month')+'-'+get('day');
 }catch{return '';}
}
export function scheduleMonthGrid(month){
 const first=month+'-01';if(!validScheduleDay(first))throw Error('달력 날짜를 확인해 주세요.');
 const next=shiftScheduleMonth(month,1),last=shiftScheduleDay(next+'-01',-1),offset=new Date(first+'T00:00:00Z').getUTCDay(),start=shiftScheduleDay(first,-offset),weeks=Math.ceil((offset+Number(last.slice(-2)))/7);
 return {first,last,start,weeks:Array.from({length:weeks},(_,week)=>Array.from({length:7},(_,day)=>shiftScheduleDay(start,week*7+day)))};
}
const scheduleText=v=>String(v??'').trim();
const scheduleNormalize=v=>scheduleText(v).normalize('NFKC').toLocaleLowerCase().replace(/\s+/g,' ');
export function buildEquipmentSchedule({loans=[],reservations=[],teams=[],projects=[],equipment=[],today,through=today}){
 const grouped=new Map(),equipmentById=new Map(equipment.map(e=>[e.id,e]));
 function put(kind,start,end,party,items,extra){
  if(!validScheduleDay(start)||!validScheduleDay(end)||end<start||!items.length)return;
  const key=JSON.stringify([kind,start,end,party.identity,party.person,extra.group||'',extra.state||'',extra.plannedEnd||'',extra.actualReturn||'',extra.loanStart||'']);
  if(!grouped.has(key))grouped.set(key,{id:key,kind,start,end,team:party.team,person:party.person,items:[],...extra});
  grouped.get(key).items.push(...items);
 }
 for(const l of loans){
  const start=l.loanDate;if(!validScheduleDay(start)||!['active','returned'].includes(l.status))continue;
  const done=l.status==='returned',actual=done?scheduleTimestampDay(l.returnedAt):'',planned=validScheduleDay(l.dueDate)?l.dueDate:'',late=!done&&!!planned&&planned<today;
  const team=l.rentalType==='external'?(scheduleText(l.externalTeam)||'외부팀'):loanTeamLabel(l,teams,projects),person=l.rentalType==='external'?(scheduleText(l.externalPerson)||scheduleText(l.person)):scheduleText(l.person);
  const party={team,person,identity:l.rentalType==='external'?['external',scheduleNormalize(team),scheduleNormalize(person)]:[l.teamId||'',l.projectId||'',team]};
  const item={...unitSnapshot(l),id:l.equipmentId,name:l.equipmentName||equipmentById.get(l.equipmentId)?.name||'삭제된 장비',qty:Number(l.quantity||0),loanId:l.id,note:scheduleText(l.note)};
  if(!(item.qty>0))continue;
  // Missing actual-return dates never become fabricated completed-return events.
  let end=done?(actual||planned||start):(planned||(validScheduleDay(through)?through:today)||start);if(late&&validScheduleDay(through)&&through>end)end=through;if(late&&today>end)end=today;if(end<start)end=start;
  const extra={group:l.rentalType==='external'?'외부팀':l.equipmentGroup||'미분류',state:done?'returned':late?'late':'active',plannedEnd:planned,actualReturn:actual,missingReturnDate:done&&!actual,openEnd:!done&&!planned};
  put('loan',start,end,party,[item],extra);
  if(done&&actual)put('returned',actual,actual,party,[item],{...extra,loanStart:start});
  if(!done&&planned)put('returnDue',planned,planned,party,[item],{...extra,loanStart:start});
 }
 for(const r of reservations){
  if(!['pending','approved'].includes(r.status))continue;
  const items=remainingReservationItems(r).map(i=>({...unitSnapshot(i),id:i.id,name:i.name||equipmentById.get(i.id)?.name||'삭제된 장비',qty:i.qty,reservationId:r.id,note:scheduleText(r.note)}));
  const team=r.rentalType==='external'?(scheduleText(r.externalTeam)||'외부팀'):loanTeamLabel({team:r.teamName||r.team,teamId:r.teamId,projectName:r.projectName,projectId:r.projectId},teams,projects),person=r.rentalType==='external'?(scheduleText(r.externalPerson)||scheduleText(r.person)):scheduleText(r.person);
  put('reservation',r.startDate,r.endDate,{team,person,identity:['reservation',r.id]},items,{state:r.status,group:r.rentalType==='external'?'외부팀':'예약',reservationId:r.id});
 }
 const order={loan:0,returnDue:1,returned:2,reservation:3};
 return [...grouped.values()].map(e=>({...e,items:e.items.sort(compareEquipment)})).sort((a,b)=>a.start.localeCompare(b.start)||order[a.kind]-order[b.kind]||a.team.localeCompare(b.team,'ko')||a.person.localeCompare(b.person,'ko')||a.id.localeCompare(b.id));
}
export function filterEquipmentSchedule(events,query='',filter='all',equipment=[]){
 const words=scheduleNormalize(query).split(' ').filter(Boolean),byId=new Map(equipment.map(e=>[e.id,e]));
 return events.filter(e=>(filter==='all'||(filter==='return'?['returnDue','returned'].includes(e.kind):e.kind===filter))&&words.every(w=>scheduleNormalize([e.team,e.person,e.group,...e.items.flatMap(i=>{const eq=byId.get(i.id)||{};return [i.name,i.note,eq.model,eq.category,eq.searchTags];})].join(' ')).includes(w)));
}
export function scheduleEventsOnDay(events,day){return events.filter(e=>e.start<=day&&day<=e.end);}
export function layoutScheduleWeek(events,days,maxLanes=3){
 const first=days[0],last=days[6],segments=events.filter(e=>e.start<=last&&e.end>=first).map(e=>({event:e,start:e.start<first?first:e.start,end:e.end>last?last:e.end})).sort((a,b)=>a.start.localeCompare(b.start)||b.end.localeCompare(a.end)||a.event.id.localeCompare(b.event.id));
 const laneEnds=[],bars=[],hidden=Object.fromEntries(days.map(d=>[d,0]));
 for(const seg of segments){let lane=laneEnds.findIndex(end=>end<seg.start);if(lane<0)lane=laneEnds.length;
  if(lane>=maxLanes){for(const day of days)if(seg.start<=day&&day<=seg.end)hidden[day]++;continue;}
  laneEnds[lane]=seg.end;const column=days.indexOf(seg.start)+1,span=days.indexOf(seg.end)-column+2;
  bars.push({...seg,lane,column,span,continuesBefore:seg.event.start<first,continuesAfter:seg.event.end>last});
 }
 return {bars,hidden};
}
