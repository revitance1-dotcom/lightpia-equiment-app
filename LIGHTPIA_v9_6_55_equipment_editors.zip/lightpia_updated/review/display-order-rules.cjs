const fs=require('fs'),assert=require('assert'),{initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing'),api=require('firebase/firestore');
(async()=>{const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8')}});try{
 await env.clearFirestore();await env.withSecurityRulesDisabled(c=>api.setDoc(api.doc(c.firestore(),'members/staff-order'),{role:'team',active:true,teamName:'A팀'}));
 const admin=env.authenticatedContext('7iSB1gW9PAhYPgi253IUk4Dooyp2').firestore(),staff=env.authenticatedContext('staff-order').firestore(),anon=env.unauthenticatedContext().firestore(),ref=db=>api.doc(db,'company/main/appSettings/displayOrder');
 const payload={groups:{categories:['전체','LED','HMI'],loanActions:['loan','return','delete']},updatedAt:api.serverTimestamp()};
 await assertSucceeds(api.setDoc(ref(admin),payload));await assertSucceeds(api.getDoc(ref(staff)));
 await assertFails(api.getDoc(ref(anon)));await assertFails(api.setDoc(ref(staff),payload));
 await assertSucceeds(api.setDoc(ref(admin),{groups:{categories:['HMI','전체','LED']},updatedAt:api.serverTimestamp()},{merge:true}));
 assert.deepEqual((await api.getDoc(ref(admin))).data().groups.loanActions,['loan','return','delete']);
 await assertFails(api.setDoc(ref(admin),{...payload,groups:{categories:Array(201).fill('LED')}}));
 await assertFails(api.setDoc(ref(admin),{...payload,groups:{categories:'wrong'}}));
 await assertFails(api.setDoc(ref(admin),{...payload,groups:{unknown:['x']}}));
 await assertFails(api.setDoc(ref(admin),{...payload,total:100}));await assertFails(api.deleteDoc(ref(admin)));
 const {patchDisplayOrderRules}=await import('../push_sender/display-order-rules.mjs');const base=fs.readFileSync('firestore.rules','utf8');assert.equal(patchDisplayOrderRules(base),base);
 console.log('PASS shared display order: administrator create/update, staff read only, anonymous denied, independent groups preserved, bounded payload and idempotent rules patch');
 }finally{await env.cleanup()}})().catch(e=>{console.error(e);process.exit(1)});
