import fs from 'node:fs';
function replaceBlock(source,anchor,replacement){
 const start=source.indexOf(anchor);if(start<0||source.indexOf(anchor,start+anchor.length)>=0)throw Error('Unexpected rules block: '+anchor);
 const open=source.indexOf('{',start+anchor.length);let depth=1,quote='',escape=false;
 for(let i=open+1;i<source.length;i++){
  const c=source[i];if(quote){if(escape)escape=false;else if(c==='\\')escape=true;else if(c===quote)quote='';continue;}
  if(c==='\''||c==='"'){quote=c;continue;}if(c==='{')depth++;if(c==='}'&&--depth===0)return source.slice(0,start)+replacement+source.slice(i+1);
 }
 throw Error('Unbalanced rules: '+anchor);
}
export function patchMaintenanceRules(source){
 if(source.includes('LNS_MAINTENANCE_V1'))return source;
 const root=new URL('./',import.meta.url),load=n=>fs.readFileSync(new URL(n,root),'utf8');
 source=replaceBlock(source,'function validQty(d)',load('maintenance-quantity.rules').trim());
 source=replaceBlock(source,'match /company/main/equipment/{equipmentId}',load('maintenance-equipment.rules').trim());
 const start=source.indexOf('match /company/main/loans/{loanId}');if(start<0)throw Error('Missing loan rules');
 const end=source.indexOf('match /company/main/reservations/',start);if(end<0)throw Error('Missing reservation rules');
 let loan=source.slice(start,end);
 const u=loan.indexOf('   allow update:');const d=loan.indexOf('   allow delete:',u);if(u<0||d<0)throw Error('Unexpected loan update rules');
 loan=loan.slice(0,u)+load('maintenance-loan-update.rules')+loan.slice(d).replace("resource.data.status == 'returned';","resource.data.status == 'returned' && resource.data.get('damageQuantity',0) == 0;");
 source=source.slice(0,start)+loan+source.slice(end);
 const marker='match /databases/{database}/documents {';const at=source.indexOf(marker);if(at<0)throw Error('Unexpected database rules');
 return source.slice(0,at+marker.length)+'\n'+load('maintenance-helpers.rules')+'\n'+load('maintenance-reports.rules')+source.slice(at+marker.length);
}
