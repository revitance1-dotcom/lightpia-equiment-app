# 9.6.47 — BOX loans, EA damage

Rental history shows the immutable BOX count and contained EA count (1BOX · 4EA). New BOX damage reports take EA and cap against the actual rented lights, with legacy full-BOX report meaning preserved. Return quarantines damaged EA; available full BOX stock rounds down and remaining healthy loose EA is shown. Repair intake, completion, cancellation and manual quantities use EA. Transactions and rules protect EA counters, history deletion and unit changes, including preventing old clients returning damaged boxes as healthy. JSON v4 preserves EA counters and snapshots. APK and web deploy from the same source.

Validation: 4/8/3 packs, partial and all-light damage, races, legacy reports, staff cancellation permissions, forged counters, exact return, repair restoration, capacity blocking, and 320/393/768 UI.
