import fs from 'node:fs';
export function patchAvailabilityRules(source){
 if(source.includes('LNS_AVAILABILITY_LOCKS_V1'))return source;
 const marker='match /company/main/reservations/{reservationId}';if(!source.includes(marker))throw Error('Reservation rules missing');
 source=source.replace(marker,fs.readFileSync(new URL('./availability.rules',import.meta.url),'utf8')+'\n  '+marker);
 const a=source.indexOf(marker),b=source.indexOf('match /company/main/repairs/',a);let r=source.slice(a,b);r=r.replace("&& request.resource.data.status == 'pending'", "&& request.resource.data.status == 'pending' && request.resource.data.items.size() > 0 && lnsCapacityLockMatches(request.resource.data.items[0].id,reservationId,'reservation')");source=source.slice(0,a)+r+source.slice(b);
 const la=source.indexOf('match /company/main/loans/{loanId}'),lb=source.indexOf('// LNS_EXTERNAL_RESERVATIONS_V1',la);let l=source.slice(la,lb);l=l.replace("&& request.resource.data.status == 'active'", "&& request.resource.data.status == 'active' && (!exists(lnsCapacityPath(request.resource.data.equipmentId)) || lnsCapacityLockMatches(request.resource.data.equipmentId,loanId,'loan'))");return source.slice(0,la)+l+source.slice(lb);
}
