export function patchReservationItemLimitRules(source) {
 const marker = 'match /company/main/reservations/{reservationId}';
 const start = source.indexOf(marker);
 const end = source.indexOf('allow update:', start);
 if (start < 0 || end < 0 || !source.includes('function lnsFulfillmentKey(index)')) {
  throw Error('Reservation create or fulfillment rules missing');
 }
 const create = source.slice(start, end).replace(
  /^[ \t]*&& request\.resource\.data\.items\.size\(\) <= 20[ \t]*\r?\n/m, '',
 );
 return (source.slice(0, start) + create + source.slice(end)).replace(
  /function lnsFulfillmentKey\(index\) \{ return \[[^\]\n]+\]\[index\]; \}/,
  'function lnsFulfillmentKey(index) { return string(index); }',
 );
}
