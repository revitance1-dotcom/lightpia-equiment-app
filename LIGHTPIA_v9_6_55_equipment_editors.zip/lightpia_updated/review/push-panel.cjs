const fs=require('fs'),vm=require('vm'),assert=require('assert'),{webcrypto}=require('crypto');
const source=fs.readFileSync('www/app.js','utf8').split('// Remember successful device registration; revalidate silently after login.')[1].split('\nfunction operationPending(')[0];
function env({saved=false,permission='granted',fail=false}={}){
 const data=new Map(saved?[['lpAdminPushRegistered:test:admin','1']]:[]),events={},visible={},els={pushRegisterStatus:{},enableAdminPush:{addEventListener(){}}};
 let prompts=0,registers=0,writes=0,admin=true;
 const plugin={checkPermissions:async()=>({receive:permission}),requestPermissions:async()=>{prompts++;return {receive:permission}},addListener:async(n,f)=>{events[n]=f;return {remove:async()=>{delete events[n]}}},register:async()=>{registers++;await events.registration({value:'token'})}};
 const ctx={BUILTIN_FIREBASE_CONFIG:{projectId:'test'},ADMIN_UID:'admin',currentUser:{uid:'admin'},isAdmin:()=>admin,localStorage:{getItem:k=>data.get(k),setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)},show:(id,on)=>visible[id]=on,$:id=>els[id],window:{Capacitor:{Plugins:{PushNotifications:plugin}}},crypto:webcrypto,TextEncoder,Uint8Array,db:{},doc:()=>0,serverTimestamp:()=>0,setDoc:async()=>{writes++;if(fail)throw Error('save failed')},document:{querySelector:()=>null}};
 vm.createContext(ctx);vm.runInContext(source,ctx);
 return {ctx,visible,data,events,counts:()=>({prompts,registers,writes}),nonAdmin:()=>admin=false};
}
(async()=>{
 let e=env();e.ctx.updateAdminPushPanel();assert.equal(e.visible.adminPushPanel,true);await e.ctx.enableAdminPush();assert.equal(e.visible.adminPushPanel,false);e.ctx.updateAdminPushPanel();assert.equal(e.visible.adminPushPanel,false);
 e=env({saved:true});e.ctx.updateAdminPushPanel();assert.equal(e.visible.adminPushPanel,false);await e.ctx.restoreAdminPush();assert.equal(e.visible.adminPushPanel,false);assert.equal(e.counts().prompts,0);
 e=env();await e.ctx.restoreAdminPush();assert.equal(e.visible.adminPushPanel,false);assert.equal(e.counts().writes,1);assert.equal(e.counts().prompts,0);
 e=env({saved:true,permission:'prompt'});await e.ctx.restoreAdminPush();assert.equal(e.visible.adminPushPanel,true);assert.equal(e.counts().prompts,0);assert.equal(e.counts().registers,0);
 e=env({saved:true,fail:true});await e.ctx.restoreAdminPush();assert.equal(e.visible.adminPushPanel,true);assert.equal(e.data.size,0);
 e=env();e.nonAdmin();e.ctx.updateAdminPushPanel();assert.equal(e.visible.adminPushPanel,false);await e.ctx.restoreAdminPush();assert.equal(e.counts().registers,0);
 console.log('PASS: successful save hides card, rerender/restart persistence, legacy registration, no automatic permission prompt, failures restore card, non-admin hidden');
})().catch(e=>{console.error(e);process.exit(1)});
