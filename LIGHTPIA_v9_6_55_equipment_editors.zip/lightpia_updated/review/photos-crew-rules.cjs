const fs=require('fs'),assert=require('assert'),{initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing'),api=require('firebase/firestore');
(async()=>{
 if(!process.env.FIRESTORE_EMULATOR_HOST)throw Error('Emulator required');
 const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8')}}),ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2';
 const {applyForCrew,validateCrewPost}=await import('../www/crew-model.js');
 try{
  await env.clearFirestore();await env.withSecurityRulesDisabled(async c=>{const db=c.firestore();for(const uid of ['author','staff','other','disabled'])await api.setDoc(api.doc(db,'members',uid),{role:'team',active:uid!=='disabled',displayName:uid,teamName:'대기 직원',teamId:''});await api.setDoc(api.doc(db,'company/main/equipment','e'),{name:'M90',total:5,loaned:1,repairing:0});});
  const db=uid=>env.authenticatedContext(uid).firestore(),a=db('author'),s=db('staff'),o=db('other'),d=db('disabled'),admin=db(ADMIN),anon=env.unauthenticatedContext().firestore();
  const post=(db,id='p')=>api.doc(db,'company/main/crewPosts',id),application=(db,id='p_staff')=>api.doc(db,'company/main/crewApplications',id),stamp=api.serverTimestamp;
  const payload={projectName:'테스트 촬영',startDate:'2099-11-01',endDate:'2099-11-02',pay:'일당 20만원',rank:'조명 지원',contact:'010-1111-2222',location:'서울',details:'지원 모집',slots:2,authorUid:'author',authorName:'author',authorTeam:'대기 직원',status:'open',createdAt:stamp(),updatedAt:stamp()};
  validateCrewPost(payload);await assertSucceeds(api.setDoc(post(a),payload));
  await assertFails(api.setDoc(post(s,'spoof'),payload));await assertFails(api.setDoc(post(anon),payload));await assertFails(api.setDoc(post(d,'blocked'),{...payload,authorUid:'disabled',authorName:'disabled'}));
  await assertFails(api.updateDoc(post(o),{pay:'0원',updatedAt:stamp()}));await assertFails(api.updateDoc(post(a),{authorUid:'other',updatedAt:stamp()}));
  await assertSucceeds(api.getDocs(api.query(api.collection(s,'company/main/crewPosts'),api.orderBy('createdAt','desc'))));
  const data={name:'staff',contact:'010-2222-3333',memo:'가능합니다'};
  await assertSucceeds(applyForCrew(api,s,'p',data,'staff'));
  await assert.rejects(applyForCrew(api,s,'p',data,'staff'));await assert.rejects(applyForCrew(api,a,'p',{...data,name:'author'},'author'));
  await assertFails(api.getDoc(application(o)));await assertSucceeds(api.getDoc(application(a)));await assertSucceeds(api.getDoc(application(s)));await assertFails(api.getDoc(application(anon)));
  await assertSucceeds(api.getDocs(api.query(api.collection(s,'company/main/crewApplications'),api.where('applicantUid','==','staff'))));
  await assertSucceeds(api.getDocs(api.query(api.collection(a,'company/main/crewApplications'),api.where('postId','==','p'))));await assertFails(api.getDocs(api.collection(o,'company/main/crewApplications')));
  await assertFails(api.updateDoc(application(o),{status:'accepted',updatedAt:stamp()}));await assertFails(api.updateDoc(application(s),{status:'accepted',updatedAt:stamp()}));
  await assertSucceeds(api.updateDoc(application(a),{status:'accepted',updatedAt:stamp()}));await assertSucceeds(api.updateDoc(application(s),{status:'withdrawn',updatedAt:stamp()}));
  await assertSucceeds(applyForCrew(api,s,'p',data,'staff'));assert.equal((await api.getDoc(application(a))).data().status,'pending');
  await assertSucceeds(api.updateDoc(post(a),{status:'closed',updatedAt:stamp()}));await assert.rejects(applyForCrew(api,o,'p',{...data,name:'other'},'other'));
  await assertFails(api.updateDoc(application(a),{status:'accepted',updatedAt:stamp()}));await assertSucceeds(api.updateDoc(application(s),{status:'withdrawn',updatedAt:stamp()}));
  await assertSucceeds(api.updateDoc(post(admin),{status:'open',updatedAt:stamp()}));
  const race=await Promise.allSettled([applyForCrew(api,o,'p',{...data,name:'other'},'other'),applyForCrew(api,o,'p',{...data,name:'other'},'other')]);assert.equal(race.filter(x=>x.status==='fulfilled').length,1);
  await assertSucceeds(api.updateDoc(post(a),{status:'deleted',updatedAt:stamp()}));await assertFails(api.updateDoc(post(a),{status:'open',updatedAt:stamp()}));
  const image='data:image/jpeg;base64,/9j/AA==',photo=(db,col='equipmentPhotos',id='e')=>api.doc(db,'company/main/'+col,id);
  const thumb={equipmentId:'e',thumbnail:image,updatedBy:ADMIN,updatedAt:stamp()};
  await assertSucceeds(api.setDoc(photo(admin),thumb));await assertSucceeds(api.getDocs(api.collection(s,'company/main/equipmentPhotos')));await assertFails(api.getDoc(photo(anon)));
  await assertFails(api.setDoc(photo(s),{...thumb,updatedBy:'staff'}));await assertFails(api.setDoc(photo(admin),{...thumb,thumbnail:'https://untrusted.example/image'}));await assertFails(api.setDoc(photo(admin),{...thumb,thumbnail:'data:image/jpeg;base64,'+'A'.repeat(24001)}));
  await assertFails(api.setDoc(photo(admin,'equipmentPhotos','missing'),{...thumb,equipmentId:'missing'}));
  await assertSucceeds(api.setDoc(photo(admin,'equipmentPhotoDetails'),{equipmentId:'e',image,updatedBy:ADMIN,updatedAt:stamp()}));await assertFails(api.deleteDoc(photo(s)));await assertSucceeds(api.deleteDoc(photo(admin)));
  console.log('PASS photo/crew rules: approved standby staff posting/application, author identity, private contacts/queries, owner/admin moderation, closed/deleted guards, withdraw/reapply, concurrent deduplication; admin-only JPEG photos, size/MIME limits, read approval and equipment existence');
 }finally{await env.cleanup();}
})().catch(e=>{console.error(e);process.exit(1)});
