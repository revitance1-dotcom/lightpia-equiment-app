const {spawnSync}=require('child_process');
for(const file of ['review/signup.integration.cjs','review/admin-rules.cjs','review/admin-worker.integration.cjs','review/maintenance-rules.cjs','review/photos-crew-rules.cjs','review/tag-correction.integration.cjs']){const r=spawnSync(process.execPath,[file],{stdio:'inherit',env:process.env});if(r.status!==0)process.exit(r.status||1);}
