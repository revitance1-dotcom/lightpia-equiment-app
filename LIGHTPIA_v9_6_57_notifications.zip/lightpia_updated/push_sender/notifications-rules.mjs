import fs from 'node:fs';
export function patchNotificationRules(source){
 if(source.includes('LNS_NOTIFICATIONS_V1'))return source;
 const m=source.match(/match\s+\/databases\/\{database\}\/documents\s*\{/);if(!m)throw Error('Unexpected rule structure');
 const at=m.index+m[0].length;return source.slice(0,at)+'\n'+fs.readFileSync(new URL('./notifications.rules',import.meta.url),'utf8')+source.slice(at);
}
