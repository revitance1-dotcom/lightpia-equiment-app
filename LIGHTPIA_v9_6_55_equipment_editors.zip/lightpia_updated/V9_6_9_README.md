V9.6.9: JSON backup restore for missing equipment only. Existing equipment is never overwritten. Loan and repair histories are not imported due to Firestore security rules.
