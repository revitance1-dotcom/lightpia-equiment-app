const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/www/app.js','utf8'),html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const rendering=s.slice(s.indexOf('let equipmentCategoryFilter='),s.indexOf('function modal(')),modal=s.slice(s.indexOf('function modal('),s.indexOf('function addEquipment('));
const cart=s.slice(s.indexOf('let cartItems='),s.indexOf('function showEquipmentDetail('));
const click=s.slice(s.indexOf('document.addEventListener("click",e=>{\n const cat='),s.indexOf('document.addEventListener("click",async e=>'));
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{for(const width of [320,393,768]){
 const page=await browser.newPage({viewport:{width,height:900},locale:'ko-KR'});page.setDefaultTimeout(10000);const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());await page.setContent(html);
 for(const module of ['equipment-search','search-input','loan-groups'])await page.addScriptTag({content:fs.readFileSync(root+'/www/'+module+'.js','utf8').replace(/export /g,'')});
 await page.addScriptTag({content:`const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const ADMIN_UID='7iSB1gW9PAhYPgi253IUk4Dooyp2',ready=true,db={},currentUser={uid:ADMIN_UID},member={displayName:'직원'},projects=[{id:'P',active:true}],teamList=[{id:'A',name:'언내추럴',projectId:'P',active:true}],reservations=[];
 let adminMode=true,teamId='admin',teamName='관리자';const isAdmin=()=>adminMode,today=()=> '2026-10-28',late=l=>l.status==='active'&&l.dueDate<'2026-10-28';
 const equipment=[{id:'e',name:'오비터',category:'LED',total:100,loaned:10,repairing:0}];
 const base={equipmentId:'e',equipmentName:'오비터',quantity:1,status:'active',loanDate:'2026-10-28',dueDate:'2026-10-31',note:'기존 비고 보존',person:'직원',ownerUid:'staff',team:'언내추럴',teamId:'A'};
 let loans=[{...base,id:'stay',equipmentGroup:'상주장비'},{...base,id:'set',equipmentGroup:'세트장비'},{...base,id:'extra',equipmentGroup:'추가장비'},{...base,id:'legacy',ownerUid:ADMIN_UID,team:'관리자',teamId:'admin',person:'관리자'},{...base,id:'external',ownerUid:ADMIN_UID,team:'관리자',teamId:'admin',rentalType:'external',externalTeam:'외부 촬영팀',externalPerson:'김광민 기사님'},{...base,id:'other-external',ownerUid:ADMIN_UID,team:'관리자',teamId:'admin',rentalType:'external',externalPerson:'이 담당자'},{...base,id:'returned',status:'returned',equipmentGroup:'상주장비'}];
 const activeLoans=()=>loans.filter(l=>l.status!=='returned'),canHandleLoan=l=>adminMode||l.teamId===teamId,canReportDamage=()=>false,untracked=()=>false,availableQtyFor=()=>90,borrowedQtyFor=()=>10,repairQtyFor=()=>0,brokenQtyFor=()=>0;
 function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}function showEquipmentDetail(){}
 const serverTimestamp=()=>0,loanDoc=id=>id,loanCol=()=>({}),doc=()=>({id:String(Math.random())}),runTransaction=()=>{};
 async function updateDoc(id,data){Object.assign(loans.find(l=>l.id===id),data);render();}
 async function submitBulkLoans(api,db,items,payload,onProgress){window.savedPayload=payload;for(const item of items)loans.push({...payload,id:item.loanId,equipmentId:item.equipmentId,equipmentName:'오비터',quantity:item.quantity,status:'active'});onProgress(items,items.length,items.length);render();}
 ${rendering}\n${modal}\n${cart}\n${click}
 $('loanSearch').addEventListener('input',render);$('loanFilter').addEventListener('change',render);
 show('app',true);show('loginGate',false);show('setupNotice',false);show('view-home',false);show('view-loans',true);render();`});
 assert.equal(await page.locator('#loanList > details').count(),2);assert.equal(await page.locator('#loanList > details[open]').count(),0);
 const staff=page.locator('[data-loan-fold="team:A"]'),stay=page.locator('[data-loan-fold="team:A/상주장비"]');await staff.locator(':scope > summary').click();await stay.locator(':scope > summary').click();assert(await stay.locator('.item').isVisible());
 await page.evaluate(()=>render());assert(await staff.getAttribute('open')!==null);assert(await stay.getAttribute('open')!==null);
 await page.locator('#loanSearch').fill('김광민');if(process.env.GROUP_PREVIEW_PATH&&width===393)await page.screenshot({path:process.env.GROUP_PREVIEW_PATH,fullPage:true});assert.equal(await page.locator('#loanList .item').count(),1);assert(await page.locator('#loanList .item').isVisible());assert((await page.locator('#loanList').innerText()).includes('외부팀'));
 await page.locator('#loanSearch').fill('');assert(await staff.getAttribute('open')!==null);assert(await stay.getAttribute('open')!==null);
 await page.evaluate(()=>editLoanClassification('legacy'));assert.equal(await page.locator('#editEquipmentGroup').inputValue(),'추가장비');
 await page.locator('#editRentalType').selectOption('external');await page.locator('#editExternalPerson').fill('기존 비고 담당자');await page.locator('#loanClassificationForm button').click();await page.waitForFunction(()=>!document.getElementById('loanClassificationForm'));
 assert.equal(await page.evaluate(()=>loans.find(l=>l.id==='legacy').externalPerson),'기존 비고 담당자');assert.equal(await page.evaluate(()=>equipment[0].loaned),10);
 await page.locator('#loanSearch').fill('기존 비고 담당자');assert.equal(await page.locator('#loanList .item').count(),1);
 await page.locator('#loanFilter').selectOption('returned');assert.equal(await page.locator('#loanList .item').count(),0);await page.locator('#loanSearch').fill('');assert.equal(await page.locator('#loanList .item').count(),1);
 await page.locator('#loanFilter').selectOption('active');
 await page.evaluate(()=>addLoan());await page.locator('[data-cart-plus=e]').click();await page.locator('#cartNext').click();
 await page.locator('#cartRentalType').selectOption('external');await page.locator('#cartExternalTeam').fill('새 외부팀');await page.locator('#cartExternalPerson').fill('외부 담당자');await page.locator('#cartBack').click();await page.locator('#cartNext').click();assert.equal(await page.locator('#cartExternalTeam').inputValue(),'새 외부팀');
 await page.locator('#cartSubmit').click();await page.waitForFunction(()=>!!window.savedPayload);assert.equal(await page.evaluate(()=>savedPayload.rentalType),'external');assert.equal(await page.evaluate(()=>savedPayload.externalTeam),'새 외부팀');assert.equal(await page.evaluate(()=>savedPayload.ownerUid),await page.evaluate(()=>ADMIN_UID));
 await page.evaluate(()=>{adminMode=false;teamId='A';teamName='언내추럴';currentUser.uid='staff';window.savedPayload=null;addLoan();});assert.equal(await page.locator('#cartRentalType').count(),0);await page.locator('[data-cart-plus=e]').click();await page.locator('#cartNext').click();await page.locator('#cartEquipmentGroup').selectOption('세트장비');await page.locator('#cartSubmit').click();await page.waitForFunction(()=>window.savedPayload?.equipmentGroup==='세트장비');assert.equal(await page.evaluate(()=>savedPayload.teamId),'A');assert.equal(await page.evaluate(()=>savedPayload.rentalType),'internal');
 await page.evaluate(()=>render());assert.equal(await page.locator('[data-classify-loan]').count(),0);assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));assert.equal(errors.length,0,errors.join('\n'));
 console.log('PASS grouped rental UI',width,'nested folds/state/search auto-open, external parties, legacy metadata edit preserves stock, admin external cart and wizard retention, staff group-only cart, no overflow');await page.close();
}}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
