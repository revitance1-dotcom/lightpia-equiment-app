# 9.6.48 — Period availability and reservation visibility

Current physical warehouse availability is explicitly labelled. Upcoming pending/approved reservation dates and quantities are shown in equipment, cart, detail and stock overview. The date step shows period capacity, blocks conflicting quantities and explains exact requested/free counts and overlap dates. Inclusive periods use peak concurrent holds instead of summing disjoint bookings. Active loans reserve their dated period; overdue unreturned loans remain occupied. Unknown legacy stock remains untracked. BOX damage EA continues to reduce whole-box capacity.

Fresh server snapshots and per-equipment transactional serialization are shared by new reservations and bulk loans to prevent simultaneous UI overbooking; changes trigger refetch/retry. New reservation writes require an operation lock, and existing equipment locks are initialized so outdated loan clients must update. Cancellation/rejection/revocation release their holds. No equipment, reservation or loan is deleted by this upgrade.

Validation: Oct31 reservation vs Oct29-Nov2 loan/reservation, nonoverlapping peaks, inclusive boundaries, exact capacity, cancellation, overdue loans, concurrent writes, 20-item reservation access budget, and viewport UI regressions.
