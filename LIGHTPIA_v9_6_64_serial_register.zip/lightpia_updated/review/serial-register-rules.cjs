const fs=require('fs'),assert=require('assert');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing');
const {doc,setDoc,getDoc,getDocs,collection,updateDoc,serverTimestamp}=require('firebase/firestore');
(async()=>{const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:fs.readFileSync(process.env.RULES_FILE||'www/firestore.rules','utf8')}});try{
 await env.clearFirestore();await env.withSecurityRulesDisabled(async c=>{const db=c.firestore();await setDoc(doc(db,'members/staff'),{active:true,role:'team',teamId:'T'});await setDoc(doc(db,'company/main/equipmentSerials/one'),{sourceName:'test',serial:'00123',ballastSerial:'00999',price:100});});
 const admin=env.authenticatedContext('7iSB1gW9PAhYPgi253IUk4Dooyp2').firestore(),staff=env.authenticatedContext('staff').firestore(),anon=env.unauthenticatedContext().firestore(),inactive=env.authenticatedContext('inactive').firestore();
 const col=db=>collection(db,'company/main/equipmentSerials'),setting=db=>doc(db,'company/main/appSettings/serialAccess');
 await assertSucceeds(getDocs(col(admin)));await assertFails(getDocs(col(staff)));await assertFails(getDocs(col(anon)));await assertFails(getDocs(col(inactive)));
 await assertFails(setDoc(setting(staff),{employeeRead:true,updatedAt:serverTimestamp()}));await assertSucceeds(setDoc(setting(admin),{employeeRead:true,updatedAt:serverTimestamp()}));await assertSucceeds(getDocs(col(staff)));await assertFails(getDocs(col(inactive)));await assertFails(getDocs(col(anon)));
 await assertFails(updateDoc(doc(staff,'company/main/equipmentSerials/one'),{price:1,updatedAt:serverTimestamp()}));await assertSucceeds(updateDoc(doc(admin,'company/main/equipmentSerials/one'),{price:200,updatedAt:serverTimestamp()}));
 await assertSucceeds(setDoc(setting(admin),{employeeRead:false,updatedAt:serverTimestamp()}));await assertFails(getDocs(col(staff)));assert.equal((await getDoc(doc(admin,'company/main/equipmentSerials/one'))).data().serial,'00123');console.log('PASS serial rules: default closed, employee read toggle, revoke, inactive/anonymous denied, admin-only edits, leading zeros preserved');
 }finally{await env.cleanup();}})().catch(e=>{console.error(e);process.exit(1)});
