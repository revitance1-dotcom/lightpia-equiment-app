// Keep the browser-owned IME value and caret intact until composition commits.
const composing=new WeakSet();
export const isSearchComposing=input=>!!input&&composing.has(input);
export function bindSearchInput(input,onSearch){
 if(!input)return;
 let pending;
 const commit=()=>{clearTimeout(pending);pending=undefined;if(input.isConnected&&!isSearchComposing(input))onSearch(input.value);};
 input.addEventListener('compositionstart',()=>{clearTimeout(pending);composing.add(input);});
 input.addEventListener('compositionend',()=>{
  composing.delete(input);
  // Safari/Android can send the final input after compositionend.
  clearTimeout(pending);pending=setTimeout(commit,0);
 });
 input.addEventListener('input',event=>{
  if(event.isComposing||isSearchComposing(input))return;
  if(pending){clearTimeout(pending);pending=setTimeout(commit,0);}else commit();
 });
}
