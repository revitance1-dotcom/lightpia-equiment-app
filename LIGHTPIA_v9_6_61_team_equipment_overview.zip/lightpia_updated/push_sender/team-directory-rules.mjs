export function patchTeamDirectoryRules(source){
 const anchor='match /teams/{teamId}';const start=source.indexOf(anchor),end=source.indexOf('\n  match ',start+anchor.length);
 if(start<0||end<0)throw Error('Unexpected team rules structure');
 let block=source.slice(start,end);if(block.includes('LNS_STAFF_TEAM_DIRECTORY_V1'))return source;
 const old="allow read: if admin() || (member() && profile().get('teamId','') == teamId);";
 if(!block.includes(old))throw Error('Unexpected team read permissions');
 block=block.replace(old,'allow read: if allowed(); // LNS_STAFF_TEAM_DIRECTORY_V1');
 return source.slice(0,start)+block+source.slice(end);
}
