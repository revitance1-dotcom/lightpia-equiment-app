V9.6.4: Uses the exact user-provided Lightpia & Softsun original waveform banner, responsive aspect ratio. Existing features unchanged.
