export async function compressEquipmentPhoto(file){
 if(!file||!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('JPG, PNG, WEBP 사진을 선택해 주세요.');
 if(file.size>20*1024*1024)throw Error('20MB 이하 사진을 선택해 주세요.');
 const url=URL.createObjectURL(file),img=new Image();
 try{
  await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('사진을 읽을 수 없습니다. 다른 사진을 선택해 주세요.'));img.src=url;});
  const encode=(max,limit)=>{
   const canvas=document.createElement('canvas');let scale=Math.min(1,max/Math.max(img.naturalWidth,img.naturalHeight));
   for(let n=0;n<5;n++){
    canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));const ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
    for(const quality of [.86,.72,.56,.4]){const data=canvas.toDataURL('image/jpeg',quality);if(data.length<=limit)return data;}
    scale*=.7;
   }throw Error('사진을 줄이지 못했습니다. 다른 사진을 선택해 주세요.');
  };
  return {image:encode(960,240000),thumbnail:encode(192,24000)};
 }finally{URL.revokeObjectURL(url);}
}
export function createEquipmentPhotos(ui){
 const {api,esc}=ui;let photos=new Map();
 const valid=s=>typeof s==='string'&&/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(s);
 function thumbnail(id){const data=photos.get(id);return `<button type="button" class="equipment-photo" data-equipment-photo="${esc(id)}" aria-label="장비 사진 보기">${valid(data)?`<img src="${data}" alt="장비 사진" loading="lazy">`:'<span aria-hidden="true">▧</span>'}</button>`;}
 async function open(id){
  const equipment=ui.equipment(id);if(!equipment)return;
  ui.modal(`${esc(equipment.name)} · 사진`,`<div id="equipmentPhotoView" data-photo-equipment="${esc(id)}"><p class="meta">사진을 불러오는 중…</p></div>${ui.isAdmin()?'<div class="row"><label class="photo-picker">사진 선택<input id="equipmentPhotoFile" type="file" accept="image/jpeg,image/png,image/webp"></label><button class="secondary" id="equipmentPhotoDelete">사진 삭제</button></div><p class="meta">한 장의 대표 사진을 등록합니다. 큰 사진은 자동으로 줄여 저장합니다.</p>':''}`);
  const root=document.getElementById('equipmentPhotoView');let saved=null,saving=false;
  const paint=data=>{if(root.isConnected)root.innerHTML=valid(data)?`<img class="equipment-photo-large" src="${data}" alt="${esc(equipment.name)} 사진">`:'<div class="empty">등록된 사진이 없습니다.</div>';};
  const ref=api.doc(ui.db(),'company/main/equipmentPhotoDetails',id);
  try{const snap=await api.getDoc(ref);saved=snap.exists()?snap.data().image:null;paint(saved);}catch(err){if(root.isConnected)root.textContent='사진을 불러오지 못했습니다. 다시 열어 주세요.';}
  const file=document.getElementById('equipmentPhotoFile'),remove=document.getElementById('equipmentPhotoDelete');if(!root.isConnected||!file)return;
  const controls=disabled=>{saving=disabled;file.disabled=disabled;remove.disabled=disabled;};
  file.onchange=async()=>{
   if(saving||!file.files[0])return;controls(true);
   try{
    const result=await compressEquipmentPhoto(file.files[0]);paint(result.image);
    const batch=api.writeBatch(ui.db()),base={equipmentId:id,updatedBy:ui.uid(),updatedAt:api.serverTimestamp()};
    batch.set(api.doc(ui.db(),'company/main/equipmentPhotos',id),{...base,thumbnail:result.thumbnail});batch.set(ref,{...base,image:result.image});await batch.commit();saved=result.image;
   }catch(err){paint(saved);alert('사진 저장 실패: '+err.message);}finally{controls(false);file.value='';}
  };
  remove.onclick=async()=>{
   if(saving||!confirm('이 장비의 사진을 삭제할까요?'))return;controls(true);
   try{const batch=api.writeBatch(ui.db());batch.delete(api.doc(ui.db(),'company/main/equipmentPhotos',id));batch.delete(ref);await batch.commit();saved=null;paint(null);}catch(err){alert('사진 삭제 실패: '+err.message);}finally{controls(false);}
  };
 }
 document.addEventListener('click',event=>{const target=event.target.closest('[data-equipment-photo]');if(target){event.stopPropagation();open(target.dataset.equipmentPhoto).catch(err=>alert(err.message));}});
 return {thumbnail,open,reset:()=>{photos=new Map();},subscribe:()=>api.onSnapshot(api.collection(ui.db(),'company/main/equipmentPhotos'),snap=>{photos=new Map(snap.docs.map(d=>[d.id,d.data().thumbnail]));ui.render();},()=>ui.error('장비 사진을 불러오지 못했습니다.'))};
}
