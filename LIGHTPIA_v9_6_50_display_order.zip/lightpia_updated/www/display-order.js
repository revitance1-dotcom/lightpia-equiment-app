// Shared natural equipment order: names A–Z/가–하, numbers descending within a series.
const orderCollator=new Intl.Collator('ko',{sensitivity:'base'});
export function compareEquipment(a,b){
 const name=x=>String(x?.equipmentName??x?.name??'').normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase();
 const left=name(a).match(/\d+(?:\.\d+)?|[^\d]+/g)||[],right=name(b).match(/\d+(?:\.\d+)?|[^\d]+/g)||[];
 for(let i=0;i<Math.min(left.length,right.length);i++){
  const x=left[i],y=right[i];if(x===y)continue;
  const numeric=/^\d/.test(x)&&/^\d/.test(y),result=numeric?Number(y)-Number(x):orderCollator.compare(x,y);
  if(result)return result;
 }
 return left.length-right.length||orderCollator.compare(String(a?.model||''),String(b?.model||''))||String(a?.id||'').localeCompare(String(b?.id||''));
}
export function orderedKeys(available,saved=[]){
 const keys=[...new Set(available)],seen=new Set();
 return [...(Array.isArray(saved)?saved:[]),...keys].filter(k=>typeof k==='string'&&keys.includes(k)&&!seen.has(k)&&seen.add(k));
}
export function createDisplayOrder({isAdmin,onSave,onChange,storage=globalThis.localStorage,cacheKey='lp-display-order-v1'}){
 let groups={},gesture=null,suppressUntil=0,saving=Promise.resolve(),pending=new Set();
 const valid=['categories','loanActions','homeQuick','homeRecords','homeStats'];
 const clean=data=>Object.fromEntries(valid.filter(k=>Array.isArray(data?.[k])).map(k=>[k,[...new Set(data[k].filter(v=>typeof v==='string'&&v.length<=120))].slice(0,200)]));
 try{groups=clean(JSON.parse(storage.getItem(cacheKey)||'{}'));}catch{}
 const cache=()=>{try{storage.setItem(cacheKey,JSON.stringify(groups));}catch{}};
 const children=el=>[...el.children].filter(n=>n.hasAttribute('data-order-key'));
 const apply=()=>{if(gesture?.active)return;document.body.classList.toggle('admin-display-order',isAdmin());for(const el of document.querySelectorAll('[data-reorder-group]')){
  const nodes=children(el),map=new Map(nodes.map(n=>[n.dataset.orderKey,n]));
  for(const key of orderedKeys([...map.keys()],groups[el.dataset.reorderGroup]))el.append(map.get(key));
  el.classList.toggle('reorder-enabled',isAdmin());
  for(const n of nodes){if(isAdmin())n.setAttribute('title','길게 눌러 드래그하면 순서 변경 · Alt+방향키');else n.removeAttribute('title');}
 }};
 function persist(group,keys){
  const before=groups[group];groups={...groups,[group]:keys};cache();pending.add(group);onChange?.();apply();
  // Serialize writes from this device; roll back visibly if saving is rejected.
  saving=saving.catch(()=>{}).then(()=>onSave(group,keys)).catch(error=>{
   if(groups[group]===keys){groups={...groups,[group]:before||[]};cache();onChange?.();apply();}
   alert('순서 저장에 실패했습니다. 다시 변경해 주세요.\n'+error.message);
  }).finally(()=>{if(groups[group]===keys||groups[group]===before)pending.delete(group);});
  return saving;
 }
 function start(target,x,y,touch){
  if(!isAdmin()||gesture||target.disabled)return;
  const el=target.closest('[data-order-key]'),parent=el?.parentElement;
  if(!parent?.hasAttribute('data-reorder-group')||children(parent).length<2)return;
  gesture={el,parent,x,y,touch,active:false,original:children(parent).map(n=>n.dataset.orderKey)};
  gesture.timer=setTimeout(()=>{
   if(!gesture||!el.isConnected)return finish(false);
   gesture.active=true;const rect=el.getBoundingClientRect(),ghost=el.cloneNode(true);
   ghost.removeAttribute('id');ghost.querySelectorAll('[id]').forEach(n=>n.removeAttribute('id'));
   ghost.classList.add('reorder-ghost');ghost.style.width=rect.width+'px';ghost.style.height=rect.height+'px';ghost.style.left=x-rect.width/2+'px';ghost.style.top=y-rect.height/2+'px';
   document.body.append(ghost);gesture.ghost=ghost;gesture.width=rect.width;gesture.height=rect.height;
   gesture.lastX=x;gesture.lastY=y;gesture.scrollTimer=setInterval(()=>{if(gesture?.active)move(gesture.lastX,gesture.lastY,{cancelable:false});},80);
   el.classList.add('reorder-source');document.body.classList.add('reorder-dragging');navigator.vibrate?.(25);
  },450);
 }
 function move(x,y,event){
  const g=gesture;if(!g)return;
  if(!g.active){if(Math.hypot(x-g.x,y-g.y)>10)finish(false);return;}
  g.lastX=x;g.lastY=y;if(event.cancelable)event.preventDefault();
  g.ghost.style.left=x-g.width/2+'px';g.ghost.style.top=y-g.height/2+'px';
  const hit=document.elementFromPoint(x,y)?.closest('[data-order-key]');
  if(hit&&hit!==g.el&&hit.parentElement===g.parent){const nodes=children(g.parent);g.parent.insertBefore(g.el,nodes.indexOf(hit)>nodes.indexOf(g.el)?hit.nextSibling:hit);}
  const rect=g.parent.getBoundingClientRect();
  if(g.parent.scrollWidth>g.parent.clientWidth){if(x>rect.right-35)g.parent.scrollLeft+=18;else if(x<rect.left+35)g.parent.scrollLeft-=18;}
  let scroll=g.parent;while(scroll&&scroll!==document.body){if(scroll.scrollHeight>scroll.clientHeight+2&&/auto|scroll/.test(getComputedStyle(scroll).overflowY))break;scroll=scroll.parentElement;}
  const region=scroll&&scroll!==document.body?scroll.getBoundingClientRect():{top:0,bottom:innerHeight};
  const dy=y<region.top+45?-15:y>region.bottom-45?15:0;
  if(dy){if(scroll&&scroll!==document.body)scroll.scrollTop+=dy;else window.scrollBy(0,dy);}
 }
 function finish(commit=true){
  const g=gesture;if(!g)return;gesture=null;clearTimeout(g.timer);clearInterval(g.scrollTimer);
  if(!g.active)return;
  suppressUntil=Date.now()+700;g.ghost.remove();g.el.classList.remove('reorder-source');document.body.classList.remove('reorder-dragging');
  const keys=children(g.parent).map(n=>n.dataset.orderKey);
  if(!commit){const map=new Map(children(g.parent).map(n=>[n.dataset.orderKey,n]));g.original.forEach(k=>map.get(k)&&g.parent.append(map.get(k)));onChange?.();apply();return;}
  if(keys.join('\0')===g.original.join('\0')){onChange?.();apply();return;}
  persist(g.parent.dataset.reorderGroup,orderedKeys([...keys,...(groups[g.parent.dataset.reorderGroup]||[])],keys.concat(groups[g.parent.dataset.reorderGroup]||[])));
 }
 document.addEventListener('pointerdown',e=>{if(e.pointerType!=='touch'&&e.button===0)start(e.target,e.clientX,e.clientY,false);});
 document.addEventListener('pointermove',e=>{if(gesture&&!gesture.touch)move(e.clientX,e.clientY,e);},{passive:false});
 document.addEventListener('pointerup',()=>{if(gesture&&!gesture.touch)finish();});
 document.addEventListener('pointercancel',()=>{if(gesture&&!gesture.touch)finish(false);});
 document.addEventListener('touchstart',e=>{if(e.touches.length===1)start(e.target,e.touches[0].clientX,e.touches[0].clientY,true);else finish(false);},{passive:true});
 document.addEventListener('touchmove',e=>{if(gesture?.touch&&e.touches.length===1)move(e.touches[0].clientX,e.touches[0].clientY,e);},{passive:false});
 document.addEventListener('touchend',e=>{if(gesture?.touch){if(gesture.active&&e.cancelable)e.preventDefault();finish();}},{passive:false});
 document.addEventListener('touchcancel',()=>finish(false));
 document.addEventListener('contextmenu',e=>{if(gesture?.active)e.preventDefault();});
 document.addEventListener('click',e=>{if(Date.now()<suppressUntil){e.preventDefault();e.stopImmediatePropagation();}},true);
 document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){finish(false);return;}
  if(!isAdmin()||!e.altKey||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key))return;
  const el=e.target.closest('[data-order-key]'),parent=el?.parentElement;if(!parent?.hasAttribute('data-reorder-group'))return;
  e.preventDefault();const nodes=children(parent),from=nodes.indexOf(el),to=from+(['ArrowLeft','ArrowUp'].includes(e.key)?-1:1);if(to<0||to>=nodes.length)return;
  parent.insertBefore(el,to>from?nodes[to].nextSibling:nodes[to]);persist(parent.dataset.reorderGroup,orderedKeys([...children(parent).map(n=>n.dataset.orderKey),...(groups[parent.dataset.reorderGroup]||[])]));for(const group of document.querySelectorAll('[data-reorder-group]'))if(group.dataset.reorderGroup===parent.dataset.reorderGroup)children(group).find(n=>n.dataset.orderKey===el.dataset.orderKey)?.focus();
 });
 window.addEventListener('blur',()=>finish(false));document.addEventListener('visibilitychange',()=>{if(document.hidden)finish(false);});
 return {order:(group,available)=>orderedKeys(available,groups[group]),apply,
  receive(data){const next=clean(data);for(const key of pending)next[key]=groups[key];groups=next;cache();if(!gesture?.active){onChange?.();apply();}},
  reset(){finish(false);apply();},whenSaved:()=>saving,isDragging:()=>!!gesture?.active};
}
