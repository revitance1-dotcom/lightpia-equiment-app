import admin from 'firebase-admin';import webpush from 'web-push';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');if(account?.project_id!=='light-4e07d')throw Error('Unexpected project');
admin.initializeApp({credential:admin.credential.cert(account)});const db=admin.firestore();
await db.runTransaction(async tx=>{const ref=db.doc('notificationSecrets/vapid'),old=await tx.get(ref);const state=db.doc('notificationState/config'),s=await tx.get(state);const keys=old.exists?old.data():webpush.generateVAPIDKeys();if(!old.exists)tx.create(ref,{...keys,createdAt:admin.firestore.FieldValue.serverTimestamp()});tx.set(db.doc('notificationConfig/public'),{vapidPublicKey:keys.publicKey},{merge:true});if(!s.exists)tx.create(state,{activatedAt:admin.firestore.Timestamp.now()});});
const adminUid='7iSB1gW9PAhYPgi253IUk4Dooyp2',pref=db.doc('notificationPreferences/'+adminUid);
const legacy=await db.collection('adminPushDevices').where('enabled','==',true).limit(1).get();
if(!legacy.empty)await db.runTransaction(async tx=>{const s=await tx.get(pref);if(!s.exists)tx.create(pref,{enabled:true,kinds:{},scope:'team',updatedAt:admin.firestore.FieldValue.serverTimestamp()});});
console.log('Notification transport ready. Existing signup rules and records unchanged.');
