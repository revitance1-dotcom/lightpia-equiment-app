const cleanReservationParty=v=>String(v??'').trim();
export function reservationDestination({admin,mode='internal',teamId,currentTeamId,teams=[],projects=[],externalTeam='',externalPerson=''}){
 if(!['internal','external'].includes(mode)||(!admin&&mode!=='internal'))throw Error('외부팀 예약은 관리자만 등록할 수 있습니다.');
 if(mode==='external'){
  externalTeam=cleanReservationParty(externalTeam);externalPerson=cleanReservationParty(externalPerson);
  if(!externalTeam&&!externalPerson)throw Error('외부팀명 또는 담당자 이름을 입력해 주세요.');
  if(externalTeam.length>100||externalPerson.length>80)throw Error('외부팀명은 100자, 담당자는 80자 이내로 입력해 주세요.');
  return {rentalType:'external',externalTeam,externalPerson,projectId:'',projectName:'외부팀',teamId:'admin',teamName:externalTeam||externalPerson};
 }
 const team=teams.find(t=>t.id===(admin?teamId:currentTeamId)),project=projects.find(p=>p.id===team?.projectId);
 if(!team||team.active===false||!project||project.active===false)throw Error('진행 중인 작품과 팀을 선택하세요.');
 return {rentalType:'internal',externalTeam:'',externalPerson:'',projectId:project.id,projectName:project.name,teamId:team.id,teamName:team.name};
}
export function reservationPartyLabel(r,teams=[],projects=[]){
 if(r.rentalType==='external')return '외부팀 · '+[r.externalTeam,r.externalPerson].filter(Boolean).join(' · ');
 const p=projects.find(p=>p.id===r.projectId),t=teams.find(t=>t.id===r.teamId);
 return (p?.name||r.projectName||'작품 미지정')+' · '+(t?.name||r.teamName||'팀 미지정');
}
