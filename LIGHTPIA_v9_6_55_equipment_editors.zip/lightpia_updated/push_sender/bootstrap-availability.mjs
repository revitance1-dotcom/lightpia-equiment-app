import admin from 'firebase-admin';
import {bootstrapAvailability} from './availability-bootstrap.mjs';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');if(account?.project_id!=='light-4e07d')throw Error('Expected Lightpia account');admin.initializeApp({credential:admin.credential.cert(account)});const count=await bootstrapAvailability(admin.firestore(),()=>admin.firestore.FieldValue.serverTimestamp());console.log('Availability serialization initialized for',count,'equipment; existing locks preserved.');
