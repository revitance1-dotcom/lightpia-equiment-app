import {fulfillReservation} from './reservation-fulfillment.js';
import {submitCheckedReservation} from './availability-model.js';
import {remainingReservationItems,overdueUnshippedReservations,periodCapacity,capacityFailure,upcomingReservationText,packSize,loanEa,damageEa,reportEa,loanQuantityText,inventoryStock,stockRemainderText,unitSnapshot,validateUnit,sameUnit,quantityText,unitHint,sumUnitQuantities,unitFields,bindUnitFields,readUnitFields,saveUnitEquipment} from './equipment-units.js';
import {LOAN_GROUPS,loanMetadata,loanParty,loanGroupName,loanSearchText,groupLoans,loanTeamLabel,loanDestination} from "./loan-groups.js";
import {bindSearchInput,isSearchComposing,searchText} from "./search-input.js";
import {submitSignup} from "./signup-model.js";
import {reservationDestination,reservationPartyLabel} from "./reservation-parties.js";
import {createPhotoBackup} from "./photo-backup.js";
import {createEquipmentPhotos} from "./equipment-photos.js";
import {createCrewBoard} from "./crew-board.js";
import { normalizeEquipmentTags, matchesEquipmentSearch } from "./equipment-search.js";
import { installAndroidBackHandler } from "./android-back.js";
import { submitBulkLoans } from "./bulk-loan-model.js";
import { setRepairQuantity, submitDamageReport, transitionDamageReport, maintenanceReturnFields } from "./maintenance-model.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, setPersistence, browserLocalPersistence } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, doc, addDoc, setDoc, updateDoc, deleteDoc, onSnapshot, query, orderBy, serverTimestamp, getDoc, runTransaction, writeBatch, where, getDocs, getDocsFromServer, documentId, limit, startAfter, enableIndexedDbPersistence } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

const $=id=>document.getElementById(id);
const ADMIN_UID="7iSB1gW9PAhYPgi253IUk4Dooyp2";
let member=null,role="",teamName="",teamId="",teamList=[],joinRequests=[],projects=[],membersList=[],reservations=[],adminOperations=[],breakdownReports=[];
const isAdmin=()=>role==="admin";
const canHandleLoan=l=>isAdmin()||(role==="team"&&(l.ownerUid===currentUser?.uid || (teamId && l.teamId===teamId)));
let app,auth,db,currentUser=null,ready=false,unsubs=[],equipment=[],loans=[],repairs=[],activeTab="home",busy=false;
const maintenanceApi={runTransaction,doc,collection,serverTimestamp};
function checkedCapacityApi(){return {runTransaction,doc,collection,getDoc,getDocsFromServer,query,where,serverTimestamp};}
const warehouseBrokenQtyFor=id=>inventoryStock(equipment.find(x=>x.id===id)).brokenTotalEa;
const brokenQtyFor=id=>breakdownReports.filter(r=>r.equipmentId===id&&r.status==="reported").reduce((n,r)=>n+reportEa(r),0);
const canReportDamage=l=>canHandleLoan(l)&&(isAdmin()||(teamId&&teamList.some(t=>t.id===teamId&&t.active!==false)));
const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const activeLoans=()=>loans.filter(x=>x.status!=="returned");
const late=x=>x.status!=="returned"&&x.dueDate&&x.dueDate<today();
const BUILTIN_FIREBASE_CONFIG={"apiKey":"AIzaSyDsEYnXz66SI3X2BVQGBtdO1gxGgZEWJD8","authDomain":"light-4e07d.firebaseapp.com","projectId":"light-4e07d","storageBucket":"light-4e07d.firebasestorage.app","messagingSenderId":"668941084388","appId":"1:668941084388:web:1b0d169e7ccfec46946ef1"};
const cfg=()=>JSON.stringify(BUILTIN_FIREBASE_CONFIG);
const eqCol=()=>collection(db,"company","main","equipment");
const loanCol=()=>collection(db,"company","main","loans");
const repairCol=()=>collection(db,"company","main","repairs");
const reservationCol=()=>collection(db,"company","main","reservations");
const eqDoc=id=>doc(db,"company","main","equipment",id);
const loanDoc=id=>doc(db,"company","main","loans",id);
const repairDoc=id=>doc(db,"company","main","repairs",id);
const activeRepairs=()=>repairs.filter(x=>x.status!=="completed");
const repairQtyFor=id=>inventoryStock(equipment.find(x=>x.id===id)).repairTotalEa;
const borrowedQtyFor=id=>Number(equipment.find(x=>x.id===id)?.loaned||0);
const availableQtyFor=id=>inventoryStock(equipment.find(x=>x.id===id)).available;
const untracked=id=>Number(equipment.find(x=>x.id===id)?.total||0)===0;
function status(text,ok=false){$("connection").textContent=text;$("connection").className="status"+(ok?" ok":"")}
function show(el,on=true){const node=$(el);if(node)node.classList.toggle("hidden",!on)}
function cfgShow(){show("configPanel",true)}
function clearSubs(){unsubs.forEach(f=>f());unsubs=[]}
function subscribe(){clearSubs();unsubs.push(equipmentPhotos.subscribe(),...crewBoard.subscribe());unsubs.push(onSnapshot(collection(db,"company","main","damageReports"),snap=>{breakdownReports=snap.docs.map(d=>({...d.data(),id:d.id}));render()},e=>status("고장 신고 읽기 오류")));if(!isAdmin())unsubs.push(onSnapshot(doc(db,"members",currentUser.uid),snap=>{if(!snap.exists()||snap.data().active!==true){ready=false;show("app",false);signOut(auth).catch(()=>{});}},()=>{}));if(!isAdmin()&&teamId)unsubs.push(onSnapshot(doc(db,"teams",teamId),snap=>{if(snap.exists()){teamList=[{id:snap.id,...snap.data()}];refreshAccountIdentity();render();}},()=>{}));unsubs.push(onSnapshot(collection(db,"projects"),snap=>{projects=snap.docs.map(d=>({...d.data(),id:d.id}));refreshAccountIdentity();renderProjects();render()},e=>status("작품 읽기 오류")));if(isAdmin()){unsubs.push(onSnapshot(collection(db,"adminOperations"),snap=>{adminOperations=snap.docs.map(d=>({...d.data(),id:d.id}));renderProjects();renderTeamAdmin()},()=>{}));unsubs.push(onSnapshot(collection(db,"members"),snap=>{membersList=snap.docs.map(d=>({...d.data(),id:d.id}));renderProjects()},e=>status("직원 목록 읽기 오류")));unsubs.push(onSnapshot(collection(db,"teams"),snap=>{teamList=snap.docs.map(d=>({...d.data(),id:d.id}));renderTeamAdmin();renderProjects();render()},e=>status("팀 목록 읽기 오류")));unsubs.push(onSnapshot(collection(db,"joinRequests"),snap=>{joinRequests=snap.docs.map(d=>({...d.data(),id:d.id}));renderTeamAdmin()},e=>status("가입 신청 읽기 오류")))}unsubs.push(onSnapshot(query(eqCol(),orderBy("name")),s=>{equipment=s.docs.map(d=>({...d.data(),id:d.id}));render();},e=>status("장비 읽기 오류")));unsubs.push(onSnapshot(query(loanCol(),orderBy("createdAt","desc")),s=>{loans=s.docs.map(d=>({...d.data(),id:d.id}));render();renderProjects();},e=>status("대여 기록 읽기 오류")));unsubs.push(onSnapshot(reservationCol(),s=>{reservations=s.docs.map(d=>({...d.data(),id:d.id}));renderReservations();render();if(!s.metadata?.fromCache)remindOverdueReservations();if($('loanReviewList'))refreshLoanPeriod();if($('reserveEquipmentList')){refreshReservationQuantities();renderReservationEquipment();}},e=>status("예약 읽기 오류: "+e.message)));unsubs.push(onSnapshot(repairCol(),s=>{repairs=s.docs.map(d=>({...d.data(),id:d.id}));render();},e=>status("수리 기록 읽기 오류")))}
function accountTeamLabel(){
 return isAdmin()?"관리자":loanTeamLabel({team:teamName,teamId},teamList,projects);
}
function refreshAccountIdentity(u=currentUser){
 if(!ready||!u)return;
 const label=accountTeamLabel(),info=$("accountInfo"),connection=$("connection");
 const account=(u.email?.endsWith("@"+ID_DOMAIN)?u.email.split("@")[0]:u.email)||"계정";
 const infoText=`${label} · ${account} · 회사 공용 재고`;
 if(info&&info.textContent!==infoText)info.textContent=infoText;
 // Keep an existing read/permission error visible while team data is arriving.
 if(connection?.classList.contains("ok")){
  const connectionText=`${label} · 공용 재고 연결됨`;
  if(connection.textContent!==connectionText)connection.textContent=connectionText;
 }
}
function updateAccountUI(u){
 const info=$("accountInfo");if(!info)return;
 refreshAccountIdentity(u);
 show("emailLoginPanel",false);
 show("emailAccountPanel",!u.isAnonymous);
 if(!u.isAnonymous)$("signedInEmail").textContent=u.email||"이메일 계정";
 show("addEquipmentBtn",isAdmin());show("importJsonBtn",isAdmin());
 updateAdminPushPanel();show("projectsPanel",isAdmin());show("photoBackupPanel",isAdmin());const teamPanel=$("teamAdminPanel");if(teamPanel)teamPanel.classList.toggle("hidden",!isAdmin());
}
function initConfig(raw){
 const c=JSON.parse(raw);if(!c.apiKey||!c.projectId||!c.appId)throw Error("apiKey, projectId, appId 설정이 필요합니다.");
 app=initializeApp(c);auth=getAuth(app);setPersistence(auth,browserLocalPersistence).catch(e=>console.warn("로그인 유지 설정 실패",e));db=getFirestore(app);enableIndexedDbPersistence(db).catch(()=>{});
 onAuthStateChanged(auth,async u=>{
  clearSubs();$("modalRoot").innerHTML="";ready=false;currentUser=null;member=null;role="";teamName="";teamId="";
  equipment=[];loans=[];repairs=[];adminOperations=[];breakdownReports=[];equipmentPhotos.reset();crewBoard.reset();show("app",false);show("loginGate",true);
  if(!u){status("로그인 필요");return}
  if(u.isAnonymous){status("V7에서는 이메일 로그인이 필요합니다");await signOut(auth);return}
  try{
   const profile=await getDoc(doc(db,"members",u.uid));
   if(u.uid===ADMIN_UID){role="admin";teamName="관리자";teamId="admin"}
   else if(profile.exists()&&profile.data().active===true&&profile.data().role==="team"){
    role="team";teamName=profile.data().teamName;teamId=profile.data().teamId||"";member=profile.data();
   }else{status("등록되지 않은 팀 계정");status("관리자 승인 대기 중");$("pendingNotice").textContent="가입 신청을 완료했다면 관리자 승인을 기다려 주세요. 승인 후 로그아웃하고 다시 로그인하세요.";show("pendingNotice",true);show("pendingSignOutBtn",true);return}
   currentUser=u;ready=true;subscribe();show("app",true);show("loginGate",false);show("setupNotice",false);show("configPanel",false);
   updateAccountUI(u);restoreAdminPush().catch(()=>{});status(`${accountTeamLabel()} · 공용 재고 연결됨`,true);render();
  }catch(e){status("계정 권한 확인 실패");alert("팀 권한 확인 실패: "+e.message)}
 });
}
const REMEMBER_KEY="lnsRememberedAccount";
function initRememberedAccount(){
 const saved=localStorage.getItem(REMEMBER_KEY)||"";
 for(const id of ["gateLoginEmail","loginEmail"]){const el=$(id);if(el&&saved)el.value=saved;}
 for(const id of ["gateRememberId","rememberId"]){const el=$(id);if(el)el.checked=!!saved;}
}
function rememberAccount(account,gate){
 const checked=$(gate?"gateRememberId":"rememberId")?.checked===true;
 if(checked)localStorage.setItem(REMEMBER_KEY,account);
 else localStorage.removeItem(REMEMBER_KEY);
}
const ID_DOMAIN="accounts.lightpia.internal";
const accountEmail=id=>id.includes("@")?id:id.toLowerCase()+"@"+ID_DOMAIN;
async function loginEmail(){
 const gate=!$("loginGate").classList.contains("hidden");const account=$(gate?"gateLoginEmail":"loginEmail").value.trim(),email=accountEmail(account),password=$(gate?"gateLoginPassword":"loginPassword").value;
 if(!account||!password)return alert("아이디와 비밀번호를 입력해 주세요.");
 if(auth.currentUser?.isAnonymous && !confirm("현재 익명 저장소에서 이메일 계정으로 전환합니다. 기존 장비 데이터는 자동으로 옮겨지지 않습니다. 설정 → 전체 백업 다운로드(JSON)를 먼저 완료했나요?"))return;
 try{await setPersistence(auth,browserLocalPersistence);await signInWithEmailAndPassword(auth,email,password);rememberAccount(account,gate);$(gate?"gateLoginPassword":"loginPassword").value="";alert("로그인 성공! 회사 공용 재고에 연결합니다.")}
 catch(e){alert("로그인 실패: "+e.message)}
}

let equipmentCategoryFilter="전체";
function equipmentImageLabel(id,body,mode='row'){
 return typeof equipmentPhotos!=='undefined'&&equipmentPhotos.label?equipmentPhotos.label(id,body,mode):body;
}

function reservationBadge(e){const text=upcomingReservationText(e,typeof reservations==='undefined'?[]:reservations,typeof today==='function'?today():'');return text?`<span class="reservation-notice"><span class="pill amber">예약 있음</span> ${esc(text)}</span>`:'';}
function cartPeriodResult(e){return periodCapacity(e,typeof loans==='undefined'?[]:loans,typeof reservations==='undefined'?[]:reservations,$('cartDate')?.value||today(),$('cartDue')?.value||today(),today());}
function refreshLoanPeriod(){if(!$('loanReviewList'))return;const chosen=Object.entries(cartItems).filter(([,n])=>n>0);let blocked=false;$('loanReviewList').innerHTML=chosen.map(([id,n])=>{const e=equipment.find(x=>x.id===id),result=cartPeriodResult(e),bad=!untracked(id)&&n>Math.min(result.free,availableQtyFor(id));blocked||=bad;return `<div class="loan-review-row"><span>${equipmentImageLabel(id,esc(e.name),'review')}<small class="meta ${bad?'red':''}">기간 내 대여 가능 ${untracked(id)?'수량 미확정':quantityText(Math.min(result.free,availableQtyFor(id)),e)}${bad?' · 선택 수량 부족':''}</small>${reservationBadge(e)}</span><strong>${loanQuantityText(n,e)}</strong></div>`;}).join('');const notice=$('loanPeriodNotice');if(notice){notice.classList.toggle('hidden',!blocked);notice.textContent=blocked?'선택 기간에 예약·대여가 겹쳐 수량이 부족합니다. 날짜 또는 수량을 변경해 주세요.':'';}if($('cartSubmit'))$('cartSubmit').disabled=!chosen.length||blocked;}


const equipmentCategoryName=e=>{
 const raw=String(e.category||"").trim();
 if(!raw)return "미분류";
 if(/^sky[ -]?panel$/i.test(raw))return "SKYPANEL";
 return raw;
};
function renderEquipmentCategories(){
 const target=$("equipmentCategories");if(!target)return;
 const counts=new Map();
 equipment.forEach(e=>{const cat=equipmentCategoryName(e);counts.set(cat,(counts.get(cat)||0)+1)});
 const cats=["전체","__repairing","__broken",...Array.from(counts.keys()).sort((a,b)=>{
  const order=["HMI","LED","SKYPANEL","텅스텐","조명 제어","스탠드·그립","액세서리","기타","미분류"];
  const ai=order.indexOf(a),bi=order.indexOf(b);
  return (ai<0?999:ai)-(bi<0?999:bi)||a.localeCompare(b,"ko");
 })];
 if(!cats.includes(equipmentCategoryFilter))equipmentCategoryFilter="전체";
 target.innerHTML=cats.map(cat=>`<button type="button" class="small ${equipmentCategoryFilter===cat?"":"secondary"}" data-equipment-category="${esc(cat)}" aria-pressed="${equipmentCategoryFilter===cat}" style="margin:0 5px 7px 0">${cat==="__repairing"?"수리 중":cat==="__broken"?"고장 중":esc(cat)} (${cat==="전체"?equipment.length:cat==="__repairing"?equipment.filter(x=>repairQtyFor(x.id)>0).length:cat==="__broken"?equipment.filter(x=>brokenQtyFor(x.id)>0).length:counts.get(cat)})</button>`).join("");
}
const loanFoldState=new Map();
let loanSearchExpanded=false;
function renderLoanGroups(rows,searching=false){
 const target=$('loanList');if(!target)return;
 if(!loanSearchExpanded)target.querySelectorAll('details[data-loan-fold]').forEach(el=>loanFoldState.set(el.dataset.loanFold,el.open));
 loanSearchExpanded=searching;
 const count=rows=>`${rows.length}건 · ${sumUnitQuantities(rows)}`;
 const fold=(id,label,rows,content)=>`<details class="loan-fold" data-loan-fold="${esc(id)}" ${searching||loanFoldState.get(id)?'open':''}><summary><span class="loan-fold-heading"><strong>${esc(label)}</strong></span><span class="loan-fold-count">${count(rows)}</span></summary><div class="loan-fold-body">${content}</div></details>`;
 target.innerHTML=rows.length?groupLoans(rows,ADMIN_UID,teamList,projects).map(g=>fold(g.id,g.label,g.rows,g.sections.map(section=>fold(section.id,section.label,section.rows,section.parties.length?section.parties.map(p=>fold(p.id,p.label,p.rows,p.rows.map(loanCard).join(''))).join(''):section.rows.map(loanCard).join(''))).join(''))).join(''):'<div class="empty">조건에 맞는 기록이 없습니다.</div>';
}

function render(){if(!ready)return;
 for(const id of ["bulkDeleteReturnedBtn","bulkDeleteReturnedHomeBtn"]){const b=$(id);if(b)b.style.display=isAdmin()?"":"none";}
 const al=activeLoans();$("statKinds").textContent=teamList.filter(t=>t.active!==false&&projects.some(p=>p.id===t.projectId&&p.active!==false)).length;$("statTotal").textContent=reservations.filter(r=>r.status==="pending").length;$("statLoan").textContent=reservations.filter(r=>r.status==="approved").length;$("statLate").textContent=al.filter(late).length;
 const due=al.filter(x=>x.dueDate).sort((a,b)=>a.dueDate.localeCompare(b.dueDate)).slice(0,5);$("dueList").innerHTML=due.length?due.map(loanCard).join(""):'<div class="empty">반납 예정 기록이 없습니다.</div>';
 $("recentList").innerHTML=loans.length?loans.slice(0,4).map(loanCard).join(""):'<div class="empty">대여 기록이 없습니다.</div>';
 renderEquipmentList();
 renderStockOverview();
 if(typeof renderOverdueReservationNotice==='function')renderOverdueReservationNotice();
 if($("loanReviewList")&&!cartSubmitting)renderCart(true);
 if($("reserveEquipmentList")){refreshReservationQuantities();renderReservationEquipment();}
 if($("modalBack")?.refreshReturns&&!bulkReturnSubmitting)$("modalBack").refreshReturns();
 const q=($("loanSearch")?.value||"").toLowerCase(),filter=$("loanFilter")?.value||"active";const ls=loans.filter(l=>{const match=loanSearchText(l,teamList,projects).includes(q);return match&&(filter==="all"||(filter==="active"&&l.status!=="returned")||(filter==="late"&&late(l))||(filter==="returned"&&l.status==="returned"))});renderLoanGroups(ls,!!q.trim());
 if($("modalBack")?.dataset.equipmentDetail)showEquipmentDetail($("modalBack").dataset.equipmentDetail);
}
function renderEquipmentList(){
 if(!ready)return;
 renderEquipmentCategories();
 const search=searchText($("equipmentSearch")).toLowerCase().trim();
 const es=equipment.filter(x=>(equipmentCategoryFilter==="전체"||(equipmentCategoryFilter==="__repairing"?repairQtyFor(x.id)>0:equipmentCategoryFilter==="__broken"?brokenQtyFor(x.id)>0:equipmentCategoryName(x)===equipmentCategoryFilter))&&matchesEquipmentSearch(x,search));
 const groups=new Map();
 es.forEach(e=>{const category=equipmentCategoryName(e);if(!groups.has(category))groups.set(category,[]);groups.get(category).push(e)});
 $("equipmentList").innerHTML=es.length?[...groups.entries()].map(([category,items])=>`<section class="equipment-group"><div class="equipment-group-head"><b>${esc(category)}</b><span>${items.length}종</span></div><div class="list">${items.map(e=>{const borrowed=borrowedQtyFor(e.id),repairing=repairQtyFor(e.id),available=availableQtyFor(e.id);return `<div class="item">${typeof equipmentPhotos!=="undefined"?equipmentPhotos.thumbnail(e.id):""}<div class="equipment-summary" data-equipment-detail="${e.id}" role="button" tabindex="0" style="flex:1;cursor:pointer;min-width:0"><div class="itemtitle">${esc(e.name)} <span class="muted" style="font-size:11px;font-weight:500">상세 보기 ›</span></div><div class="meta">${esc(e.category||"미분류")} ${e.model?"· "+esc(e.model):""}<br>${unitHint(e)}<br>전체 ${quantityText(e.total,e)} · 대여 ${quantityText(borrowed,e)} · 수리 ${repairing+'EA'} · 고장 ${brokenQtyFor(e.id)+'EA'} · <b>${untracked(e.id)?`수량 미확정 · 대여 ${quantityText(borrowed,e)}`:`현재 창고 가용 ${quantityText(available,e)}${stockRemainderText(e)}`}</b>${e.note?"<br>"+esc(e.note):""}${reservationBadge(e)}</div></div>${isAdmin()?`<div class="actions"><button class="small secondary" data-edit-equipment="${e.id}">수정</button><button class="small danger" data-delete-equipment="${e.id}">삭제</button></div>`:""}</div>` }).join("")}</div></section>`).join(""):'<div class="empty">조건에 맞는 장비가 없습니다.</div>';
}

let stockSearch='',stockCategory='전체',stockFilter='available';
function stockRows(){
 return equipment.map(e=>{const unknown=Number(e.total||0)===0,free=Math.max(0,availableQtyFor(e.id));return {e,unknown,free,present:unknown||free>0||inventoryStock(e).looseEa>0,category:equipmentCategoryName(e)}});
}
function showStockOverview(){
 stockSearch='';stockCategory='전체';stockFilter='available';
 modal('장비현황표',`<div class="stock-intro"><span class="overline">WAREHOUSE / LnS</span><p>사무실에 남아 있는 장비를 빠르게 확인하세요.</p></div><div id="stockSummary" class="stock-summary"></div><div class="stock-controls"><input id="stockSearch" class="search" placeholder="장비명 · 분류 · 검색 태그" aria-label="장비현황 검색"><div class="stock-filters" role="group" aria-label="보유 상태"><button type="button" data-stock-filter="available">보유 장비</button><button type="button" data-stock-filter="all">전체 장비</button><button type="button" data-stock-filter="out">잔여 없음</button></div><div id="stockCategories" class="stock-categories" aria-label="장비 분류"></div></div><p class="stock-help">총수량 0으로 등록한 장비는 <b>보유 · 수량 미집계</b>로 포함합니다. 수리·고장 수량은 잔여에서 제외합니다.</p><div id="stockResults" class="meta" role="status" aria-live="polite"></div><div id="stockRows"></div>`);
 $('modalBack').querySelector('.modal').classList.add('stock-modal');
 bindSearchInput($('stockSearch'),value=>{stockSearch=value;renderStockOverview()});
 $('modalBack').addEventListener('click',ev=>{const f=ev.target.closest('[data-stock-filter]'),c=ev.target.closest('[data-stock-category]');if(f)stockFilter=f.dataset.stockFilter;if(c)stockCategory=c.dataset.stockCategory;if(f||c)renderStockOverview()});
 renderStockOverview();
}
function renderStockOverview(){
 const rows=stockRows(),present=rows.filter(r=>r.present),unknown=rows.filter(r=>r.unknown),out=rows.filter(r=>!r.present);
 if($('statStock'))$('statStock').textContent=present.length+'종';
 if($('statStockMeta'))$('statStockMeta').textContent=`등록 ${rows.length}종 · 수량 미집계 ${unknown.length}종 포함`;
 if(!$('stockRows'))return;
 $('stockSummary').innerHTML=[['보유 장비',present.length,'green'],['잔여 없음',out.length,'red'],['수량 미집계',unknown.length,'amber']].map(([label,n,color])=>`<div><span>${label}</span><b class="${color}">${n}<small>종</small></b></div>`).join('');
 const cats=['전체',...new Set(rows.map(r=>r.category).sort((a,b)=>a.localeCompare(b,'ko')))];if(!cats.includes(stockCategory))stockCategory='전체';
 const catHTML=cats.map(c=>`<button type="button" class="small secondary" data-stock-category="${esc(c)}" aria-pressed="${stockCategory===c}">${esc(c)}</button>`).join('');if($('stockCategories').innerHTML!==catHTML)$('stockCategories').innerHTML=catHTML;
 document.querySelectorAll('[data-stock-filter]').forEach(b=>b.setAttribute('aria-pressed',String(stockFilter===b.dataset.stockFilter)));
 const filtered=rows.filter(r=>(stockCategory==='전체'||r.category===stockCategory)&&(stockFilter==='all'||(stockFilter==='out'?!r.present:r.present))&&matchesEquipmentSearch(r.e,stockSearch.toLocaleLowerCase().trim())).sort((a,b)=>a.category.localeCompare(b.category,'ko')||a.e.name.localeCompare(b.e.name,'ko',{numeric:true}));
 $('stockResults').textContent=`${filtered.length}종 표시 · 장비를 누르면 상세 보기`;
 const groups=new Map();for(const r of filtered){if(!groups.has(r.category))groups.set(r.category,[]);groups.get(r.category).push(r)}
 $('stockRows').innerHTML=[...groups].map(([cat,items])=>`<section class="stock-section"><h3>${esc(cat)} <small>${items.length}종</small></h3><div class="stock-grid">${items.map(({e,unknown,free,present})=>`<button type="button" class="stock-item ${!present?'stock-out':''}" data-equipment-detail="${esc(e.id)}" aria-label="${esc(e.name)} · ${unknown?'보유, 수량 미집계':'잔여 '+quantityText(free,e)}"><span class="stock-name">${equipmentImageLabel(e.id,`<span class="stock-title">${esc(e.name)}</span><small>${unknown?'수량 미집계 · '+unitHint(e):`${unitHint(e)} · 전체 ${quantityText(e.total,e)} · 대여 ${quantityText(borrowedQtyFor(e.id),e)}${repairQtyFor(e.id)?' · 수리 '+repairQtyFor(e.id)+'EA':''}${inventoryStock(e).brokenTotalEa?' · 고장 입고 '+inventoryStock(e).brokenTotalEa+'EA':''}`}</small>`,'stock')}${reservationBadge(e)}</span><span class="stock-qty ${unknown?'stock-unknown':''}">${unknown?'보유':free}<small>${unknown?'미집계':unitSnapshot(e).unit+' 남음'}</small>${!unknown&&inventoryStock(e).looseEa?`<small class="stock-loose">정상 낱개 ${inventoryStock(e).looseEa}EA</small>`:''}</span>${!unknown?`<span class="stock-meter" aria-hidden="true"><i style="width:${Math.min(100,100*free/Math.max(1,Number(e.total||0)))}%"></i></span>`:''}</button>`).join('')}</div></section>`).join('')||'<div class="empty">조건에 맞는 장비가 없습니다.</div>';
}

function loanCard(l){const returned=l.status==="returned",isLate=late(l);return `<div class="item"><div><div class="itemtitle">${equipmentImageLabel(l.equipmentId,`${esc(l.equipmentName||"삭제된 장비")} · ${loanQuantityText(l.quantity,l)}`,'micro')}</div><div class="meta">${esc(loanTeamLabel(l,teamList,projects))} · ${esc(l.rentalType==="external"?"외부팀":loanGroupName(l))}${loanParty(l)?" · "+esc(loanParty(l)):""}<br>대여 ${esc(l.loanDate||"")} · 반납 예정 ${esc(l.dueDate||"미정")}${l.note?"<br>"+esc(l.note):""}${l.reservationId?"<br>예약에서 출고한 장비":""}${damageEa(l)>0?`<br><span class="pill red">${returned?"고장·수리 미완료":"대여 수량 중 고장"} ${damageEa(l)+'EA'}</span>`:""}</div><div style="margin-top:7px"><span class="pill ${returned?"green":isLate?"red":"amber"}">${returned?"반납 완료":isLate?"반납 지연":"대여 중"}</span></div></div><div class="actions">${isAdmin()?`<button class="small secondary" data-classify-loan="${esc(l.id)}">분류·대여처</button>`:""}${!returned&&canReportDamage(l)&&damageEa(l)<loanEa(l)?`<button class="small danger" data-report-damage-loan="${esc(l.id)}">고장 신고</button>`:""}${!returned&&canHandleLoan(l)?`<button class="small" data-return="${esc(l.id)}">반납</button>`:""}${isAdmin()&&returned?`<button class="small danger" data-delete-loan="${esc(l.id)}">기록 삭제</button>`:""}</div></div>`}
function modal(title,body){$("modalRoot").innerHTML=`<div class="modalback" id="modalBack"><div class="modal"><div class="modalhead"><h2>${title}</h2><button class="secondary small" id="closeModal">닫기</button></div>${body}</div></div>`;$("closeModal").onclick=closeModal;$("modalBack").onclick=e=>{if(e.target.id==="modalBack")closeModal()}}
function closeModal(){if(typeof reservationFulfillmentBusy!=="undefined"&&reservationFulfillmentBusy)return;if(typeof photoBackup!=="undefined"&&!photoBackup.beforeClose())return;if((typeof cartSubmitting!=="undefined"&&cartSubmitting)||(typeof bulkReturnSubmitting!=="undefined"&&bulkReturnSubmitting))return;if(typeof equipmentPhotos!=="undefined"&&!equipmentPhotos.beforeClose())return;$("modalRoot").innerHTML=""}
function field(label,id,placeholder="",type="text",value="",required=false){return `<div class="field"><label>${label}${required?" *":""}</label><input id="${id}" type="${type}" placeholder="${placeholder}" value="${esc(value)}" ${required?"required":""} ${type==="number"?'min="0" step="1"':""}></div>`}
function addEquipment(old={}){
 if(!old.id)return openEquipmentBatch(old);
 const targetId=old.id,prefix='edit-'+encodeURIComponent(targetId)+'-',input=k=>$(prefix+k);
 modal(`${esc(old.name)} · 장비 수정`,`<form id="equipmentForm" autocomplete="off" data-equipment-id="${esc(targetId)}"><p class="meta">이 장비에만 적용되는 검색 태그입니다.</p><div class="formgrid">${field('장비명',prefix+'name','장비명','text',old.name||'',true)}${field('분류',prefix+'category','예: HMI / LED','text',old.category||'')}${field('모델 / 규격',prefix+'model','모델명','text',old.model||'')}${field('검색어 / 태그',prefix+'tags','예: #sun #컴','text',old.searchTags||'')}${unitFields(prefix,old)}${field('전체 수량',prefix+'total','수량','number',old.total??1,true)}${field('비고',prefix+'note','보관 위치, 구성품 등','text',old.note||'')}</div><div class="modalbuttons"><button type="submit">이 장비 저장</button></div></form>`);
 bindUnitFields(prefix,prefix+'total',true);const locked=borrowedQtyFor(targetId)+repairQtyFor(targetId)+warehouseBrokenQtyFor(targetId)>0||reservations.some(r=>['pending','approved'].includes(r.status)&&(!r.endDate||r.endDate>=today())&&(r.items||[]).some(i=>i.id===targetId));if(locked){input('unit').disabled=true;input('unitsPerBox').disabled=true;}
 const form=$('equipmentForm');form.querySelectorAll('input').forEach(el=>{el.autocomplete='off';el.name=el.id;el.setAttribute('autocorrect','off');el.spellcheck=false;});
 form.onsubmit=async event=>{
  event.preventDefault();if(form.dataset.saving==='true')return;
  let units;try{units=readUnitFields(prefix);}catch(e){return alert(e.message);}
  const data={...units,name:input('name').value.trim(),category:input('category').value.trim(),model:input('model').value.trim(),searchTags:normalizeEquipmentTags(input('tags').value),total:Number(input('total').value),note:input('note').value.trim(),updatedAt:serverTimestamp()};
  if(!data.name||!input('total').value.trim()||!Number.isSafeInteger(data.total)||data.total<0)return alert('장비명과 0 이상의 정수 수량을 입력해 주세요.');
  if(!sameUnit(old,data)&&reservations.some(r=>['pending','approved'].includes(r.status)&&(!r.endDate||r.endDate>=today())&&(r.items||[]).some(i=>i.id===targetId)))return alert('진행 중인 예약을 먼저 정리한 뒤 단위를 변경해 주세요.');
  const used=Number(old.total||0)-inventoryStock(old).available;
  if(data.total!==0&&data.total<used)return alert(`대여·수리·고장 중인 ${quantityText(used,old)} 미만으로 설정할 수 없습니다.`);
  form.dataset.saving='true';const button=form.querySelector('button[type=submit]');button.disabled=true;
  try{await saveUnitEquipment({runTransaction,doc},db,targetId,data);if($('equipmentForm')===form)closeModal();}catch(err){alert('저장 실패: '+err.message);}finally{form.dataset.saving='false';button.disabled=false;}
 };
}

let cartItems={},cartCategory="전체",cartSearch="",cartStep=1,cartSubmitting=false,cartLoanRefs={};
function loanClassificationFields(){
 return `<div class="loan-recipient-fields"><p class="meta">등록 팀: ${esc(loanTeamLabel({team:teamName,teamId},teamList,projects))} · 대여 구분을 선택해 주세요.</p>${isAdmin()?'<div class="field"><label for="cartRentalType">대여 대상</label><select id="cartRentalType"><option value="internal">내부 · 관리자 대여</option><option value="team">기존 팀 대여</option><option value="external">외부팀 대여</option></select></div>':''}${isAdmin()?`<div class="field hidden" id="cartTargetTeamField"><label for="cartTargetTeam">기존 팀 선택</label><select id="cartTargetTeam"><option value="">작품 · 팀을 선택해 주세요</option>${teamList.filter(t=>t.active!==false&&projects.some(p=>p.id===t.projectId&&p.active!==false)).map(t=>`<option value="${esc(t.id)}">${esc(loanTeamLabel({teamId:t.id,team:t.name,projectId:t.projectId},teamList,projects))}</option>`).join('')}</select><p class="meta">선택한 팀의 대여 기록에 등록됩니다. 등록 담당자는 관리자로 남습니다.</p></div>`:''}<div class="field" id="cartGroupField"><label for="cartEquipmentGroup">장비 구분</label><select id="cartEquipmentGroup">${LOAN_GROUPS.map(g=>`<option ${g==='추가장비'?'selected':''}>${g}</option>`).join('')}</select></div>${isAdmin()?'<div id="cartExternalFields" class="hidden"><p class="meta">외부팀은 가입할 필요가 없습니다. 팀명 또는 담당자 중 하나 이상 입력해 주세요.</p><div class="field"><label for="cartExternalTeam">외부팀명</label><input id="cartExternalTeam" maxlength="100" placeholder="예: 언내추럴 외부팀"></div><div class="field"><label for="cartExternalPerson">외부 담당자</label><input id="cartExternalPerson" maxlength="80" placeholder="예: 김광민 기사님"></div></div>':''}</div>`;
}
function updateLoanClassificationFields(){
 const external=$('cartRentalType')?.value==='external';
 show('cartExternalFields',external);show('cartGroupField',!external);show('cartTargetTeamField',$('cartRentalType')?.value==='team');
}
function editLoanClassification(id){
 if(!isAdmin())return;
 const loan=loans.find(l=>l.id===id);if(!loan)return;
 const canExternal=loan.ownerUid===ADMIN_UID&&(loan.teamId||'admin')==='admin';
 modal('대여 분류 · 대여처 수정',`<form id="loanClassificationForm"><p><b>${esc(loan.equipmentName)}</b> · ${loanQuantityText(loan.quantity,loan)}</p><p class="meta">${esc(loanTeamLabel(loan,teamList,projects))} · ${esc(loan.person||'담당자 미입력')}<br>기존 비고: ${esc(loan.note||'없음')}<br>재고·수량·대여일·반납 상태는 변경되지 않습니다.</p>${canExternal?'<div class="field"><label for="editRentalType">대여 대상</label><select id="editRentalType"><option value="internal">내부 · 관리자 대여</option><option value="external">외부팀 대여</option></select></div>':''}<div class="field" id="editGroupField"><label for="editEquipmentGroup">장비 구분</label><select id="editEquipmentGroup">${LOAN_GROUPS.map(g=>`<option ${g===loan.equipmentGroup?'selected':''}>${g}</option>`).join('')}</select></div>${canExternal?`<div id="editExternalFields" class="hidden"><div class="field"><label for="editExternalTeam">외부팀명</label><input id="editExternalTeam" maxlength="100" value="${esc(loan.externalTeam||'')}" placeholder="팀명 또는 담당자 중 하나 이상 입력"></div><div class="field"><label for="editExternalPerson">외부 담당자</label><input id="editExternalPerson" maxlength="80" value="${esc(loan.externalPerson||'')}"></div></div>`:''}<button type="submit">분류·대여처 저장</button></form>`);
 if(!LOAN_GROUPS.includes(loan.equipmentGroup))$('editEquipmentGroup').value='추가장비';
 if(canExternal){$('editRentalType').value=loan.rentalType==='external'?'external':'internal';const refresh=()=>{const external=$('editRentalType').value==='external';show('editExternalFields',external);show('editGroupField',!external);};$('editRentalType').onchange=refresh;refresh();}
 const form=$('loanClassificationForm');
 form.onsubmit=async event=>{
  event.preventDefault();if(form.dataset.saving)return;
  try{
   const classification=loanMetadata({rentalType:$('editRentalType')?.value||'internal',equipmentGroup:$('editEquipmentGroup').value,externalTeam:$('editExternalTeam')?.value||'',externalPerson:$('editExternalPerson')?.value||''},true);
   form.dataset.saving='true';form.querySelectorAll('input,select,button').forEach(el=>el.disabled=true);
   await updateDoc(loanDoc(id),{...classification,updatedAt:serverTimestamp()});
   if($('loanClassificationForm')===form)closeModal();
  }catch(err){alert('대여 분류 저장 실패: '+err.message);}finally{delete form.dataset.saving;form.querySelectorAll('input,select,button').forEach(el=>el.disabled=false);}
 };
}

function addLoan(old={}){
 if(cartSubmitting)return;
 if(old.id)return alert("기존 대여 기록은 수정할 수 없습니다. 반납 후 다시 대여해 주세요.");
 cartItems={};cartCategory="전체";cartSearch="";cartStep=1;
 if(old.equipmentId)cartItems[old.equipmentId]=1;
 const name=isAdmin()?"관리자":(member?.displayName||teamName);
 modal("빠른 일괄 대여",equipment.length?`<div class="loan-progress" aria-label="대여 등록 단계"><span id="loanStepOne" class="current">1 · 장비 선택</span><span aria-hidden="true">›</span><span id="loanStepTwo">2 · 날짜 / 확인</span></div>
 <section id="loanSelectStep" class="loan-step" aria-label="장비 선택"><div class="loan-controls"><p class="meta">${esc(loanTeamLabel({team:teamName,teamId},teamList,projects))} · 대여자 ${esc(name)} · 최대 20종 선택</p><div class="search-field"><div class="search search-editor" id="cartSearch" contenteditable="plaintext-only" role="searchbox" aria-label="대여할 장비 검색" aria-multiline="false" data-placeholder="장비명 / 모델 / 분류 검색" spellcheck="false" autocapitalize="off" autocorrect="off" inputmode="search" enterkeyhint="search"></div><button type="button" class="search-submit" data-search-submit="cartSearch" aria-label="검색 실행" title="검색"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5"></circle><path d="m15.5 15.5 4.5 4.5"></path></svg></button></div><div id="cartCategories" class="cart-filter"></div></div><div id="cartEquipmentList"></div></section>
 <section id="loanDetailsStep" class="loan-step hidden" aria-label="날짜 및 선택 장비 확인"><h3 class="loan-section-title" id="loanDetailsTitle" tabindex="-1">대여 기간을 확인해 주세요</h3><p class="meta">선택 기간에 겹치는 예약·대여를 확인합니다. 반납일 당일도 사용 기간에 포함됩니다.</p><div id="loanPeriodNotice" class="notice warning hidden" role="alert"></div>${loanClassificationFields()}<div class="loan-date-fields">${field("대여일","cartDate","","date",today(),true)}<div class="loan-shortcuts"><button type="button" class="small secondary" id="loanToday">오늘 출고</button></div>${field("반납 예정일","cartDue","","date",today(),true)}<div class="loan-shortcuts" aria-label="반납 예정일 빠른 선택"><button type="button" class="small secondary" data-loan-days="0">당일</button><button type="button" class="small secondary" data-loan-days="1">다음 날</button><button type="button" class="small secondary" data-loan-days="7">7일 후</button></div></div><div class="field"><label for="cartNote">비고 <span class="muted">(선택)</span></label><input id="cartNote" placeholder="촬영 현장 / 참고 사항"></div><h3 class="loan-section-title">선택 장비</h3><div id="loanReviewList"></div></section>
 <footer class="loan-footer"><div id="cartSummary" role="status" aria-live="polite"></div><div class="loan-footer-actions"><button type="button" id="cartBack" class="secondary hidden">장비 수정</button><button type="button" id="cartNext">날짜 선택으로 →</button><button type="button" id="cartSubmit" class="hidden">대여 완료</button></div></footer>`:'<div class="empty">관리자가 장비를 먼저 등록해 주세요.</div>');
 if(!equipment.length)return;
 $('modalBack').classList.add('loan-backdrop');
 $('modalBack').querySelector('.modal').classList.add('loan-modal');
 bindSearchInput($("cartSearch"),value=>{cartSearch=value.toLowerCase();renderCart()});
 $("cartDue").min=$("cartDate").value;
 $("cartDate").onchange=()=>{const start=$("cartDate").value;$("cartDue").min=start;if(!$("cartDue").value||$("cartDue").value<start)$("cartDue").value=start;refreshLoanPeriod();};
 $("cartDue").onchange=refreshLoanPeriod;
 $('loanToday').onclick=()=>{$('cartDate').value=today();$('cartDate').onchange();};
 document.querySelectorAll('[data-loan-days]').forEach(button=>button.onclick=()=>{
  const start=$('cartDate').value;if(!start)return alert('대여일을 먼저 선택해 주세요.');
  $('cartDue').value=loanDateAfter(start,Number(button.dataset.loanDays));refreshLoanPeriod();
 });
 $('cartNext').onclick=()=>setLoanStep(2);
 $('cartBack').onclick=()=>setLoanStep(1);
 $("cartSubmit").onclick=submitCart;
 $("cartRentalType")?.addEventListener("change",updateLoanClassificationFields);
 updateLoanClassificationFields();
 renderCart();
}
function loanDateAfter(start,days){
 const [year,month,day]=start.split('-').map(Number),d=new Date(year,month-1,day+days);
 return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function setLoanStep(step){
 const chosen=Object.entries(cartItems).filter(([,n])=>n>0);
 if(step===2&&(!chosen.length||chosen.length>20))return alert('장비를 1종 이상, 최대 20종까지 선택해 주세요.');
 cartStep=step;
 show('loanSelectStep',step===1);show('loanDetailsStep',step===2);
 show('cartNext',step===1);show('cartBack',step===2);show('cartSubmit',step===2);
 $('loanStepOne').classList.toggle('current',step===1);$('loanStepTwo').classList.toggle('current',step===2);
 if(step===2)refreshLoanPeriod();
 if(step===2)$('loanDetailsTitle').focus({preventScroll:true});
 else $('cartSearch').focus({preventScroll:true});
}
function renderCart(quantitiesOnly=false){
 if(!quantitiesOnly){
 const cats=["전체",...new Set(equipment.map(x=>x.category||"미분류"))];
 $("cartCategories").innerHTML=cats.map(c=>`<button type="button" class="secondary ${cartCategory===c?'selected':''}" data-cart-cat="${esc(c)}">${esc(c)}</button>`).join("");
 const filtered=equipment.filter(x=>(cartCategory==="전체"||(x.category||"미분류")===cartCategory)&&matchesEquipmentSearch(x,cartSearch));
 $("cartEquipmentList").innerHTML=filtered.length?filtered.map(x=>`<div class="cart-row" data-cart-row="${esc(x.id)}"><div style="flex:1;min-width:0">${equipmentImageLabel(x.id,`<b>${esc(x.name)}</b><span class="meta">${esc(x.category||"미분류")} · ${unitHint(x)} · 현재 창고 ${untracked(x.id)?`수량 미확정 · 대여 ${quantityText(borrowedQtyFor(x.id),x)}`:`가용 ${quantityText(availableQtyFor(x.id),x)}`}</span>${reservationBadge(x)}`)}</div><div class="qty-control"><button type="button" class="secondary" data-cart-minus="${esc(x.id)}" aria-label="${esc(x.name)} 수량 줄이기" ${(cartItems[x.id]||0)===0?'disabled':''}>−</button><strong>${cartItems[x.id]||0}</strong><small class="qty-unit">${unitSnapshot(x).unit}</small><button type="button" class="secondary" data-cart-plus="${esc(x.id)}" aria-label="${esc(x.name)} 수량 늘리기" ${!untracked(x.id)&&availableQtyFor(x.id)<=(cartItems[x.id]||0)?'disabled':''}>＋</button></div></div>`).join(""):'<div class="empty">검색 결과가 없습니다.</div>';
 }else{
  document.querySelectorAll('[data-cart-row]').forEach(row=>{
   const id=row.dataset.cartRow,count=cartItems[id]||0;
   row.querySelector('strong').textContent=String(count);
   row.querySelector('[data-cart-minus]').disabled=count===0;
   row.querySelector('[data-cart-plus]').disabled=!untracked(id)&&availableQtyFor(id)<=count;
  });
 }
 if(!isAdmin()&&teamList.some(t=>t.id===teamId&&t.active===false))return alert("종료된 팀은 대여할 수 없습니다.");const chosen=Object.entries(cartItems).filter(([,n])=>n>0),total=chosen.reduce((s,[,n])=>s+n,0);
 $("cartSummary").innerHTML=`<span class="cart-count">${chosen.length}종 · ${sumUnitQuantities(chosen.map(([id,quantity])=>({...equipment.find(e=>e.id===id),quantity})))} 선택</span>`;
 $('loanReviewList').innerHTML=chosen.map(([id,n])=>`<div class="loan-review-row"><span>${equipmentImageLabel(id,esc(equipment.find(x=>x.id===id)?.name||'장비'),'review')}</span><strong>${quantityText(n,equipment.find(e=>e.id===id))}</strong></div>`).join('');
 refreshLoanPeriod();
 $('cartNext').disabled=!chosen.length;
}
async function submitCart(){
 if(cartSubmitting)return;
 if(!isAdmin()&&teamList.some(t=>t.id===teamId&&t.active===false))return alert("종료된 팀은 대여할 수 없습니다.");
 const chosen=Object.entries(cartItems).filter(([,n])=>n>0),loanDate=$("cartDate").value,dueDate=$("cartDue").value,note=$("cartNote").value.trim();
 if(!chosen.length||!loanDate||!dueDate||dueDate<loanDate)return alert("장비 수량과 날짜를 확인해 주세요.");
 if(chosen.length>20)return alert("한 번에 최대 20종까지 대여할 수 있어요. 나누어 등록해 주세요.");
 const periodErrors=chosen.flatMap(([id,n])=>{const eq=equipment.find(e=>e.id===id),result=cartPeriodResult(eq);return n>result.free?[capacityFailure(eq,result,n,loanDate,dueDate)]:[];});if(periodErrors.length)return alert("선택 기간의 가용 수량이 부족합니다.\n"+periodErrors.join("\n"));
 let classification,destination;
 const mode=$("cartRentalType")?.value||"internal";
 try{destination=loanDestination({admin:isAdmin(),mode,targetTeamId:$("cartTargetTeam")?.value,currentTeamId:teamId,teamName,teams:teamList,projects});classification=loanMetadata({rentalType:mode==="external"?"external":"internal",equipmentGroup:$("cartEquipmentGroup")?.value||"추가장비",externalTeam:$("cartExternalTeam")?.value||"",externalPerson:$("cartExternalPerson")?.value||""},isAdmin());}catch(e){return alert(e.message);}
 const btn=$("cartSubmit"),controls=[...document.querySelectorAll('#modalRoot button,#modalRoot input,#modalRoot textarea,#modalRoot select')].map(el=>({el,disabled:el.disabled}));
 cartSubmitting=true;controls.forEach(({el})=>el.disabled=true);btn.textContent="재고 확인 및 대여 처리 중...";
 const items=chosen.map(([equipmentId,quantity])=>({...unitSnapshot(equipment.find(e=>e.id===equipmentId)),equipmentId,quantity,loanId:cartLoanRefs[equipmentId]||(cartLoanRefs[equipmentId]=doc(loanCol()).id)}));
 const payload={...classification,...destination,ownerUid:currentUser.uid,person:isAdmin()?"관리자":(member?.displayName||teamName),loanDate,dueDate,note};
 let completed=0;
 try{
  await submitBulkLoans({runTransaction,doc,serverTimestamp,capacity:typeof checkedCapacityApi==='function'?checkedCapacityApi():null,today:today()},db,items,payload,(chunk,count,total)=>{
   completed=count;for(const item of chunk){delete cartItems[item.equipmentId];delete cartLoanRefs[item.equipmentId];}
   btn.textContent=`대여 저장 중 · ${count}/${total}종`;
  });
  cartSubmitting=false;closeModal();alert(`${chosen.length}종 ${sumUnitQuantities(chosen.map(([id,quantity])=>({...equipment.find(e=>e.id===id),quantity})))} 대여가 완료됐습니다.`);
 }catch(e){
  cartSubmitting=false;controls.forEach(({el,disabled})=>el.disabled=disabled);
  if(completed)renderCart();
  btn.disabled=false;btn.textContent=completed?"남은 장비 대여 재시도":"대여 다시 시도";
  alert((completed?`${completed}종은 대여 완료됐습니다. 남은 ${chosen.length-completed}종만 다시 시도해 주세요.\n`:"일괄 대여 실패: ")+e.message);
 }finally{cartSubmitting=false;}
}
function showEquipmentDetail(id){
 const e=equipment.find(x=>x.id===id);if(!e)return;
 const active=activeLoans().filter(l=>l.equipmentId===id),reports=breakdownReports.filter(r=>r.equipmentId===id).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));
 const rows=active.map(l=>`<div class="item"><div style="min-width:0;flex:1"><b>${esc(l.rentalType==='external'?'외부팀 · '+loanParty(l):loanTeamLabel(l,teamList,projects))} · ${loanQuantityText(l.quantity,l)}</b><div class="meta">${esc(l.person||'담당자 미입력')} · 반납 예정 ${esc(l.dueDate||'미정')}${damageEa(l)>0?`<br>고장 신고 ${damageEa(l)+'EA'} 포함`:''}</div></div>${canReportDamage(l)&&damageEa(l)<loanEa(l)?`<button class="small danger" data-report-damage-loan="${esc(l.id)}">고장 신고</button>`:''}</div>`).join('');
 const states={reported:'고장 중',repairing:'수리 중',completed:'수리 완료',cancelled:'신고 취소'};
 const reportRows=reports.map(r=>{
  const loan=loans.find(l=>l.id===r.loanId),returned=loan?.status==='returned',open=['reported','repairing'].includes(r.status),canCancel=open&&(isAdmin()||r.reporterUid===currentUser?.uid);
  const manager=isAdmin()?(r.status==='reported'?(returned?`<button class="small" data-damage-transition="repairing" data-damage-id="${esc(r.id)}">수리 접수</button>`:'<span class="meta">장비 반납 후 수리 접수할 수 있습니다.</span>'):r.status==='repairing'?`<button class="small" data-damage-transition="completed" data-damage-id="${esc(r.id)}">수리 완료</button>`:''):'';
  const cancel=canCancel?`<button class="small secondary" data-damage-transition="cancelled" data-damage-id="${esc(r.id)}">고장 신고 취소</button>`:'';
  return `<div class="maintenance-report"><div class="row"><b>${reportEa(r)+'EA'} · ${esc(r.teamName||'팀 미입력')}</b><span class="pill ${r.status==='reported'?'red':r.status==='repairing'?'amber':'green'}">${states[r.status]||esc(r.status)}</span></div><p class="meta">${esc(r.symptom)}<br>신고자 ${esc(r.reporterName||'직원')}${r.status==='reported'?` · ${returned?'입고 완료 · 수리 접수 대기':'현장 보관 · 반납 대기'}`:''}</p>${manager||cancel?`<div class="row">${manager}${cancel}</div>`:''}</div>`;
 }).join('');
 modal(`${esc(e.name)} 상세`,`<div class="row" style="margin-bottom:14px">${typeof equipmentPhotos!=="undefined"?equipmentPhotos.thumbnail(id):""}${isAdmin()?`<button class="small secondary" data-equipment-photo="${esc(id)}">사진 등록 · 변경</button>`:""}</div><div class="maintenance-stats">${[['전체',Number(e.total||0)],['가용',untracked(id)?'미확정':Math.max(0,availableQtyFor(id))],['대여',borrowedQtyFor(id)],['수리 중',repairQtyFor(id)],['고장 중',brokenQtyFor(id)]].map(([name,n])=>`<div class="stat"><div class="k">${name}</div><div class="v">${typeof n==='number'?(['수리 중','고장 중'].includes(name)?n+'EA':quantityText(n,e)):n}</div></div>`).join('')}</div><p class="meta">${unitHint(e)}${stockRemainderText(e)} · 고장·수리는 EA로 관리합니다. 현장 고장은 대여 수량에 포함됩니다. 반납된 고장 장비는 정상 재고로 풀리지 않습니다.</p><div class="panel"><div class="panelhead"><h2>장비 정보</h2>${isAdmin()?`<button class="small secondary" data-edit-equipment="${esc(id)}">장비 수정</button>`:''}</div><div class="meta">분류: ${esc(e.category||'미분류')}<br>모델 / 규격: ${esc(e.model||'미입력')}<br>비고: ${esc(e.note||'없음')}</div>${isAdmin()?`<div class="modalbuttons"><button type="button" data-repair-quantity="${esc(id)}">수리 수량 지정 · 현재 ${repairQtyFor(id)+'EA'}</button></div>`:''}</div>${reservationBadge(e)}<div class="panel"><div class="panelhead"><h2>팀별 대여 · 고장 신고</h2><button class="small" data-loan-equipment="${esc(id)}">+ 대여 등록</button></div><div class="list">${rows||'<div class="empty">현재 대여 중인 팀이 없습니다.</div>'}</div></div><div class="panel"><div class="panelhead"><h2>고장 · 수리 처리 내역</h2></div>${reportRows||'<div class="empty">고장 신고 내역이 없습니다.</div>'}</div>`);
 $('modalBack').dataset.equipmentDetail=id;
}
function addRepair(equipmentId,old={}){alert("V7에서는 재고 정확성을 위해 수리 등록을 일시 제한했습니다. 후속 버전에서 트랜잭션 방식으로 복구합니다.");return;const eq=equipment.find(e=>e.id===equipmentId);if(!eq)return;modal(old.id?`${esc(eq.name)} 수리 기록 수정`:`${esc(eq.name)} 수리 등록`, `<form id="repairForm"><div class="formgrid">${field("수리 수량","repairQty","수량","number",old.quantity??1,true)}${field("수리 날짜","repairDate","","date",old.repairDate||today(),true)}${field("수리 업체","repairVendor","예: 업체명","text",old.vendor||"")}<div class="field"><label>수리 상태</label><select id="repairStatus"><option value="active" ${old.status!=="completed"?"selected":""}>수리 중</option><option value="completed" ${old.status==="completed"?"selected":""}>수리 완료</option></select></div><div class="field wide"><label>고장 증상 *</label><textarea id="repairSymptom" rows="2" required placeholder="예: 전원 불량, 깜빡임">${esc(old.symptom||"")}</textarea></div><div class="field wide"><label>메모</label><textarea id="repairNote" rows="2" placeholder="접수 번호, 수리 내용 등">${esc(old.note||"")}</textarea></div></div><div class="notice">수리 중인 수량은 사용 가능 수량에서 자동으로 제외됩니다. 완료 처리하면 다시 사용 가능 수량에 포함됩니다.</div><div class="modalbuttons"><button type="submit">저장</button></div></form>`);$("repairForm").onsubmit=async ev=>{ev.preventDefault();const qty=Number($("repairQty").value),statusValue=$("repairStatus").value==="completed"?"completed":"active";if(!Number.isInteger(qty)||qty<1)return alert("수리 수량은 1 이상의 정수로 입력해 주세요.");const currentRepairing=repairQtyFor(equipmentId)-(old.id&&old.status!=="completed"?Number(old.quantity||1):0);const availableForRepair=Number(eq.total||0)-borrowedQtyFor(equipmentId)-currentRepairing;if(statusValue!=="completed"&&qty>availableForRepair)return alert(`현재 수리 등록 가능한 수량은 ${Math.max(0,availableForRepair)}개입니다. 대여 중인 수량과 다른 수리 중 수량을 확인해 주세요.`);const data={equipmentId,equipmentName:eq.name,quantity:qty,repairDate:$("repairDate").value,vendor:$("repairVendor").value.trim(),symptom:$("repairSymptom").value.trim(),note:$("repairNote").value.trim(),status:statusValue,updatedAt:serverTimestamp()};if(!data.repairDate||!data.symptom)return alert("수리 날짜와 고장 증상을 입력해 주세요.");try{if(old.id){await updateDoc(repairDoc(old.id),data);repairs=repairs.map(r=>r.id===old.id?{...r,...data}:r)}else{const ref=await addDoc(repairCol(),{...data,createdAt:serverTimestamp()});repairs.push({id:ref.id,...data})}showEquipmentDetail(equipmentId)}catch(err){alert("수리 기록 저장 실패: "+err.message)}}}
let bulkReturnSubmitting=false;
function bulkReturnDialog(){
 if(!activeLoans().filter(canHandleLoan).length)return alert("반납할 대여 기록이 없습니다.");
 const selected=new Set(),folds=new Map();let searching=false;
 modal("일괄 반납",`<p class="meta">팀을 펼친 뒤 상주장비 · 세트장비 · 추가장비별로 선택하세요.</p><div class="notice">선택한 기록은 전량 반납됩니다. 한 번에 최대 5건, 같은 장비는 1건씩 선택할 수 있어요.</div><input class="search" id="bulkReturnSearch" placeholder="장비명 / 작품 · 팀 / 담당자 / 구분 검색" aria-label="반납 기록 검색"><div class="return-tools"><label><input type="checkbox" id="bulkReturnAll"> 검색 결과 선택</label><button type="button" class="small secondary" id="bulkReturnClear">선택 해제</button></div><p id="bulkReturnNotice" class="meta" role="status" aria-live="polite"></p><div id="bulkReturnRows" class="return-scroll"></div><footer class="return-footer"><strong id="bulkReturnCount" aria-live="polite"></strong><button id="bulkReturnSubmit">선택한 기록 반납</button></footer>`);
 $('modalBack').querySelector('.modal').classList.add('return-modal');
 const eligible=()=>activeLoans().filter(canHandleLoan);
 let filtered=[];
 const sync=()=>{
  const valid=new Set(eligible().map(l=>l.id));for(const id of selected)if(!valid.has(id))selected.delete(id);
  document.querySelectorAll('#bulkReturnRows .bulk-return-check').forEach(c=>c.checked=selected.has(c.value));
  const all=$('bulkReturnAll'),n=filtered.filter(l=>selected.has(l.id)).length;all.checked=filtered.length>0&&n===filtered.length;all.indeterminate=n>0&&n<filtered.length;
  $('bulkReturnCount').textContent=`선택 ${selected.size} / 5건`;$('bulkReturnSubmit').disabled=!selected.size||bulkReturnSubmitting;
 };
 const pick=(rows,on)=>{
  let limited=false,duplicate=false;const byId=new Map(eligible().map(l=>[l.id,l]));
  for(const l of rows){if(!on){selected.delete(l.id);continue}if(selected.has(l.id))continue;if([...selected].some(id=>byId.get(id)?.equipmentId===l.equipmentId)){duplicate=true;continue}if(selected.size>=5){limited=true;continue}selected.add(l.id)}
  $('bulkReturnNotice').textContent=[limited?'최대 5건까지 선택했어요. 나머지는 다음 반납에서 처리해 주세요.':'',duplicate?'같은 장비의 다른 대여 건은 나누어 반납해 주세요.':''].filter(Boolean).join(' ');sync();
 };
 const renderRows=()=>{
  const target=$('bulkReturnRows');if(!target)return;
  if(!searching)target.querySelectorAll('details[data-return-fold]').forEach(el=>folds.set(el.dataset.returnFold,el.open));
  const q=$('bulkReturnSearch').value.toLocaleLowerCase().trim();searching=!!q;filtered=eligible().filter(l=>loanSearchText(l,teamList,projects).includes(q));
  const row=l=>`<label class="return-row"><input type="checkbox" class="bulk-return-check" value="${esc(l.id)}" ${selected.has(l.id)?'checked':''}><span>${equipmentImageLabel(l.equipmentId,`<b>${esc(l.equipmentName||'삭제된 장비')}</b><small>${esc(loanParty(l)||'담당자 미입력')} · ${esc(l.loanDate||'')} 출고${l.unit==='BOX'?' · 총 '+loanEa(l)+'EA':''}</small>`)}</span><strong>${Number(l.quantity||0)}<small>${unitSnapshot(l).unit}</small></strong></label>`;
  const fold=(id,label,rows,body)=>`<details class="loan-fold" data-return-fold="${esc(id)}" ${searching||folds.get(id)?'open':''}><summary><span class="loan-fold-heading"><strong>${esc(label)}</strong></span><span class="loan-fold-count">${rows.length}건 · ${sumUnitQuantities(rows)}</span></summary><div class="loan-fold-body">${body}</div></details>`;
  target.innerHTML=groupLoans(filtered,ADMIN_UID,teamList,projects).map(g=>fold(g.id,g.label,g.rows,g.sections.map(c=>fold(c.id,c.label,c.rows,c.parties.length?c.parties.map(p=>fold(p.id,p.label,p.rows,p.rows.map(row).join(''))).join(''):c.rows.map(row).join(''))).join(''))).join('')||'<div class="empty">반납할 기록이 없습니다.</div>';sync();
 };
 $('bulkReturnRows').onchange=e=>{if(!e.target.matches('.bulk-return-check'))return;const l=eligible().find(l=>l.id===e.target.value);if(l)pick([l],e.target.checked)};
 $('bulkReturnSearch').oninput=renderRows;
 $('bulkReturnAll').onchange=e=>pick(filtered,e.target.checked);
 $('bulkReturnClear').onclick=()=>{selected.clear();$('bulkReturnNotice').textContent='';sync()};
 $('modalBack').refreshReturns=renderRows;
 $('bulkReturnSubmit').onclick=async()=>{
  if(bulkReturnSubmitting)return;sync();const ids=[...selected];if(!ids.length)return alert('반납할 기록을 선택해 주세요.');
  if(!confirm(`${ids.length}건을 모두 전량 반납할까요?`))return;
  bulkReturnSubmitting=true;sync();
  try{await returnLoans(ids);bulkReturnSubmitting=false;closeModal();alert(`${ids.length}건 일괄 반납 완료`)}catch(e){bulkReturnSubmitting=false;sync();alert('일괄 반납 실패: '+e.message)}
 };
 renderRows();
}
async function returnLoans(ids){
 const unique=[...new Set(ids)];if(!unique.length||unique.length>5)throw Error("한 번에 1~5건을 선택해 주세요.");
 await runTransaction(db,async tx=>{
  const rows=[];for(const id of unique){const ref=loanDoc(id),snap=await tx.get(ref);if(!snap.exists()||snap.data().status!=="active")throw Error("이미 반납된 기록이 있습니다.");const l={id,...snap.data()};if(!canHandleLoan(l))throw Error("다른 팀 기록은 반납할 수 없습니다.");rows.push({ref,l})}
  // Each equipment document can carry only one lastLoanId per transaction.
  const eqIds=rows.map(x=>x.l.equipmentId);if(new Set(eqIds).size!==eqIds.length)throw Error("동일 장비의 여러 대여 건은 한 번에 반납할 수 없습니다. 각각 나누어 처리해 주세요.");
  const eqs=[];for(const row of rows){const ref=eqDoc(row.l.equipmentId),snap=await tx.get(ref);if(!snap.exists())throw Error("삭제된 장비가 있습니다.");if(Number(snap.data().loaned||0)<Number(row.l.quantity))throw Error("대여 수량이 일치하지 않습니다.");eqs.push({ref,snap,row})}
  for(const {ref,snap,row} of eqs){tx.update(ref,maintenanceReturnFields(snap.data(),row.l,row.l.id));tx.update(row.ref,{status:"returned",returnedAt:serverTimestamp(),updatedAt:serverTimestamp()})}
 });
}
async function bulkDeleteReturnedLoansAdmin(){
 if(!isAdmin())throw Error("관리자만 일괄삭제할 수 있습니다.");
 const targets=loans.filter(l=>l.status==="returned"&&damageEa(l)===0);
 if(!targets.length)return alert("삭제할 반납 완료 기록이 없습니다.");
 const count=targets.length;
 if(!confirm(`반납 완료된 대여 기록 ${count}건을 전부 영구 삭제할까요?\n\n대여 중 기록은 삭제되지 않으며 재고 수량도 변경되지 않습니다.\n삭제한 기록은 복구할 수 없습니다. 먼저 JSON 백업을 권장합니다.`))return;
 const phrase=prompt(`${count}건의 반납 완료 기록을 삭제합니다.\n계속하려면 '삭제'를 입력하세요.`);
 if(phrase!=="삭제")return;
 // Limit each Firestore write batch to 400 operations (under the 500 limit).
 // The Firestore rule independently rejects deleting non-returned records.
 let removed=0;
 for(let i=0;i<targets.length;i+=400){
  const batch=writeBatch(db);
  const part=targets.slice(i,i+400);
  part.forEach(l=>batch.delete(loanDoc(l.id)));
  try{await batch.commit();removed+=part.length;}
  catch(e){alert(`${removed}건 삭제 후 오류가 발생했습니다.\n${e.message}\n남은 기록은 다시 확인해 주세요.`);return;}
 }
 alert(`반납 완료 기록 ${removed}건을 삭제했습니다.`);
}
async function deleteReturnedLoanAdmin(id){
 if(!isAdmin())throw Error("관리자만 대여 기록을 삭제할 수 있습니다.");
 const item=loans.find(l=>l.id===id);
 if(item&&damageEa(item)>0)throw Error("고장·수리 처리를 완료한 뒤 기록을 삭제해 주세요.");
 if(!item||item.status!=="returned")throw Error("반납 완료 기록만 삭제할 수 있습니다. 대여 중 기록은 먼저 반납 처리하세요.");
 if(!confirm(`${item.equipmentName||"장비"} · ${item.team||"팀 미지정"}의 반납 완료 대여 기록을 영구 삭제할까요?\\n삭제 후 복구할 수 없습니다. 장비 재고는 변경되지 않습니다.`))return;
 const ref=loanDoc(id);
 await runTransaction(db,async tx=>{
  const snap=await tx.get(ref);
  if(!snap.exists()||snap.data().status!=="returned")throw Error("반납 완료 기록만 삭제할 수 있습니다.");
  tx.delete(ref);
 });
}
async function returnLoan(l){
 if(!canHandleLoan(l))throw Error("다른 팀의 대여를 반납할 수 없습니다.");
 await runTransaction(db,async tx=>{const loanRef=loanDoc(l.id),snap=await tx.get(loanRef);if(!snap.exists()||snap.data().status!=="active")throw Error("이미 반납되었거나 기록이 없습니다.");const loan=snap.data(),eqRef=eqDoc(loan.equipmentId),eqSnap=await tx.get(eqRef);if(!eqSnap.exists())throw Error("장비가 없습니다.");
  tx.update(eqRef,maintenanceReturnFields(eqSnap.data(),loan,l.id));tx.update(loanRef,{status:"returned",returnedAt:serverTimestamp(),updatedAt:serverTimestamp()});
 });
}
let signupSubmitting=false;
async function signup(){
 if(signupSubmitting)return;
 // Read the actual field value on submission; never force IME blur/commit.
 const username=$("signupEmail").value.trim().toLowerCase(),email=accountEmail(username),password=$("signupPassword").value,name=$("signupName").textContent.trim(),requestedTeam=$("signupTeam").value.trim();
 if(!/^[a-z0-9][a-z0-9._-]{3,19}$/.test(username))return alert("아이디는 영문 소문자, 숫자, 점, 밑줄, 하이픈을 사용해 4~20자로 입력해 주세요.");
 if(password.length<8||!name)return alert("8자리 이상 비밀번호와 이름을 입력해 주세요.");
 if(name.length>80||requestedTeam.length>100)return alert("이름은 80자, 희망 소속 팀은 100자 이내로 입력해 주세요.");
 signupSubmitting=true;$("signupBtn").disabled=true;
 try{
  const state=await submitSignup({createUserWithEmailAndPassword,signInWithEmailAndPassword,doc,runTransaction,serverTimestamp},auth,db,{email,username,password,name,requestedTeam});
  alert(state==="approved"?"이미 승인된 계정입니다. 로그인해서 이용해 주세요.":state==="rejected"?"가입 신청이 거절된 계정입니다. 관리자에게 문의해 주세요.":"가입 신청 완료! 관리자 승인을 기다려 주세요. 승인 후 다시 로그인하면 이용할 수 있습니다.");
 }catch(e){
  const credentialError=["auth/invalid-credential","auth/wrong-password","auth/invalid-login-credentials"].includes(e.code);
  alert(credentialError?"이미 생성된 아이디입니다. 처음 가입할 때 입력한 비밀번호로 다시 신청해 주세요.":"가입 신청 저장 실패: "+e.message+"\n같은 아이디와 비밀번호로 다시 신청할 수 있습니다.");
 }finally{signupSubmitting=false;$("signupBtn").disabled=false;}
}

function projectArchiveHTML(p){
 const history=loans.filter(l=>l.projectId===p.id);
 const groups=new Map();
 for(const l of history){const key=l.teamId||('legacy:'+String(l.team||'미확인 팀'));if(!groups.has(key))groups.set(key,{name:l.team||'미확인 팀',records:[]});groups.get(key).records.push(l)}
 const contents=[...groups.values()].map(g=>`<div class="archive-team"><b>${esc(g.name)}</b><div class="meta">대여 ${g.records.length}건</div>${g.records.map(l=>`<div class="archive-loan"><div><b>${esc(l.equipmentName||'이름 없는 장비')}</b><div class="meta">${esc(l.person||'담당자 미기록')} · 대여 ${esc(l.loanDate||'미기록')} · 반납 예정 ${esc(l.dueDate||'미기록')}</div><div class="meta">${l.status==='returned'?'반납 완료':'미반납'}</div></div><strong>${loanQuantityText(l.quantity,l)}</strong></div>`).join('')}</div>`).join('');
 return `<details class="project-archive"><summary><span><b>${esc(p.name)}</b><span class="meta">대여 ${history.length}건 · ${sumUnitQuantities(history)}</span></span><span class="pill green">종료 · 이력 보기</span></summary><div class="archive-content"><div class="archive-delete">${adminDeleteButton("delete_project",p.id,p.name)}</div>${contents||'<div class="empty">이 작품으로 저장된 대여 기록이 없습니다.</div>'}<div class="meta">※ 구버전에서 작품 ID 없이 생성된 대여 기록은 자동 연결되지 않습니다.</div></div></details>`;
}
function memberProjectTeamLabel(m){
 const t=teamList.find(t=>t.id===m.teamId);
 const p=projects.find(p=>p.id===(t?.projectId||m.projectId));
 const name=t?.name||m.teamName||"미배정";
 return p?`${p.name} · ${name}`:name==="미배정"?name:`작품 미연결 · ${name}`;
}
function memberWorkCategory(m){
 if(m.active===false)return 'ended';
 const t=teamList.find(t=>t.id===m.teamId);
 const p=projects.find(p=>p.id===(t?.projectId||m.projectId));
 return t&&t.active!==false&&p&&p.active!==false?'assigned':'standby';
}
function renderMemberGroups(teamOptions){
 const members=membersList.filter(m=>m.role==='team');
 const groups=[
  {id:'assigned',label:'프로젝트 투입 인원',empty:'현재 진행 중인 작품에 배정된 직원이 없습니다.'},
  {id:'standby',label:'프로젝트 대기 인원',empty:'현재 대기 중인 직원이 없습니다.'},
  {id:'ended',label:'운영 종료 인원',empty:'이용 권한이 해제된 직원이 없습니다.'}
 ];
 return '<h3>직원 현황 및 팀 관리</h3><p class="muted">진행 중인 작품 배정과 계정 이용 상태에 따라 자동 분류됩니다. 프로젝트 대기 인원도 정상 로그인할 수 있습니다.</p>'+groups.map(g=>{
  const people=members.filter(m=>memberWorkCategory(m)===g.id);
  const rows=people.map(m=>`<div class="item"><div style="flex:1"><b>${esc(m.displayName||m.teamName||'이름 미등록')}</b><div class="field"><label>직원 이름 (수정 가능)</label><input id="memberName-${esc(m.id)}" value="${esc(m.displayName||'')}" placeholder="실명 입력"></div><button class="small secondary" data-save-member-name="${esc(m.id)}">이름 저장</button><div class="meta">현재: ${esc(memberProjectTeamLabel(m))}${m.active===false?' · 이용 중지':''}</div><select id="memberTeam-${esc(m.id)}"><option value="">새 팀 선택</option>${teamOptions}</select></div><button class="small secondary" data-move-member="${esc(m.id)}" ${m.active===false?'disabled':''}>배정</button><button class="small ${m.active===false?'secondary':'danger'}" data-toggle-member="${esc(m.id)}">${m.active===false?'재활성화':'이용 중지'}</button>${adminDeleteButton('delete_user',m.id,m.displayName||m.teamName||'직원')}</div>`).join('');
  return `<details class="admin-fold" data-member-fold="${g.id}"><summary>${g.label} <span class="fold-count">${people.length}명</span></summary><div class="fold-body"><div class="list">${rows||`<div class="empty">${g.empty}</div>`}</div></div></details>`;
 }).join('');
}
function projectTeamRows(p){
 const teams=teamList.filter(t=>t.projectId===p.id&&t.active!==false);
 return `<div class="project-team-list">${teams.map(t=>`<div class="project-team-row"><div><b>${esc(t.name)}</b><div class="meta">미반납 ${activeLoans().filter(l=>l.teamId===t.id).length}건</div></div><button class="small danger" data-close-team="${esc(t.id)}">팀 종료·보관</button></div>`).join('')||'<p class="meta">진행 중인 팀이 없습니다.</p>'}</div>`;
}
function teamArchiveHTML(t){
 const p=projects.find(p=>p.id===t.projectId),history=loans.filter(l=>l.teamId===t.id);
 return `<details class="project-archive"><summary><span><b>${esc(p?`${p.name} · ${t.name}`:t.name)}</b><span class="meta">대여 ${history.length}건</span></span><span class="pill green">팀 종료 · 이력</span></summary><div class="archive-content"><div class="archive-delete">${adminDeleteButton('delete_team',t.id,(p?p.name+' · ':'')+t.name)}</div>${history.map(l=>`<div class="archive-loan"><div><b>${esc(l.equipmentName||'이름 없는 장비')}</b><div class="meta">${esc(l.person||'담당자 미기록')} · ${esc(l.loanDate||'날짜 미기록')} · ${l.status==='returned'?'반납 완료':'미반납'}</div></div><strong>${loanQuantityText(l.quantity,l)}</strong></div>`).join('')||'<div class="empty">대여 기록이 없습니다.</div>'}</div></details>`;
}
let teamClosing=new Set();
async function closeTeam(id){
 if(!isAdmin())throw Error('관리자 전용입니다.');
 const t=teamList.find(t=>t.id===id);if(!t||t.active===false||teamClosing.has(id))return;
 const p=projects.find(p=>p.id===t.projectId),records=activeLoans().filter(l=>l.teamId===id);
 const booked=reservations.filter(r=>r.teamId===id&&['pending','approved'].includes(r.status)&&(!r.endDate||r.endDate>=today()));
 if(booked.length)return alert(`이 팀에 유효 예약 ${booked.length}건이 있습니다. 예약을 먼저 취소한 뒤 종료해 주세요.`);
 if(!confirm(`${p?p.name+' · ':''}${t.name} 팀만 종료·보관할까요?\n이 팀의 미반납 ${records.length}건을 자동 반납하고 재고를 복구합니다. 실제 장비 입고 여부를 먼저 확인해 주세요.\n작품과 다른 팀은 계속 진행되며, 직원 계정과 대여 기록은 유지됩니다.`))return;
 teamClosing.add(id);
 try{for(const l of records)await returnLoan(l);await updateDoc(doc(db,'teams',id),{active:false});alert('해당 팀을 종료하고 보관했습니다. 작품과 다른 팀은 계속 진행됩니다.');}
 catch(e){alert('팀 종료 중 일부 작업이 실패했습니다. 미반납 기록을 확인한 뒤 다시 시도해 주세요: '+e.message);}
 finally{teamClosing.delete(id);}
}
function renderProjects(){
 const target=$("projectsPanel");if(!target||!isAdmin())return;
 const active=projects.filter(p=>p.active!==false),closed=projects.filter(p=>p.active===false);
 const expandedFolds=[...target.querySelectorAll("details.admin-fold[open]")].map(x=>x.getAttribute("data-member-fold")||"archive");
 const teamOptions=teamList.filter(t=>t.active!==false).map(t=>{const project=projects.find(p=>p.id===t.projectId);const label=project?(project.name===t.name?`${project.name} (단일 팀)`:`${project.name} · ${t.name}`):`미연결 팀 · ${t.name}`;return `<option value="${esc(t.id)}">${esc(label)}</option>`}).join("");
 target.innerHTML=`<h2>작품 운영 · 관리자 전용</h2><p class="muted">직원 계정은 유지하고 작품과 팀 배정만 바꿉니다. 종료된 작품의 기록은 보관됩니다.</p><div class="field"><label>새 작품 이름</label><input id="newProjectName" placeholder="예: 드라마 2026"></div><button id="createProjectBtn">+ 작품 등록</button><details class="admin-fold" data-member-fold="active-projects"><summary>진행 중 작품 <span class="fold-count">${active.length}개</span></summary><div class="fold-body"><div class="list">${active.map(p=>{const ts=teamList.filter(t=>t.projectId===p.id&&t.active!==false);const count=activeLoans().filter(l=>l.projectId===p.id).length;return `<div class="item"><div style="flex:1"><b>${esc(p.name)}</b><div class="meta">소속 팀 ${ts.map(t=>esc(t.name)).join(', ')||'없음'} · 미반납 ${count}건</div>${projectTeamRows(p)}<div class="field"><label>새 팀 생성 (팀명 생략 시 작품명 사용)</label><input id="newProjectTeam-${esc(p.id)}" placeholder="비워두면 작품명으로 생성 · 예: A팀, B팀"></div><button class="small" data-create-project-team="${esc(p.id)}">+ 이 작품에 팀 추가</button><div class="field"><label>기존 팀 연결</label><select id="projectTeam-${esc(p.id)}"><option value="">대기 직원 (팀 미배정)</option>${teamOptions}</select></div><button class="small secondary" data-link-project="${esc(p.id)}">팀 연결</button></div><button class="small danger" data-close-project="${esc(p.id)}">작품 전체 종료</button></div>`}).join('')||'<div class="empty">진행 중인 작품이 없습니다.</div>'}</div></div></details><details class="admin-fold"><summary>종료된 작품 <span class="fold-count">${closed.length}개</span></summary><div class="fold-body"><div class="list">${closed.length?closed.map(p=>projectArchiveHTML(p)).join(''):'<div class="empty">없음</div>'}</div></div></details><details class="admin-fold" data-member-fold="archived-teams"><summary>종료·보관된 팀 <span class="fold-count">${teamList.filter(t=>t.active===false).length}개</span></summary><div class="fold-body">${teamList.filter(t=>t.active===false).map(teamArchiveHTML).join('')||'<div class="empty">없음</div>'}</div></details>${renderMemberGroups(teamOptions)}${adminOperationsHTML()}<div class="notice">이전 버전에서 생성된 대여 기록에는 작품 ID가 없을 수 있습니다. 그런 기록은 자동 종료 대상으로 추정하지 않으며, 먼저 직접 반납해야 합니다.</div>`;
 target.querySelectorAll("details.admin-fold").forEach(el=>{const key=el.getAttribute("data-member-fold")||"archive";if(expandedFolds.includes(key))el.open=true;});
}
async function createProjectTeam(id){
 const p=projects.find(x=>x.id===id),typedName=$("newProjectTeam-"+id)?.value.trim(),name=typedName||p?.name;
 if(!p||p.active===false||!name)return alert("진행 중 작품을 확인해 주세요.");
 if(teamList.some(t=>t.projectId===id&&t.name===name))return alert("이 작품에 같은 이름의 팀이 있습니다.");
 await addDoc(collection(db,"teams"),{name,projectId:id,active:true,createdAt:serverTimestamp()});
 alert(p.name+" · "+name+" 생성 완료. 이제 직원 소속을 배정할 수 있어요.");
}
async function saveMemberName(uid){
 if(operationPending("delete_user",uid))return alert("계정 삭제 처리 중입니다.");
 const m=membersList.find(x=>x.id===uid),name=$("memberName-"+uid)?.value.trim();
 if(!m||!name)return alert("직원 이름을 입력해 주세요.");
 if(name.length>80)return alert("이름은 80자 이내로 입력해 주세요.");
 await updateDoc(doc(db,"members",uid),{displayName:name,updatedAt:serverTimestamp()});
 alert(name+" 이름 저장 완료");
}
async function createProject(){const name=$("newProjectName")?.value.trim();if(!name)return alert("작품명을 입력하세요.");if(projects.some(p=>p.active!==false&&p.name===name))return alert("같은 이름의 진행 중 작품이 있습니다.");await addDoc(collection(db,"projects"),{name,active:true,createdAt:serverTimestamp()});}
async function linkProject(id){const team=teamList.find(t=>t.id===$("projectTeam-"+id)?.value),p=projects.find(x=>x.id===id);if(!team||!p||p.active===false)return alert("활성 팀을 선택하세요.");if(activeLoans().some(l=>l.teamId===team.id&&!l.projectId))return alert("이 팀에 이전 버전의 미반납 기록이 있습니다. 먼저 반납 처리한 뒤 작품을 연결해 주세요.");await updateDoc(doc(db,"teams",team.id),{projectId:id});alert(`${team.name}을 ${p.name}에 연결했습니다.`)}
async function toggleMember(uid){
 if(operationPending("delete_user",uid))return alert("계정 삭제 처리 중입니다.");
 if(!isAdmin())throw Error('관리자 전용입니다.');
 const m=membersList.find(x=>x.id===uid);
 if(!m||m.role!=='team')throw Error('직원 정보를 찾을 수 없습니다.');
 const next=m.active===false;
 const name=m.displayName||m.teamName||'해당 직원';
 if(!next){
  const outstanding=loans.filter(l=>l.status==='active'&&l.ownerUid===uid);
  const booked=reservations.filter(r=>['pending','approved'].includes(r.status)&&r.ownerUid===uid);
  if(outstanding.length||booked.length){
   const msg=`${name} 계정에 미반납 대여 ${outstanding.length}건, 유효 예약 ${booked.length}건이 있습니다.\n기록은 그대로 유지됩니다. 관련 건을 확인하고 계정을 해제할까요?`;
   if(!confirm(msg))return;
  }else if(!confirm(`${name}의 앱 사용 권한을 해제할까요?\n기존 대여·예약 기록은 유지되고 재승인 없이 관리자만 다시 활성화할 수 있습니다.`))return;
 }else if(!confirm(`${name}의 앱 사용 권한을 다시 활성화할까요?`))return;
 await updateDoc(doc(db,'members',uid),{active:next,updatedAt:serverTimestamp()});
 alert(next?'직원 계정이 다시 활성화되었습니다.':'직원 계정의 앱 접근 권한을 해제했습니다.');
}
async function moveMember(uid){if(operationPending("delete_user",uid))return alert("계정 삭제 처리 중입니다.");const t=teamList.find(x=>x.id===$("memberTeam-"+uid)?.value);if(!t||t.active===false)return alert("활성 팀을 선택하세요.");await updateDoc(doc(db,"members",uid),{teamId:t.id,teamName:t.name,updatedAt:serverTimestamp()});alert("팀 배정 완료. 직원은 다시 로그인하면 새 소속이 적용됩니다.")}
async function closeProject(id){const p=projects.find(x=>x.id===id);if(!p||p.active===false)return;const ts=teamList.filter(t=>t.projectId===id),legacy=activeLoans().filter(l=>ts.some(t=>t.id===l.teamId)&&!l.projectId);if(legacy.length)return alert(`작품 ID가 없는 이전 대여 ${legacy.length}건이 있습니다. 오반납 방지를 위해 해당 기록을 먼저 수동 반납해 주세요.`);const records=activeLoans().filter(l=>l.projectId===id);if(!confirm(`${p.name} 종료: 미반납 ${records.length}건을 자동 반납하고 재고를 복구합니다. 실제 장비 입고 여부는 별도 확인해야 합니다. 계속할까요?`))return;
 // One transaction per loan: rules require each equipment update to match its loan's return.
 // A failure leaves the project active; rerunning processes only remaining active loans.
 try{for(const l of records){await returnLoan(l)}await updateDoc(doc(db,"projects",id),{active:false,closedAt:serverTimestamp()});for(const t of ts)await updateDoc(doc(db,"teams",t.id),{active:false});alert("작품 종료 완료. 미반납 기록 자동 반납 및 재고 복구를 처리했습니다. 기존 직원 계정은 유지됩니다.")}catch(e){alert("종료 처리 중 일부 작업이 실패했습니다. 작품과 미반납 기록을 확인하고 다시 종료를 시도하세요: "+e.message)}}
function renderTeamAdmin(){
 const t=$("teamsList"),r=$("requestsList");if(!t||!r)return;
 const activeTeams=teamList.filter(x=>x.active!==false);
 const inactiveTeams=teamList.filter(x=>x.active===false);
 const teamRow=x=>{
  const project=projects.find(p=>p.id===x.projectId);
  const projectLabel=project?.name||'작품 미연결';
  return `<div class="item"><div style="flex:1;min-width:0"><b>${esc(x.name)}</b><div class="meta">작품: ${esc(projectLabel)} · ${x.active===false?"비활성":"활성"}</div><div class="meta" style="font-size:11px">팀 ID: ${esc(x.id)}</div></div><button class="small secondary" data-toggle-team="${esc(x.id)}">${x.active===false?"활성화":"비활성화"}</button></div>`;
 };
 const openTeams=[...t.querySelectorAll("details[open]")].map(x=>x.dataset.teamFold);
 t.innerHTML=`<details class="admin-fold" data-team-fold="active"><summary>운영 중인 팀 <span class="fold-count">${activeTeams.length}개</span></summary><div class="fold-body"><div class="list">${activeTeams.map(teamRow).join("")||'<div class="empty">운영 중인 팀이 없습니다.</div>'}</div></div></details><details class="admin-fold" data-team-fold="inactive"><summary>운영 종료 팀 <span class="fold-count">${inactiveTeams.length}개</span></summary><div class="fold-body"><div class="list">${inactiveTeams.map(teamRow).join("")||'<div class="empty">운영 종료 팀이 없습니다.</div>'}</div></div></details>`;
 t.querySelectorAll("details[data-team-fold]").forEach(el=>{if(openTeams.includes(el.dataset.teamFold))el.open=true;});

 const pending=joinRequests.filter(x=>x.status==="pending");
 r.innerHTML=pending.length?pending.map(x=>`<div class="item"><div><b>${esc(x.name)}</b><div class="meta">${esc(x.username||x.email)}<br>희망 팀: ${esc(x.requestedTeam)}</div><select id="assign-${esc(x.id)}"><option value="">대기 직원 (팀 미배정)</option>${teamList.filter(t=>t.active!==false).map(t=>{const project=projects.find(p=>p.id===t.projectId);return `<option value="${esc(t.id)}">${esc(project?`${project.name} · ${t.name}`:`미연결 팀 · ${t.name}`)}</option>`}).join("")}</select></div><button class="small" data-approve="${esc(x.id)}">승인</button><button class="small secondary" data-reject="${esc(x.id)}">거절</button>${adminDeleteButton("delete_user",x.id,x.name||x.username||"가입 신청자")}</div>`).join(""):'<div class="empty">대기 중인 가입 신청이 없습니다.</div>';
}
async function createTeam(){if(!isAdmin())return;const name=$("newTeamName").value.trim();if(!name)return alert("팀 이름을 입력해 주세요.");if(teamList.some(t=>t.name===name))return alert("동일한 팀 이름이 있습니다.");await addDoc(collection(db,"teams"),{name,active:true,createdAt:serverTimestamp()});$("newTeamName").value=""}
async function approveUser(uid){
 if(!isAdmin())return;
 if(operationPending("delete_user",uid))return alert("계정 삭제 처리 중입니다.");
 const id=$("assign-"+uid)?.value||"",t=teamList.find(x=>x.id===id),r=joinRequests.find(x=>x.id===uid);
 if(!r||(id&&(!t||t.active===false)))return alert("소속 팀을 확인해 주세요.");
 const batch=writeBatch(db);
 batch.set(doc(db,"members",uid),{role:"team",...(t?{teamId:t.id}:{}),teamName:t?.name||"대기 직원",active:true,displayName:r.name,updatedAt:serverTimestamp()});
 batch.update(doc(db,"joinRequests",uid),{status:"approved",updatedAt:serverTimestamp()});
 await batch.commit();alert(r.name+" 님을 "+(t?.name||"대기 직원")+"으로 승인했어요.");
}
async function saveTeam(){
 if(!isAdmin())return;
 const uid=$("teamUid").value.trim(),name=$("teamName").value.trim();
 if(!/^[a-zA-Z0-9]{20,128}$/.test(uid)||!name)return alert("Firebase Authentication에서 만든 팀 계정의 UID와 팀 이름을 입력해 주세요.");
 if(uid===ADMIN_UID)return alert("관리자 UID는 팀으로 등록할 수 없습니다.");
 await setDoc(doc(db,"members",uid),{role:"team",teamName:name,active:true,updatedAt:serverTimestamp()});
 alert(`${name} 등록 완료! 팀 계정으로 로그인할 수 있습니다.`);$("teamUid").value="";$("teamName").value="";
}
async function downloadBlob(name,blob){
 // Native Android/iOS: write the file into app storage and open the system share/save sheet.
 // Browser/PWA: prefer the platform share sheet when available; otherwise download normally.
 const native=window.Capacitor?.isNativePlatform?.();
 if(native){
  const plugins=window.Capacitor?.Plugins||{};
  const filesystem=plugins.Filesystem,share=plugins.Share;
  if(!filesystem||!share)throw Error("파일 저장 플러그인을 찾지 못했습니다. 새 버전 APK를 설치해 주세요.");
  const bytes=new Uint8Array(await blob.arrayBuffer());
  let binary="";for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  const base64=btoa(binary);
  const result=await filesystem.writeFile({path:name,data:base64,directory:"CACHE",recursive:true});
  try{await share.share({title:name,text:"Lightpia & Softsun 장비 관리 백업",url:result.uri,dialogTitle:"파일 저장 또는 공유"});return true;}catch(e){if(/cancel|abort|dismiss/i.test(e.message||e.name||""))return false;throw e;}
 }
 if(navigator.canShare&&navigator.share){
  const file=new File([blob],name,{type:blob.type||"application/octet-stream"});
  if(navigator.canShare({files:[file]})){
   try{await navigator.share({files:[file],title:name});return}catch(e){if(e.name==="AbortError")return false;}
  }
 }
 const a=document.createElement("a"),url=URL.createObjectURL(blob);
 a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();
 setTimeout(()=>URL.revokeObjectURL(url),10000);
}
async function exportJSON(){const data={format:"lightpia-equipment-backup",version:4,exportedAt:new Date().toISOString(),equipment:equipment.map(x=>({...x,createdAt:null,updatedAt:null})),loans:loans.map(x=>({...x,createdAt:null,updatedAt:null,returnedAt:null})),repairs:repairs.map(x=>({...x,createdAt:null,updatedAt:null,returnedAt:null})),damageReports:breakdownReports.map(x=>({...x,createdAt:null,updatedAt:null}))};await downloadBlob(`조명장비_백업_${today()}.json`,new Blob([JSON.stringify(data,null,2)],{type:"application/json;charset=utf-8"}))}
async function exportCSV(){const rows=[["종류","장비명","분류/팀","모델/담당자","수량","대여일","반납예정일","상태","비고","대여 구분","장비 구분","외부팀명","외부 담당자","관리 단위","1BOX 구성 EA"],...loans.map(l=>["대여",l.equipmentName,loanTeamLabel(l,teamList,projects),l.person,l.quantity,l.loanDate,l.dueDate,l.status==="returned"?"반납완료":"대여중",l.note,l.rentalType==="external"?"외부팀":"내부팀",loanGroupName(l),l.externalTeam,l.externalPerson,unitSnapshot(l).unit,unitSnapshot(l).unitsPerBox]),...equipment.map(e=>["재고",e.name,e.category,e.model,e.total,"","","",e.note,"","","","",unitSnapshot(e).unit,unitSnapshot(e).unitsPerBox]),...repairs.map(r=>["수리",r.equipmentName,r.vendor,r.symptom,r.quantity,r.repairDate,"",r.status==="completed"?"수리완료":"수리중",r.note,"","","","",unitSnapshot(r).unit,unitSnapshot(r).unitsPerBox])];const csv="\uFEFF"+rows.map(r=>Array.from({length:15},(_,i)=>r[i]).map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");await downloadBlob(`조명장비_목록_${today()}.csv`,new Blob([csv],{type:"text/csv;charset=utf-8;"}))}
async function importJSON(file){
 if(!file)return;
 try{
  if(!isAdmin())throw Error("관리자만 백업 가져오기를 실행할 수 있습니다.");
  if(file.size>15*1024*1024)throw Error("파일이 너무 큽니다 (15MB 초과).");
  const data=JSON.parse(await file.text());
  if(data.format!=="lightpia-equipment-backup"||![2,3,4].includes(data.version)||!Array.isArray(data.equipment)||!Array.isArray(data.loans)||!Array.isArray(data.repairs))throw Error("지원되는 JSON 백업 형식(version 2·3·4)이 아닙니다.");
  const sets=[{label:"장비",name:"equipment",rows:data.equipment,current:equipment},{label:"대여 기록",name:"loans",rows:data.loans,current:loans},{label:"수리 기록",name:"repairs",rows:data.repairs,current:repairs}];
  const errors=[],warnings=[],results=[];
  const eqIds=new Set(data.equipment.map(x=>x.id));
  const liveEqIds=new Set(equipment.map(x=>x.id));
  for(const set of sets){
   const seen=new Set(),existing=new Map(set.current.map(x=>[x.id,x]));let duplicate=0,missing=0,conflict=0;
   for(const item of set.rows){
    if(!item||typeof item!=="object"||typeof item.id!=="string"||!item.id.trim()){errors.push(`${set.label}: 유효하지 않은 ID`);continue;}
    if(seen.has(item.id))errors.push(`${set.label}: 파일 안에 중복 ID ${item.id}`);
    seen.add(item.id);
    if(existing.has(item.id)){
     duplicate++;
     const old=existing.get(item.id);
     if(set.name==="equipment" && (old.total!==item.total||old.loaned!==item.loaned||old.repairing!==item.repairing))conflict++;
    }else missing++;
    if(set.name==="equipment"){try{validateUnit(item);}catch(e){errors.push("장비 단위 오류: "+e.message);}}
    if(set.name==="equipment" && (!Number.isInteger(item.total)||!Number.isInteger(item.loaned)||!Number.isInteger(item.repairing)||item.total<0||item.loaned<0||item.repairing<0||(item.total!==0&&item.loaned+item.repairing>item.total)))errors.push(`장비 수량 오류: ${item.name||item.id}`);
    if(set.name==="loans" && (!eqIds.has(item.equipmentId)&&!liveEqIds.has(item.equipmentId)))warnings.push(`대여 기록 ${item.id}: 연결된 장비가 백업/현재 목록에 없음`);
   }
   results.push({label:set.label,total:set.rows.length,duplicate,missing,conflict});
  }
  if(data.equipment.length>0 && data.loans.some(x=>x.status==="active"))warnings.push("진행 중인 대여 기록은 재고와 별도로 검증해야 합니다.");
  const esc=x=>String(x).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const table=results.map(x=>`<tr><td>${x.label}</td><td>${x.total}</td><td>${x.duplicate}</td><td>${x.missing}</td><td>${x.conflict}</td></tr>`).join("");
  const notes=[...errors.map(x=>"오류: "+x),...warnings.map(x=>"주의: "+x)].slice(0,12);
  const untrackedNote=data.equipment.some(x=>x.total===0)?'<p class="meta">전체 수량 0인 장비는 수량 미집계 장비입니다. 대여·수리 수량이 있어도 전체 수량 초과 오류로 처리하지 않습니다.</p>':'';
  const noteHtml=notes.length?`<div class="notice warning">${notes.map(esc).join("<hr>")}</div>`:'<p class="muted">파일 내부의 기본 형식 및 수량 검사에서 오류가 발견되지 않았습니다.</p>';
  const html=`<div class="notice">읽기 전용 사전 검사입니다. Firebase 데이터는 추가·수정·삭제되지 않습니다. 현재 화면에 로드된 데이터를 기준으로 비교했습니다.</div><div class="meta">파일: ${esc(file.name)} · 백업일: ${esc(data.exportedAt||"미기록")}</div><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;text-align:center;margin:15px 0"><thead><tr><th>종류</th><th>백업</th><th>이미 존재</th><th>새 ID</th><th>재고 충돌</th></tr></thead><tbody>${table}</tbody></table></div>${noteHtml}${untrackedNote}<p class="meta">새 ID는 실제 복원 대상이 아니라 예상 후보입니다. 복원 실행 기능은 비활성화되어 있습니다.</p><button class="secondary" id="closeDryRun">확인 · 닫기</button>`;
  const eligible=data.equipment.filter(x=>!equipment.some(y=>y.id===x.id)&&x.loaned===0&&x.repairing===0&&Number(x.brokenStock||0)===0&&Number(x.reportRepairing||0)===0&&Number(x.brokenEa||0)===0&&Number(x.repairingEa||0)===0&&Number(x.reportRepairingEa||0)===0&&Number.isInteger(x.total)&&x.total>=0&&typeof x.name==="string"&&x.name.trim());
  const blocked=data.equipment.filter(x=>!equipment.some(y=>y.id===x.id)&&!eligible.includes(x));
  const action=errors.length?'<div class="notice warning">검사 오류가 있어 복원을 실행할 수 없습니다.</div>':(!eligible.length&&!blocked.length)?'<div class="notice">검사 완료 · 백업의 장비가 모두 이미 등록되어 있습니다. 새로 추가할 장비가 없으며 현재 데이터는 그대로 유지됩니다.</div>':`<div class="notice">기존 장비는 절대 덮어쓰지 않습니다. 새 장비 ${eligible.length}종만 복원할 수 있습니다. 과거 대여 ${data.loans.length}건과 수리 ${data.repairs.length}건은 현재 Firebase 보안 규칙상 복원할 수 없어 건너뜁니다.</div><button id="restoreMissingEquipment" ${eligible.length?'':'disabled'}>새 장비 ${eligible.length}종만 복원</button>`;
  modal("JSON 백업 가져오기",html.replace('읽기 전용 사전 검사입니다. Firebase 데이터는 추가·수정·삭제되지 않습니다. 현재 화면에 로드된 데이터를 기준으로 비교했습니다.','복원 전 검사입니다. 기존 데이터는 덮어쓰지 않으며 새 장비만 추가할 수 있습니다. 대여·수리 이력은 이 기능으로 복원되지 않습니다.').replace('새 ID는 실제 복원 대상이 아니라 예상 후보입니다. 복원 실행 기능은 비활성화되어 있습니다.',`복원 제외: 대여 ${data.loans.length}건, 수리 ${data.repairs.length}건, 복원 불가 장비 ${blocked.length}종.`).replace('<button class="secondary" id="closeDryRun">확인 · 닫기</button>',action+'<button class="secondary" id="closeDryRun">닫기</button>'));
  $("closeDryRun").addEventListener("click",closeModal);
  const restoreButton=$("restoreMissingEquipment");
  if(restoreButton)restoreButton.addEventListener("click",async()=>{
   if(!isAdmin())return alert("관리자 전용입니다.");
   if(!confirm(`기존 데이터는 유지하고 새 장비 ${eligible.length}종만 추가할까요? 대여·수리 기록은 복원되지 않습니다.`))return;
   restoreButton.disabled=true;let done=0;const failures=[];
   for(const x of eligible){
    try{
     const ref=eqDoc(x.id);const live=await getDoc(ref);
     if(live.exists())continue;
     const payload={...unitSnapshot(x),name:x.name,searchTags:normalizeEquipmentTags(x.searchTags),model:String(x.model||""),category:String(x.category||"기타"),note:String(x.note||""),total:x.total,loaned:0,repairing:0,createdAt:serverTimestamp(),updatedAt:serverTimestamp()};
     await setDoc(ref,payload);done++;
    }catch(err){failures.push(`${x.name}: ${err.message}`)}
   }
   closeModal();alert(`새 장비 ${done}종 복원 완료. 실패 ${failures.length}건. 기존 장비는 변경하지 않았습니다. 대여·수리 기록은 복원하지 않았습니다.${failures.length?'\n'+failures.join('\n'):''}`);
  });
 }catch(e){alert("백업 검사 실패: "+e.message)}finally{$("importFile").value=""}
}

const featureApi={collection,doc,getDoc,getDocs,addDoc,setDoc,updateDoc,writeBatch,onSnapshot,query,where,orderBy,serverTimestamp,runTransaction};
const featureUI={api:featureApi,db:()=>db,uid:()=>currentUser?.uid,isAdmin,name:()=>isAdmin()?'관리자':member?.displayName||teamName,team:()=>teamName,modal,closeModal,esc,today};
const equipmentPhotos=createEquipmentPhotos({...featureUI,equipment:id=>equipment.find(e=>e.id===id),render,error:message=>status(message)});
const crewBoard=createCrewBoard(featureUI);
const photoBackup=createPhotoBackup({...featureUI,api:{...featureApi,getDocsFromServer,documentId,limit,startAfter},equipment:()=>equipment,eqDoc,download:downloadBlob});
installAndroidBackHandler(window.Capacitor,{
 hasModal:()=>!!$('modalBack'),
 closeModal:()=>{const close=$('closeModal');if(close&&!close.disabled)close.click();},
 isSecondaryView:()=>activeTab!=='home',
 goHome:()=>document.querySelector('[data-tab="home"]')?.click()
}).catch(err=>console.error('뒤로가기 연결 실패',err));

initRememberedAccount();
document.addEventListener("click",e=>{
 const cat=e.target.closest("[data-cart-cat]");if(cat){cartCategory=cat.dataset.cartCat;renderCart();return}
 const plus=e.target.closest("[data-cart-plus]"),minus=e.target.closest("[data-cart-minus]");
 if(plus||minus){const id=(plus||minus).dataset[plus?"cartPlus":"cartMinus"];const old=cartItems[id]||0;cartItems[id]=Math.max(0,Math.min(untracked(id)?9999:Math.max(0,availableQtyFor(id)),old+(plus?1:-1)));renderCart(true);return}
});
document.addEventListener("click",async e=>{const detail=e.target.closest("[data-equipment-detail]");if(detail&&!e.target.closest("button")){showEquipmentDetail(detail.dataset.equipmentDetail);return}const b=e.target.closest("button");if(!b)return;try{if(b.dataset.tab){activeTab=b.dataset.tab;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===activeTab));["home","equipment","loans","reservations","crew","settings"].forEach(x=>show("view-"+x,x===activeTab));render()}if(b.dataset.goto){document.querySelector(`[data-tab="${b.dataset.goto}"]`).click()}if(b.id==="addEquipmentBtn"){if(!isAdmin())throw Error("관리자 전용입니다.");addEquipment()}if(b.dataset.equipmentDetail)showEquipmentDetail(b.dataset.equipmentDetail);if(b.dataset.editEquipment){if(!isAdmin())throw Error("관리자 전용입니다.");const item=equipment.find(x=>x.id===b.dataset.editEquipment);closeModal();addEquipment(item)}if(b.dataset.deleteEquipment){if(!isAdmin())throw Error("관리자 전용입니다.");const id=b.dataset.deleteEquipment;if(borrowedQtyFor(id)>0)return alert("대여 중인 장비는 삭제할 수 없습니다.");if(repairQtyFor(id)>0||warehouseBrokenQtyFor(id)>0)return alert("수리·고장 처리가 남은 장비는 삭제할 수 없습니다.");if(repairs.some(r=>r.equipmentId===id))return alert("수리 이력이 있는 장비는 삭제할 수 없습니다. 수리 이력을 먼저 정리해 주세요.");if(confirm("이 장비를 삭제할까요?")){const batch=writeBatch(db);batch.delete(eqDoc(id));batch.delete(doc(db,"company/main/equipmentPhotos",id));batch.delete(doc(db,"company/main/equipmentPhotoDetails",id));await batch.commit();}}if(b.id==="stockOverviewCard")showStockOverview();if(b.id==="addLoanBtn")addLoan();if(b.id==="bulkReturnBtn")bulkReturnDialog();if(b.dataset.loanEquipment){const id=b.dataset.loanEquipment;closeModal();addLoan({equipmentId:id})}if(b.dataset.editLoan){const item=loans.find(x=>x.id===b.dataset.editLoan);closeModal();addLoan(item)}if(b.dataset.addRepair){const id=b.dataset.addRepair;closeModal();addRepair(id)}if(b.dataset.editRepair){const item=repairs.find(x=>x.id===b.dataset.editRepair);closeModal();if(item)addRepair(item.equipmentId,item)}if(b.dataset.completeRepair){throw Error("수리 기록 변경은 현재 제한됩니다.");const item=repairs.find(x=>x.id===b.dataset.completeRepair);if(item&&confirm("이 수리를 완료 처리할까요? 완료 처리하면 사용 가능 수량에 다시 포함됩니다.")){await updateDoc(repairDoc(item.id),{status:"completed",updatedAt:serverTimestamp()});repairs=repairs.map(r=>r.id===item.id?{...r,status:"completed"}:r);showEquipmentDetail(item.equipmentId)}}if(b.dataset.deleteRepair){throw Error("수리 기록 변경은 현재 제한됩니다.");const item=repairs.find(x=>x.id===b.dataset.deleteRepair);if(item&&confirm("이 수리 기록을 삭제할까요?")){await deleteDoc(repairDoc(item.id));repairs=repairs.filter(r=>r.id!==item.id);showEquipmentDetail(item.equipmentId)}}if(b.id==="bulkDeleteReturnedBtn"||b.id==="bulkDeleteReturnedHomeBtn")await bulkDeleteReturnedLoansAdmin();if(b.dataset.deleteLoan)await deleteReturnedLoanAdmin(b.dataset.deleteLoan);if(b.dataset.return){const l=loans.find(x=>x.id===b.dataset.return);if(confirm(`${l.equipmentName} ${loanQuantityText(l.quantity,l)}를 반납 처리할까요?`))await returnLoan(l)}if(b.id==="loginEmailBtn")await loginEmail();if(b.id==="signOutBtn"){if(confirm("로그아웃할까요? 같은 이메일로 다시 로그인할 수 있습니다."))await signOut(auth)}if(b.id==="showConfigBtn")cfgShow();if(b.id==="hideConfigBtn")show("configPanel",false);if(b.id==="saveConfigBtn"){const raw=$("firebaseConfig").value.trim();const c=JSON.parse(raw);if(!c.apiKey||!c.projectId||!c.appId)throw Error("apiKey, projectId, appId 항목이 필요합니다.");localStorage.setItem("lpPersonalFirebaseConfig",JSON.stringify(c));location.reload()}if(b.id==="exportJsonBtn")await exportJSON();if(b.id==="exportBtn")await exportCSV();if(b.id==="importJsonBtn"){if(!isAdmin())throw Error("관리자 전용입니다.");$("importFile").click();}if(b.id==="createTeamBtn")await createTeam();if(b.id==="createProjectBtn")await createProject();if(b.dataset.createProjectTeam)await createProjectTeam(b.dataset.createProjectTeam);if(b.dataset.saveMemberName)await saveMemberName(b.dataset.saveMemberName);if(b.dataset.linkProject)await linkProject(b.dataset.linkProject);if(b.dataset.moveMember)await moveMember(b.dataset.moveMember);if(b.dataset.toggleMember)await toggleMember(b.dataset.toggleMember);if(b.dataset.closeTeam)await closeTeam(b.dataset.closeTeam);if(b.dataset.closeProject)await closeProject(b.dataset.closeProject);if(b.dataset.approve)await approveUser(b.dataset.approve);if(b.dataset.reject&&confirm("가입 신청을 거절할까요?"))await updateDoc(doc(db,"joinRequests",b.dataset.reject),{status:"rejected",updatedAt:serverTimestamp()});if(b.dataset.toggleTeam){const t=teamList.find(x=>x.id===b.dataset.toggleTeam);if(t&&t.active===false&&(!projects.some(p=>p.id===t.projectId&&p.active!==false)))return alert("진행 중인 작품에 연결된 팀만 다시 활성화할 수 있습니다.");if(t&&operationPending("delete_team",t.id))return alert("팀 삭제 처리 중입니다.");if(t&&t.active!==false){await closeTeam(t.id);return}if(t&&confirm("팀 활성 상태를 변경할까요?"))await updateDoc(doc(db,"teams",t.id),{active:t.active===false})}}catch(err){alert("처리 중 오류: "+err.message)}});

$("gateLoginBtn").addEventListener("click",loginEmail);
$("gateLoginPassword").addEventListener("keydown",e=>{if(e.key==="Enter")$("gateLoginBtn").click()});
bindSearchInput($("equipmentSearch"),renderEquipmentList);$("loanSearch").addEventListener("input",render);$("loanFilter").addEventListener("change",render);$("importFile").addEventListener("change",e=>importJSON(e.target.files?.[0]));
if(cfg()){try{$("firebaseConfig").value=cfg();initConfig(cfg())}catch(e){show("configPanel",true);status("설정 확인 필요");alert("Firebase 설정을 확인해 주세요: "+e.message)}}else{show("configPanel",true);show("setupNotice",true);status("초기 설정 필요")}
if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{});

$("signupBtn").addEventListener("click",signup);$("pendingSignOutBtn").addEventListener("click",()=>signOut(auth));

// V9.4: Team operations follow active project/team membership, not loan counts.
document.getElementById('activeTeamsCard')?.addEventListener('click',()=>{
 const active=teamList.filter(t=>t.active!==false&&projects.some(p=>p.id===t.projectId&&p.active!==false));
 const content=active.map(t=>{const p=projects.find(x=>x.id===t.projectId);const records=activeLoans().filter(l=>l.teamId===t.id);const staff=isAdmin()?membersList.filter(m=>m.teamId===t.id&&m.active!==false).map(m=>m.displayName||'이름 미등록').join(', '):'팀 소속 직원은 관리자 화면에서 확인';return `<div class="item" style="display:block;margin-bottom:9px"><div class="itemtitle">${esc(p?.name||'미연결 작품')} · ${esc(t.name)}</div><div class="meta">촬영 중 · 대여 ${records.length}건 / ${sumUnitQuantities(records)}<br>직원: ${esc(staff||'없음')}</div></div>`}).join('');
 modal('현재 촬영 중인 팀',content||'<div class="empty">진행 중인 작품에 연결된 활성 팀이 없습니다.</div>');
});

// Reservation pilot: independent reservation requests, admin review, and date overlap warnings.
const dateOverlap=(a,b,c,d)=>a<=d&&c<=b;
function reservationCard(r){const project=projects.find(p=>p.id===r.projectId),team=teamList.find(t=>t.id===r.teamId);const label={pending:'승인 대기',approved:'승인 완료',rejected:'거절',cancelled:'신청 취소',revoked:'승인 취소됨',fulfilled:'출고 완료'}[r.status]||r.status;return `<div class="item"><div style="flex:1;min-width:0"><div class="itemtitle">${esc(reservationPartyLabel(r,teamList,projects))} <span class="pill ${['approved','fulfilled'].includes(r.status)?'green':r.status==='pending'?'amber':'red'}">${esc(label)}</span></div><div class="meta">${esc(r.startDate)} ~ ${esc(r.endDate)} · ${esc(r.person||'담당자 미등록')}${Object.keys(r.fulfilledItems||{}).length?'<br>출고 '+Object.keys(r.fulfilledItems).length+'/'+r.items.length+'종 · '+esc(r.fulfillmentLoanDate||''):''}<br>${(r.items||[]).map(i=>equipmentImageLabel(i.id,esc(i.name)+' '+quantityText(i.qty,i),'micro')).join(' / ')}${r.note?'<br>'+esc(r.note):''}</div></div><div class="actions">${isAdmin()&&r.status==='pending'?`<button class="small" data-approve-reservation="${esc(r.id)}">승인</button><button class="small secondary" data-reject-reservation="${esc(r.id)}">거절</button>`:''}${r.status==='pending'&&(isAdmin()||r.ownerUid===currentUser?.uid)?`<button class="small secondary" data-cancel-reservation="${esc(r.id)}">신청 취소</button>`:''}${isAdmin()&&r.status==='approved'?`<button class="small" data-fulfill-reservation="${esc(r.id)}">${Object.keys(r.fulfilledItems||{}).length?'남은 장비 출고':'출고 처리'}</button>`:''}${isAdmin()&&r.status==='approved'?`<button class="small secondary" data-revoke-reservation="${esc(r.id)}">승인 취소</button>`:''}${isAdmin()?`<button class="small secondary" data-delete-reservation="${esc(r.id)}">삭제</button>`:''}</div></div>`}
function renderReservations(){const target=$('reservationList');if(!target)return;const sorted=[...reservations].sort((a,b)=>(b.startDate||'').localeCompare(a.startDate||''));target.innerHTML=sorted.length?sorted.map(reservationCard).join(''):'<div class="empty">예약 내역이 없습니다.</div>';}
// Inclusive date overlap; pending requests hold capacity until reviewed or cancelled.
function reservedForPeriod(id,start,end,excludeId=''){const e=equipment.find(x=>x.id===id);if(!e)return 0;return periodCapacity(e,[],reservations,start,end,today(),excludeId).peak;}
function reservationFree(id,start,end,excludeId=''){const eq=equipment.find(e=>e.id===id);if(!eq)return 0;return periodCapacity(eq,typeof loans==='undefined'?[]:loans,reservations,start,end,today(),excludeId).free;}
function refreshReservationQuantities(){
 const start=$('reserveStart')?.value,end=$('reserveEnd')?.value;
 document.querySelectorAll('[data-reserve-qty]').forEach(input=>{
  const id=input.dataset.reserveQty,free=reservationFree(id,start,end);
  const value=Math.max(0,Number(input.value)||0);
  input.value=String(Math.max(0,value));const count=rowCountForReservation(id);if(count)count.textContent=input.value;
  const row=input.closest('[data-reserve-row]');if(!row)return;
  const label=row.querySelector('[data-reserve-available]');if(label)label.textContent=free===9999?'수량 미확정':`해당 기간 예약 가능 ${quantityText(free,equipment.find(e=>e.id===id))}${value>free?" · 선택 수량 부족: 날짜/수량을 변경해 주세요.":""}`;
  const minus=row.querySelector('[data-reserve-minus]'),plus=row.querySelector('[data-reserve-plus]');
  if(minus)minus.disabled=value<=0;if(plus)plus.disabled=value>=free;row.classList.toggle('capacity-conflict',value>free);
 });
}
let reserveCategory="전체", reserveSearch="";
function renderReservationEquipment(){
 const list=$("reserveEquipmentList"),filters=$("reserveCategories");if(!list||!filters)return;
 const cats=["전체",...new Set(equipment.map(e=>e.category||"미분류"))];
 filters.innerHTML=cats.map(c=>`<button type="button" class="secondary ${reserveCategory===c?'selected':''}" data-reserve-category="${esc(c)}">${esc(c)}</button>`).join("");
 const q=reserveSearch.trim().toLowerCase();
 const rows=[...list.querySelectorAll("[data-reserve-row]")];let visible=0;
 rows.forEach(row=>{const eq=equipment.find(e=>e.id===row.dataset.reserveRow);const ok=!!eq&&(reserveCategory==="전체"||(eq.category||"미분류")===reserveCategory)&&matchesEquipmentSearch(eq,q);row.style.display=ok?"":"none";if(ok)visible++});
 const empty=$("reserveNoResults");if(empty)empty.style.display=visible?"none":"block";
 const chosen=rows.map(row=>{const n=Number(row.querySelector("[data-reserve-qty]")?.value||0);return n>0?{...unitSnapshot(equipment.find(e=>e.id===row.dataset.reserveRow)),id:row.dataset.reserveRow,name:equipment.find(e=>e.id===row.dataset.reserveRow)?.name||"장비",qty:n}:null}).filter(Boolean);
 const summary=$("reserveSelectionSummary");if(summary)summary.innerHTML=`<b>${chosen.length}종 · ${sumUnitQuantities(chosen,'qty')} 선택</b>${chosen.length?`<div class="meta">${chosen.map(i=>equipmentImageLabel(i.id,esc(i.name)+" "+quantityText(i.qty,i),'micro')).join(" · ")}</div>`:""}`;
}
function openReservation(){
 const activeTeams=teamList.filter(t=>t.active!==false&&projects.some(p=>p.id===t.projectId&&p.active!==false));
 if(!isAdmin()&&!activeTeams.length)return alert('먼저 작품에 활성 팀을 등록해 주세요.');
 const options=(isAdmin()?activeTeams:activeTeams.filter(t=>t.id===teamId)).map(t=>{const p=projects.find(p=>p.id===t.projectId);return `<option value="${esc(t.id)}">${esc(p?.name||'작품 미지정')} · ${esc(t.name)}</option>`}).join('');
 if(!isAdmin()&&!options)return alert('현재 소속된 활성 촬영팀이 없습니다. 관리자에게 문의해 주세요.');
 reserveCategory="전체";reserveSearch="";
 const items=equipment.map(e=>`<div class="item" data-reserve-row="${esc(e.id)}" style="align-items:center;gap:10px"><div style="flex:1;min-width:0">${equipmentImageLabel(e.id,`<b>${esc(e.name)}</b><span class="meta">${unitHint(e)}</span><span class="meta" data-reserve-available>계산 중</span>${reservationBadge(e)}`)}</div><div class="qty-control" style="display:flex;align-items:center;gap:9px"><button type="button" class="secondary" data-reserve-minus="${esc(e.id)}" style="min-width:40px;padding:9px">−</button><strong data-reserve-count="${esc(e.id)}" style="min-width:22px;text-align:center">0</strong><small class="qty-unit">${unitSnapshot(e).unit}</small><button type="button" class="secondary" data-reserve-plus="${esc(e.id)}" style="min-width:40px;padding:9px">＋</button><input type="hidden" value="0" data-reserve-qty="${esc(e.id)}"></div></div>`).join('');
 modal('장비 일괄 예약 신청',`<div class="notice">예약 신청 즉시 해당 기간의 예약 가능 수량에서 차감됩니다. 승인 대기·승인 완료 예약 모두 반영하며 거절·취소 시 복구됩니다. 예약 승인만으로 출고 처리되지는 않습니다.</div>${isAdmin()?`<div class="field"><label>예약 대상</label><select id="reserveRentalType"><option value="internal" ${options?'':'disabled'}>내부팀 예약</option><option value="external" ${options?'':'selected'}>외부팀 예약</option></select></div><div id="reserveExternalFields" class="hidden"><p class="meta">외부팀은 가입할 필요가 없습니다. 팀명 또는 담당자 중 하나 이상 입력해 주세요.</p><div class="field"><label>외부팀명</label><input id="reserveExternalTeam" maxlength="100" placeholder="예: 언내추럴 외부팀"></div><div class="field"><label>외부 담당자</label><input id="reserveExternalPerson" maxlength="80" placeholder="예: 김광민 기사님"></div></div>`:''}<div class="field" id="reserveInternalFields"><label>작품 · 팀</label><select id="reserveTeam">${options}</select></div><div class="field"><label>시작일 *</label><input id="reserveStart" type="date" min="${today()}" value="${today()}"></div><div class="field"><label>종료일 *</label><input id="reserveEnd" type="date" min="${today()}" value="${today()}"></div><div class="field"><label>메모</label><input id="reserveNote" placeholder="촬영 장소, 요청 사항"></div><h3>예약 장비 수량</h3><input class="search" id="reserveSearch" placeholder="⌕ 장비명 / 모델 / 분류 검색" autocomplete="off"><div id="reserveCategories" class="cart-filter"></div><div id="reserveEquipmentList" class="list" style="max-height:40dvh;overflow-y:auto">${items}</div><div id="reserveNoResults" class="empty" style="display:none">검색 결과가 없습니다.</div><div id="reserveSelectionSummary" class="cart-summary" style="margin-top:12px"></div><button id="submitReservation">예약 신청</button>`);
 const switchParty=()=>{const external=$("reserveRentalType")?.value==='external';$("reserveExternalFields")?.classList.toggle("hidden",!external);$("reserveInternalFields")?.classList.toggle("hidden",external);};$("reserveRentalType")?.addEventListener("change",switchParty);switchParty();
 refreshReservationQuantities();renderReservationEquipment();
 $("reserveStart").onchange=()=>{const start=$("reserveStart").value;$("reserveEnd").min=start;if($("reserveEnd").value<start)$("reserveEnd").value=start;refreshReservationQuantities();renderReservationEquipment();};$("reserveEnd").onchange=()=>{refreshReservationQuantities();renderReservationEquipment();};
 $("reserveSearch").addEventListener("input",e=>{reserveSearch=e.target.value;renderReservationEquipment()});
}
async function submitReservation(){
 let destination;try{destination=reservationDestination({admin:isAdmin(),mode:$('reserveRentalType')?.value||'internal',teamId:$('reserveTeam')?.value,currentTeamId:teamId,teams:teamList,projects,externalTeam:$('reserveExternalTeam')?.value,externalPerson:$('reserveExternalPerson')?.value});}catch(e){return alert(e.message);}
 const startDate=$('reserveStart')?.value,endDate=$('reserveEnd')?.value,note=$('reserveNote')?.value.trim();
 const items=[...document.querySelectorAll('[data-reserve-qty]')].map(x=>({...unitSnapshot(equipment.find(e=>e.id===x.dataset.reserveQty)),id:x.dataset.reserveQty,qty:Number(x.value),name:equipment.find(e=>e.id===x.dataset.reserveQty)?.name||''})).filter(x=>Number.isInteger(x.qty)&&x.qty>0);
 if(!startDate||!endDate||startDate<today()||endDate<startDate)return alert('예약 날짜를 확인해 주세요.');
 if(!items.length||items.length>20)return alert('1~20종의 장비를 선택하세요.');
 const conflicts=items.filter(i=>i.qty>reservationFree(i.id,startDate,endDate));
 if(conflicts.length){refreshReservationQuantities();return alert('선택 기간의 가용 수량이 부족합니다.\n'+conflicts.map(i=>{const e=equipment.find(e=>e.id===i.id);return capacityFailure(e,periodCapacity(e,typeof loans==='undefined'?[]:loans,reservations,startDate,endDate,today()),i.qty,startDate,endDate);}).join('\n'));}
 const btn=$('submitReservation');btn.disabled=true;
 try{await submitCheckedReservation(checkedCapacityApi(),db,{...destination,ownerUid:currentUser.uid,person:isAdmin()?'관리자':member?.displayName||teamName,startDate,endDate,note,items,status:'pending'},today());closeModal();alert('예약 신청 완료! 관리자 승인을 기다려 주세요.')}catch(e){alert('예약 신청 실패: '+e.message);btn.disabled=false}
}
let reservationFulfillmentBusy=false;
function openReservationFulfillment(id){
 if(!isAdmin())return alert('관리자 전용입니다.');if(reservationFulfillmentBusy)return;const r=reservations.find(r=>r.id===id);if(!r||r.status!=='approved')return alert('승인 완료 예약만 출고할 수 있습니다.');const partial=Object.keys(r.fulfilledItems||{}).length>0,remaining=remainingReservationItems(r);
 modal('예약 장비 출고 처리',`<form id="reservationFulfillmentForm"><p><b>${esc(reservationPartyLabel(r,teamList,projects))}</b></p><div class="notice">실제 장비를 가져가는 것을 확인한 뒤 출고해 주세요. 예약 선점을 실제 대여로 전환하며, 출고한 장비는 다시 차감하지 않습니다.</div><p class="meta">예약 ${esc(r.startDate)} ~ ${esc(r.endDate)} · 남은 ${remaining.length}종</p>${field('실제 출고일','fulfillmentDate','','date',partial?r.fulfillmentLoanDate:today(),true)}${field('반납 예정일','fulfillmentDue','','date',partial?r.fulfillmentDueDate:(r.endDate<today()?today():r.endDate),true)}<div class="field"><label for="fulfillmentGroup">장비 구분</label><select id="fulfillmentGroup">${['상주장비','세트장비','추가장비'].map(g=>`<option ${g===(r.fulfillmentGroup||'추가장비')?'selected':''}>${g}</option>`).join('')}</select></div><div class="list">${remaining.map(i=>`<div class="item"><b>${esc(i.name)}</b><strong>${loanQuantityText(i.qty,i)}</strong></div>`).join('')}</div><p id="fulfillmentStatus" class="meta" role="status" aria-live="polite"></p><button type="submit" id="confirmReservationFulfillment">확인 · 출고 처리</button></form>`);
 for(const id of ['fulfillmentDate','fulfillmentDue','fulfillmentGroup'])$(id).disabled=partial;
 $('reservationFulfillmentForm').onsubmit=async event=>{event.preventDefault();if(reservationFulfillmentBusy)return;const options={loanDate:$('fulfillmentDate').value,dueDate:$('fulfillmentDue').value,equipmentGroup:$('fulfillmentGroup').value,today:today()};const button=$('confirmReservationFulfillment');reservationFulfillmentBusy=true;button.disabled=true;$('fulfillmentStatus').textContent='재고와 예약을 확인하는 중…';try{await fulfillReservation(checkedCapacityApi(),db,id,options,{uid:currentUser.uid,isAdmin:isAdmin()},(done,total)=>{if($('fulfillmentStatus'))$('fulfillmentStatus').textContent=`출고 저장 중 · ${done}/${total}종`;if(done>0)for(const field of ['fulfillmentDate','fulfillmentDue','fulfillmentGroup'])if($(field))$(field).disabled=true;});reservationFulfillmentBusy=false;closeModal();alert('예약 장비 출고가 완료됐습니다. 대여·반납 목록에서 확인하세요.');}catch(e){reservationFulfillmentBusy=false;button.disabled=false;$('fulfillmentStatus').textContent=e.message;button.textContent='남은 장비 출고 재시도';}};
}
function renderOverdueReservationNotice(){const panel=$('overdueReservationsNotice');if(!panel)return;if(!isAdmin()){panel.classList.add('hidden');return;}const rows=overdueUnshippedReservations(reservations,today());panel.classList.toggle('hidden',!rows.length);if(!rows.length){panel.innerHTML='';return;}panel.innerHTML=`<h3>출고 확인이 필요한 지난 예약 ${rows.length}건</h3><p class="meta">${rows.slice(0,5).map(r=>esc(r.startDate+' · '+reservationPartyLabel(r,teamList,projects)+' · 미출고 '+remainingReservationItems(r).length+'종')).join('<br>')}</p><button class="small" data-goto="reservations">예약 확인 · 출고 처리</button>`;}
let overdueReminderDay='';
function remindOverdueReservations(){if(typeof ready==='undefined'||!ready||!isAdmin()||document.visibilityState!=='visible'||$('modalBack'))return;const rows=overdueUnshippedReservations(reservations,today());if(!rows.length)return;const key='lp-overdue-reminder-'+currentUser?.uid+'-'+today();if(overdueReminderDay===key)return;overdueReminderDay=key;try{if(localStorage.getItem(key))return;localStorage.setItem(key,'1');}catch{}alert('출고 확인이 필요한 지난 예약 '+rows.length+'건이 있습니다.\n'+rows.slice(0,3).map(r=>r.startDate+' · '+reservationPartyLabel(r,teamList,projects)+' · 미출고 '+remainingReservationItems(r).length+'종').join('\n')+'\n예약 목록에서 출고 또는 취소 여부를 확인해 주세요.');}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')remindOverdueReservations();});
async function reviewReservation(id,decision){const r=reservations.find(x=>x.id===id);if(!isAdmin()||!r||r.status!=='pending')return;const p=projects.find(x=>x.id===r.projectId),t=teamList.find(x=>x.id===r.teamId);if(decision==='approved'&&r.rentalType!=='external'&&(!p||p.active===false||!t||t.active===false))return alert('종료된 작품 또는 비활성 팀은 승인할 수 없습니다.');if(decision==='approved'){const conflicts=[];for(const i of r.items||[]){const eq=equipment.find(x=>x.id===i.id);if(!eq||!sameUnit(i,eq)){conflicts.push(i.name+' (삭제 또는 관리 단위 변경)');continue;}const result=periodCapacity(eq,typeof loans==='undefined'?[]:loans,reservations,r.startDate,r.endDate,today(),id);if(i.qty>result.free)conflicts.push(capacityFailure(eq,result,i.qty,r.startDate,r.endDate));}if(conflicts.length)return alert('예약 충돌 또는 수량 부족: '+conflicts.join(' / '));}if(!confirm(decision==='approved'?'예약을 승인할까요?':'예약을 거절할까요?'))return;await updateDoc(doc(reservationCol(),id),{status:decision,updatedAt:serverTimestamp()})}
async function revokeReservation(id){if(!isAdmin())return alert('관리자 전용 기능입니다.');const r=reservations.find(x=>x.id===id);if(!r||r.status!=='approved')return alert('이미 변경된 예약입니다. 화면을 새로 확인해 주세요.');if(!confirm('이 예약의 승인을 취소할까요?\n예약 기록은 보관되며 장비 대여 재고는 변경되지 않습니다.'))return;await runTransaction(db,async tx=>{const ref=doc(reservationCol(),id),snap=await tx.get(ref);if(!snap.exists()||snap.data().status!=='approved')throw Error('예약 상태가 이미 변경되었습니다.');tx.update(ref,{status:'revoked',updatedAt:serverTimestamp()})});}
async function cancelReservation(id){const r=reservations.find(x=>x.id===id);if(!r||r.status!=='pending'||!(isAdmin()||r.ownerUid===currentUser?.uid))return;if(confirm('예약 신청을 취소할까요?'))await updateDoc(doc(reservationCol(),id),{status:'cancelled',updatedAt:serverTimestamp()})}
async function deleteReservationAdmin(id){
 if(!isAdmin())throw Error('관리자 전용 기능입니다.');
 const r=reservations.find(x=>x.id===id);
 if(!r)throw Error('예약을 찾을 수 없습니다.');
 const label=reservationPartyLabel(r,teamList,projects);
 if(!confirm(label+' 예약 내역을 영구 삭제할까요?\n삭제한 기록은 복구할 수 없습니다.\n승인 대기/승인 완료 예약이면 해당 기간의 예약 선점도 해제됩니다.\n실제 출고·대여 기록은 별도로 유지됩니다.'))return;
 const ref=doc(reservationCol(),id);
 await runTransaction(db,async tx=>{
  const snap=await tx.get(ref);
  if(!snap.exists())throw Error('이미 삭제된 예약입니다.');
  tx.delete(ref);
 });
}
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;try{if(b.dataset.reservePlus||b.dataset.reserveMinus){const id=b.dataset.reservePlus||b.dataset.reserveMinus;const input=[...document.querySelectorAll('[data-reserve-qty]')].find(x=>x.dataset.reserveQty===id);if(input){const step=b.dataset.reservePlus?1:-1;input.value=String(Math.max(0,Math.min(reservationFree(id,$('reserveStart')?.value,$('reserveEnd')?.value),Number(input.value||0)+step)));const count=document.querySelector('[data-reserve-count=\"'+id+'\"]');if(count)count.textContent=input.value;refreshReservationQuantities();renderReservationEquipment();}}if(b.dataset.reserveCategory){reserveCategory=b.dataset.reserveCategory;renderReservationEquipment();}if(b.id==='openReservationBtn')openReservation();if(b.id==='submitReservation')await submitReservation();if(b.dataset.fulfillReservation)openReservationFulfillment(b.dataset.fulfillReservation);if(b.dataset.approveReservation)await reviewReservation(b.dataset.approveReservation,'approved');if(b.dataset.rejectReservation)await reviewReservation(b.dataset.rejectReservation,'rejected');if(b.dataset.cancelReservation)await cancelReservation(b.dataset.cancelReservation);if(b.dataset.revokeReservation)await revokeReservation(b.dataset.revokeReservation);if(b.dataset.deleteReservation)await deleteReservationAdmin(b.dataset.deleteReservation)}catch(err){alert('예약 처리 오류: '+err.message)}});

document.addEventListener('change',e=>{if(e.target?.id==='reserveStart'||e.target?.id==='reserveEnd'){const start=$('reserveStart'),end=$('reserveEnd');if(start&&end){end.min=start.value;if(end.value<start.value)end.value=start.value;}refreshReservationQuantities();renderReservationEquipment();}});

function rowCountForReservation(id){return [...document.querySelectorAll('[data-reserve-count]')].find(x=>x.dataset.reserveCount===id)}

document.addEventListener("click",e=>{const btn=e.target.closest("[data-equipment-category]");if(!btn)return;equipmentCategoryFilter=btn.dataset.equipmentCategory;render();});

// V9.6.20: contenteditable field preserves the live Korean IME composition.
// Do not rewrite its text or force blur during composition.


// Signup name editor: paste text only; no re-render or forced composition commit.
$('signupName')?.addEventListener('paste', e => {
  e.preventDefault();
  const value=e.clipboardData?.getData('text/plain')||'';
  const selection=window.getSelection();
  if(!selection?.rangeCount)return;
  const range=selection.getRangeAt(0);
  range.deleteContents();
  range.insertNode(document.createTextNode(value));
  range.collapse(false);
  selection.removeAllRanges();
  selection.addRange(range);
});

// Remember successful device registration; revalidate silently after login.
let adminPushRegistered=false,adminPushBusy=false,adminPushListenersReady=false;
function adminPushStorageKey(){return 'lpAdminPushRegistered:'+BUILTIN_FIREBASE_CONFIG.projectId+':'+ADMIN_UID;}
function updateAdminPushPanel(){
 let saved=false;try{saved=localStorage.getItem(adminPushStorageKey())==='1';}catch(_){}
 show('adminPushPanel',isAdmin()&&!(adminPushRegistered||saved));
}
function setAdminPushRegistered(value){
 adminPushRegistered=value;
 try{if(value)localStorage.setItem(adminPushStorageKey(),'1');else localStorage.removeItem(adminPushStorageKey());}catch(_){}
 updateAdminPushPanel();
}
function adminPushFailure(message){
 adminPushBusy=false;setAdminPushRegistered(false);
 const el=$('pushRegisterStatus');if(el)el.textContent=message;
}
async function installAdminPushListeners(plugin){
 if(adminPushListenersReady)return;
 const handles=[];
 try{
  handles.push(await plugin.addListener('registration',async ({value:token})=>{
   if(!isAdmin()||currentUser?.uid!==ADMIN_UID){adminPushBusy=false;return;}
   try{
    const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token));
    const key=[...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('');
    await setDoc(doc(db,'adminPushDevices',key),{token,platform:'android',ownerUid:ADMIN_UID,enabled:true,updatedAt:serverTimestamp()});
    adminPushBusy=false;
    $('pushRegisterStatus').textContent='이 기기 알림 등록 완료 ✓';
    setAdminPushRegistered(true);
   }catch(e){adminPushFailure('등록 저장 실패: '+e.message);}
  }));
  handles.push(await plugin.addListener('registrationError',e=>adminPushFailure('FCM 등록 실패: '+(e.error||JSON.stringify(e)))));
  handles.push(await plugin.addListener('pushNotificationActionPerformed',()=>{if(isAdmin())document.querySelector('[data-tab="reservations"]')?.click();}));
  adminPushListenersReady=true;
 }catch(e){for(const handle of handles)await handle.remove();throw e;}
}
async function enableAdminPush(silent=false){
 if(!isAdmin()||currentUser?.uid!==ADMIN_UID)throw Error('관리자만 알림을 등록할 수 있습니다.');
 if(adminPushBusy)return;
 const plugin=window.Capacitor?.Plugins?.PushNotifications;
 if(!plugin){if(silent)return;throw Error('Android APK에서만 등록할 수 있습니다. 최신 APK로 접속해 주세요.');}
 adminPushBusy=true;
 try{
  let perm=await plugin.checkPermissions();
  // On startup never request permission. Existing installs can reuse granted permission.
  if(perm.receive!=='granted'&&!silent)perm=await plugin.requestPermissions();
  if(perm.receive!=='granted'){
   adminPushBusy=false;setAdminPushRegistered(false);
   if(silent)return;
   throw Error('휴대폰 설정에서 앱 알림을 허용해 주세요.');
  }
  await installAdminPushListeners(plugin);
  $('pushRegisterStatus').textContent='FCM 토큰 등록 중...';
  await plugin.register();
 }catch(e){adminPushFailure(e.message);throw e;}
}
async function restoreAdminPush(){
 if(!isAdmin())return;
 updateAdminPushPanel();
 await enableAdminPush(true);
}
$('enableAdminPush')?.addEventListener('click',()=>enableAdminPush().catch(e=>adminPushFailure(e.message)));

function operationPending(type,id){return adminOperations.some(o=>o.type===type&&o.targetId===id&&['pending','processing'].includes(o.status));}
function adminDeleteButton(type,id,name){
 const pending=operationPending(type,id);
 return `<button type="button" class="small danger" data-admin-delete-type="${esc(type)}" data-admin-delete-id="${esc(id)}" data-admin-delete-name="${esc(name)}" ${pending?'disabled':''}>${pending?'삭제 처리 중':type==='delete_user'?'계정 삭제':type==='delete_team'?'팀 삭제':'작품 삭제'}</button>`;
}
function adminOperationsHTML(){
 const ordered=[...adminOperations].sort((a,b)=>(b.updatedAt?.seconds||0)-(a.updatedAt?.seconds||0)).slice(0,15);
 const labels={pending:'삭제 대기',processing:'삭제 처리 중',completed:'삭제 완료',failed:'처리 실패'};
 return `<details class="admin-fold" data-member-fold="delete-history"><summary>삭제 처리 내역 <span class="fold-count">${ordered.filter(x=>['pending','processing'].includes(x.status)).length}건 대기</span></summary><div class="fold-body"><p class="meta">서버가 순차 처리합니다. 완료까지 시간이 걸릴 수 있으며 화면을 닫아도 처리됩니다. 삭제 전 대여·예약 이력은 보관됩니다.</p>${ordered.map(o=>`<div class="item"><div><b>${esc(o.targetName)}</b><div class="meta">${o.type==='delete_user'?'직원 계정':o.type==='delete_team'?'종료 팀':'종료 작품'} · ${labels[o.status]||'상태 확인 중'}</div>${o.status==='failed'?`<div class="meta">${esc(o.error||'처리 결과를 확인해 주세요.')}</div>`:''}</div>${o.status==='failed'?`<button type="button" class="small secondary" data-retry-admin-operation="${esc(o.id)}">다시 시도</button>`:''}</div>`).join('')||'<div class="empty">삭제 요청 내역이 없습니다.</div>'}</div></details>`;
}
async function requestAdminDeletion(type,id,name){
 if(!isAdmin()||currentUser?.uid!==ADMIN_UID)throw Error('관리자 전용입니다.');
 if(!['delete_user','delete_project','delete_team'].includes(type)||id===ADMIN_UID)throw Error('삭제할 수 없는 대상입니다.');
 if(operationPending(type,id))return;
 if(type==='delete_team'){
  const t=teamList.find(t=>t.id===id);if(!t||t.active!==false)throw Error('종료·보관된 팀만 삭제할 수 있습니다.');
  if(activeLoans().some(l=>l.teamId===id))throw Error('이 팀의 미반납 장비를 먼저 반납해 주세요.');
  if(reservations.some(r=>r.teamId===id&&['pending','approved'].includes(r.status)&&(!r.endDate||r.endDate>=today())))throw Error('이 팀의 유효 예약을 먼저 취소해 주세요.');
 }
 if(type==='delete_project'){
  const p=projects.find(p=>p.id===id);if(!p||p.active!==false)throw Error('종료된 작품만 삭제할 수 있습니다.');
  const teams=teamList.filter(t=>t.projectId===id);
  if(activeLoans().some(l=>l.projectId===id||(!l.projectId&&teams.some(t=>t.id===l.teamId))))throw Error('미반납 장비를 먼저 반납해 주세요.');
  if(reservations.some(r=>r.projectId===id&&['pending','approved'].includes(r.status)&&(!r.endDate||r.endDate>=today())))throw Error('유효한 예약을 먼저 취소해 주세요.');
 }
 const desc=type==='delete_user'?'로그인 계정과 직원 정보를 영구 삭제합니다. 앱 이용 권한은 즉시 해제됩니다.':type==='delete_team'?'종료 팀을 목록에서 삭제합니다. 소속 직원은 대기 직원으로 전환하며 작품과 다른 팀은 유지됩니다.':'종료 작품을 작품 목록에서 영구 삭제합니다.';
 const counts=type==='delete_user'?`\n해당 직원의 미반납 ${activeLoans().filter(l=>l.ownerUid===id).length}건 · 유효 예약 ${reservations.filter(r=>r.ownerUid===id&&['pending','approved'].includes(r.status)&&r.endDate>=today()).length}건은 관리자가 계속 처리할 수 있습니다.`:'';
 if(!confirm(`${name}\n${desc}\n기존 대여·반납·예약 기록은 유지됩니다. 삭제는 되돌릴 수 없습니다.${counts}\n삭제를 요청할까요?`))return;
 const ref=doc(db,'adminOperations',type+'_'+id),existing=await getDoc(ref);
 if(existing.exists()){
  if(existing.data().status==='failed'){await updateDoc(ref,{status:'pending',error:'',updatedAt:serverTimestamp()});return;}
  return alert('이미 삭제 요청을 처리 중이거나 완료한 대상입니다.');
 }
 const batch=writeBatch(db);
 if(type==='delete_user'&&membersList.some(m=>m.id===id))batch.update(doc(db,'members',id),{active:false,updatedAt:serverTimestamp()});
 batch.set(ref,{type,targetId:id,targetName:String(name).slice(0,160),createdBy:currentUser.uid,status:'pending',createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
 await batch.commit();alert('삭제 요청을 접수했습니다. 삭제 처리 내역에서 완료 여부를 확인해 주세요.');
}
async function retryAdminOperation(id){
 if(!isAdmin()||currentUser?.uid!==ADMIN_UID)throw Error('관리자 전용입니다.');
 const op=adminOperations.find(x=>x.id===id);if(!op||op.status!=='failed')return;
 if(confirm(`${op.targetName} 삭제를 다시 시도할까요?`))await updateDoc(doc(db,'adminOperations',id),{status:'pending',error:'',updatedAt:serverTimestamp()});
}
document.addEventListener('click',async e=>{
 const b=e.target.closest('button');if(!b)return;
 try{if(b.dataset.adminDeleteType)await requestAdminDeletion(b.dataset.adminDeleteType,b.dataset.adminDeleteId,b.dataset.adminDeleteName);if(b.dataset.retryAdminOperation)await retryAdminOperation(b.dataset.retryAdminOperation);}catch(err){alert('처리 실패: '+err.message);}
});

let equipmentDrafts=[],equipmentDraftEdit=-1,equipmentDraftSaving=false,equipmentDraftRefs=null;
function equipmentIdentity(x){return [x.name,x.model,x.category,unitSnapshot(x).unit,unitSnapshot(x).unitsPerBox].map(v=>String(v||'').trim().toLocaleLowerCase().replace(/\s+/g,' ')).join('\u0001');}
function validateEquipmentDraft(data){
 validateUnit(data);
 if(!data.name||data.name.length>120)throw Error('장비명은 1~120자로 입력해 주세요.');
 if(!Number.isSafeInteger(data.total)||data.total<0)throw Error('전체 수량은 0 이상의 정수로 입력해 주세요.');
 if([data.model,data.category,data.searchTags,data.note].some(x=>x.length>1000))throw Error('장비 정보는 항목별 1,000자 이내로 입력해 주세요.');
}
function openEquipmentBatch(initial={}){
 if(!isAdmin())return alert('관리자 전용입니다.');
 equipmentDrafts=[];equipmentDraftEdit=-1;equipmentDraftSaving=false;equipmentDraftRefs=null;
 modal('장비 연속 등록',`<div class="loan-step equipment-entry-body"><p class="meta">장비를 목록에 담고 다음 품목을 계속 입력하세요. 마지막에 한 번에 등록됩니다.</p><form id="equipmentDraftForm" autocomplete="off">${field('장비명','eqName','예: ARRI M90','text',initial.name||'',true)}<div class="formgrid">${field('분류','eqCategory','예: HMI / LED','text',initial.category||'')}${field('모델 / 규격','eqModel','모델명','text',initial.model||'')}${unitFields('eq-',initial)}${field('전체 수량','eqTotal','수량','number',initial.total??1,true)}</div><datalist id="equipmentCategorySuggestions"><option value="HMI"><option value="LED"><option value="SKYPANEL"><option value="텅스텐"><option value="스탠드·그립"><option value="액세서리"><option value="기타"></datalist><details class="equipment-extra"><summary>검색 태그 · 비고 (선택)</summary>${field('검색어 / 태그','eqTags','예: #sun #소프트썬')}${field('비고','eqNote','보관 위치, 구성품 등')}</details><div class="modalbuttons"><button type="submit" id="equipmentDraftAdd">목록에 담고 다음 입력</button><button type="button" class="secondary hidden" id="equipmentDraftCancel">수정 취소</button></div></form><h3 class="loan-section-title">등록할 장비 목록</h3><div id="equipmentDraftList"></div></div><footer class="loan-footer"><div id="equipmentDraftCount" class="cart-count" role="status" aria-live="polite">0종 대기</div><button type="button" id="equipmentDraftSave" class="batch-save">목록 전체 등록</button></footer>`);
 $('modalBack').querySelector('.modal').classList.add('loan-modal','equipment-batch-modal');$('eqCategory').setAttribute('list','equipmentCategorySuggestions');
 bindUnitFields('eq-','eqTotal');
 $('equipmentDraftForm').onsubmit=e=>{e.preventDefault();try{queueEquipmentDraft();}catch(err){alert(err.message);}};
 $('equipmentDraftCancel').onclick=()=>resetEquipmentDraftForm();
 $('equipmentDraftSave').onclick=()=>saveEquipmentDrafts().catch(err=>alert('등록 실패: '+err.message));
 const close=$('closeModal');close.onclick=()=>{if(equipmentDraftSaving)return;if(!equipmentDrafts.length||confirm('등록 대기 목록을 저장하지 않고 닫을까요?'))closeModal();};
 $('modalBack').onclick=e=>{if(e.target.id==='modalBack')close.click();};
 renderEquipmentDrafts();
}
function queueEquipmentDraft(){
 if(equipmentDraftSaving)throw Error('장비를 등록 중입니다.');
 const data={...readUnitFields('eq-'),name:$('eqName').value.trim(),category:$('eqCategory').value.trim(),model:$('eqModel').value.trim(),total:Number($('eqTotal').value),searchTags:normalizeEquipmentTags($('eqTags').value),note:$('eqNote').value.trim()};
 if(!$('eqTotal').value.trim())throw Error('전체 수량을 입력해 주세요.');
 validateEquipmentDraft(data);const key=equipmentIdentity(data);
 if(equipment.some(x=>equipmentIdentity(x)===key))throw Error('이미 등록된 장비입니다. 기존 장비의 수량을 수정해 주세요.');
 if(equipmentDrafts.some((x,i)=>i!==equipmentDraftEdit&&equipmentIdentity(x)===key))throw Error('대기 목록에 같은 장비가 있습니다. 목록에서 수량을 수정해 주세요.');
 if(equipmentDraftEdit<0&&equipmentDrafts.length>=50)throw Error('한 번에 최대 50종까지 등록할 수 있습니다.');
 if(equipmentDraftEdit<0)equipmentDrafts.push(data);else equipmentDrafts[equipmentDraftEdit]=data;
 equipmentDraftRefs=null;resetEquipmentDraftForm();renderEquipmentDrafts();$('eqName').focus();
}
function resetEquipmentDraftForm(){
 equipmentDraftEdit=-1;for(const id of ['eqName','eqModel','eqTags','eqNote'])$(id).value='';$('eqTotal').value='1';$('eq-unit').value='EA';$('eq-unitsPerBox').value='1';bindUnitFields('eq-','eqTotal');$('equipmentDraftAdd').textContent='목록에 담고 다음 입력';show('equipmentDraftCancel',false);
}
function renderEquipmentDrafts(){
 $('equipmentDraftCount').textContent=`${equipmentDrafts.length}종 · ${sumUnitQuantities(equipmentDrafts,'total')} 등록 대기`;
 $('equipmentDraftList').innerHTML=equipmentDrafts.map((x,i)=>`<div class="item"><div><b>${esc(x.name)}</b><div class="meta">${esc(x.category||'미분류')} · ${esc(x.model||'모델 미입력')} · ${unitHint(x)} · ${x.total===0?'수량 미확정':quantityText(x.total,x)}</div></div><div class="actions"><button type="button" class="small secondary" data-draft-edit="${i}">수정</button><button type="button" class="small danger" data-draft-remove="${i}">제외</button></div></div>`).join('')||'<div class="empty">장비를 입력하고 목록에 담아 주세요.</div>';
}
async function saveEquipmentDrafts(){
 if(!isAdmin()||currentUser?.uid!==ADMIN_UID)throw Error('관리자 전용입니다.');if(equipmentDraftSaving)return;
 if($('eqName').value.trim()||equipmentDraftEdit>=0)queueEquipmentDraft();
 if(!equipmentDrafts.length)throw Error('등록할 장비를 먼저 담아 주세요.');
 equipmentDrafts.forEach(validateEquipmentDraft);
 if(equipmentDrafts.some(x=>equipment.some(e=>equipmentIdentity(e)===equipmentIdentity(x)&&!equipmentDraftRefs?.some(ref=>ref.id===e.id))))throw Error('기존 목록과 중복된 장비가 있습니다. 목록을 수정해 주세요.');
 if(!equipmentDraftRefs)equipmentDraftRefs=equipmentDrafts.map(()=>doc(eqCol()));
 equipmentDraftSaving=true;const button=$('equipmentDraftSave');button.disabled=true;button.textContent='전체 장비 등록 중...';$('equipmentDraftForm').querySelectorAll('input,select,button').forEach(x=>x.disabled=true);
 try{
  // Stable document IDs make a retry safe even if the first response was interrupted.
  const existing=await Promise.all(equipmentDraftRefs.map(ref=>getDoc(ref)));
  const batch=writeBatch(db);let writes=0;
  for(let i=0;i<equipmentDrafts.length;i++){
   if(existing[i].exists())continue;
   batch.set(equipmentDraftRefs[i],{...equipmentDrafts[i],loaned:0,repairing:0,createdAt:serverTimestamp(),updatedAt:serverTimestamp()});writes++;
  }
  if(writes)await batch.commit();const count=equipmentDrafts.length;equipmentDrafts=[];equipmentDraftRefs=null;closeModal();alert(`${count}종 장비를 한 번에 등록했습니다.`);
 }finally{equipmentDraftSaving=false;if($('equipmentDraftSave')){button.disabled=false;button.textContent='목록 전체 등록';$('equipmentDraftForm').querySelectorAll('input,select,button').forEach(x=>x.disabled=false);}}
}
document.addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b||equipmentDraftSaving)return;
 if(b.dataset.draftEdit!==undefined){
  const i=Number(b.dataset.draftEdit),x=equipmentDrafts[i];if(!x)return;
  if($('eqName').value.trim()&&!confirm('현재 입력 중인 내용을 바꾸고 목록 장비를 수정할까요?'))return;
  equipmentDraftEdit=i;for(const [id,key] of Object.entries({eqName:'name',eqCategory:'category',eqModel:'model',eqTotal:'total',eqTags:'searchTags',eqNote:'note'}))$(id).value=x[key];
  $('eq-unit').value=unitSnapshot(x).unit;$('eq-unitsPerBox').value=unitSnapshot(x).unitsPerBox;bindUnitFields('eq-','eqTotal');
  $('equipmentDraftAdd').textContent='목록 수정 완료';show('equipmentDraftCancel',true);$('eqName').focus();
 }
 if(b.dataset.draftRemove!==undefined){const i=Number(b.dataset.draftRemove);if(equipmentDraftEdit===i)resetEquipmentDraftForm();else if(equipmentDraftEdit>i)equipmentDraftEdit--;equipmentDrafts.splice(i,1);equipmentDraftRefs=null;renderEquipmentDrafts();}
});

function maintenanceActor(){return {uid:currentUser?.uid,isAdmin:isAdmin(),teamId,name:isAdmin()?'관리자':member?.displayName||teamName};}
function openRepairQuantity(id){
 if(!isAdmin())return alert('관리자 전용입니다.');const e=equipment.find(x=>x.id===id);if(!e)return;
 modal(`${esc(e.name)} · 수리 수량 지정`,`<form id="repairQuantityForm"><p class="notice">수리 중인 전체 수량을 지정하세요. 수리 수량은 가용 재고에서 제외됩니다. 정상 복구된 장비는 수량을 줄여 반영하세요.</p><p class="meta">${unitHint(e)} · 고장·수리는 EA 기준입니다.</p>${field('수리 중 수량 (EA)','maintenanceQty','0','number',repairQtyFor(id),true)}<p class="meta">대여 ${quantityText(borrowedQtyFor(id),e)} · 고장 입고 ${warehouseBrokenQtyFor(id)+'EA'}<br>신고에서 수리 접수한 ${(Number(e.reportRepairing||0)*packSize(e)+Number(e.reportRepairingEa||0))+'EA'}는 해당 신고에서 ‘수리 완료’로 처리해 주세요.</p><button type="submit">수리 수량 저장</button></form>`);
 $('maintenanceQty').min=String(e.unit==='BOX'?Number(e.reportRepairing||0)*packSize(e)+Number(e.reportRepairingEa||0):Number(e.reportRepairing||0));if(!untracked(id))$('maintenanceQty').max=String(Math.max(0,(Number(e.total||0)-borrowedQtyFor(id))*packSize(e)-warehouseBrokenQtyFor(id)));
 $('repairQuantityForm').onsubmit=async event=>{event.preventDefault();const button=event.submitter;if(!$('maintenanceQty').value.trim())return alert('수량을 입력해 주세요.');button.disabled=true;try{await setRepairQuantity(maintenanceApi,db,id,Number($('maintenanceQty').value),maintenanceActor());showEquipmentDetail(id);}catch(err){alert('수량 저장 실패: '+err.message);}finally{button.disabled=false;}};
}
function openDamageReport(equipmentId,selectedLoan=''){
 const options=activeLoans().filter(l=>l.equipmentId===equipmentId&&canReportDamage(l)&&damageEa(l)<loanEa(l));
 if(!options.length)return alert('신고 가능한 본인 또는 같은 팀의 대여 장비가 없습니다.');
 modal('현장 장비 고장 신고',`<form id="damageReportForm"><div class="notice">신고한 장비는 반납 전까지 대여 상태를 유지합니다. 고장 수량을 중복 차감하지 않으며, 고장·수리 수량은 라이트 낱개(EA)로 입력합니다. 반납하면 고장 EA만 정상 재고에서 제외됩니다.</div><div class="field"><label for="damageLoan">대여 기록</label><select id="damageLoan">${options.map(l=>`<option value="${esc(l.id)}" ${l.id===selectedLoan?'selected':''}>${esc(l.team||'팀 미입력')} · ${esc(l.equipmentName)} · 대여 ${loanQuantityText(l.quantity,l)} · 신고 가능 ${loanEa(l)-damageEa(l)}EA</option>`).join('')}</select></div>${field('고장 수량','damageQuantity','1','number',1,true)}<div class="field"><label for="damageSymptom">고장 증상 *</label><textarea id="damageSymptom" rows="3" maxlength="1000" required placeholder="예: 전원 불량, 점등 중 꺼짐"></textarea></div><button type="submit">고장 신고</button></form>`);
 const refresh=()=>{const l=options.find(x=>x.id===$('damageLoan').value);$('damageQuantity').closest('.field').querySelector('label').textContent='고장 수량 (EA) *';const max=loanEa(l)-damageEa(l);$('damageQuantity').min='1';$('damageQuantity').max=String(max);if(Number($('damageQuantity').value)>max)$('damageQuantity').value=String(max);};$('damageLoan').onchange=refresh;refresh();
 $('damageReportForm').onsubmit=async event=>{event.preventDefault();const button=event.submitter;button.disabled=true;try{await submitDamageReport(maintenanceApi,db,$('damageLoan').value,Number($('damageQuantity').value),$('damageSymptom').value,maintenanceActor());showEquipmentDetail(equipmentId);alert('고장 신고를 등록했습니다. 관리자 화면에서도 확인할 수 있습니다.');}catch(err){alert('고장 신고 실패: '+err.message);}finally{button.disabled=false;}};
}
document.addEventListener('click',async event=>{
 const button=event.target.closest('button');if(!button)return;
 try{
  if(button.dataset.repairQuantity)openRepairQuantity(button.dataset.repairQuantity);
  if(button.dataset.reportDamageLoan){const l=loans.find(x=>x.id===button.dataset.reportDamageLoan);if(l)openDamageReport(l.equipmentId,l.id);}
  if(button.dataset.damageTransition){
   const state=button.dataset.damageTransition,label={repairing:'수리 접수',completed:'수리 완료',cancelled:'신고 취소'}[state];
   if(!confirm(state==='cancelled'?'이 고장 신고를 취소할까요? 해당 신고 수량만 해제되며 대여 상태는 유지됩니다.':`${label} 처리할까요?`))return;
   button.disabled=true;try{const result=await transitionDamageReport(maintenanceApi,db,button.dataset.damageId,state,maintenanceActor());showEquipmentDetail(result.equipmentId);}finally{button.disabled=false;}
  }
 }catch(err){alert('처리 실패: '+err.message);}
});

document.addEventListener('click',event=>{const b=event.target.closest('[data-classify-loan]');if(b&&isAdmin())editLoanClassification(b.dataset.classifyLoan);});
