export function patchLoanExtensionRules(source){
 if(source.includes('// LNS_LOAN_EXTENSION_V1'))return source;
 const anchor='match /company/main/loans/{loanId} {';
 const marker='match /company/main/availabilityLocks/{equipmentId} {';
 if(source.split(anchor).length!==2||source.split(marker).length!==2)throw Error('Unexpected loan/lock rules.');
 source=source.replace(anchor,()=>`// LNS_LOAN_EXTENSION_V1
 function lnsValidExtension(before,after) {
  return after.dueDate != before.get('dueDate','') && before.status == 'active'
   && (admin() || activeTeamMember()) && loanOwner(before)
   && after.diff(before).affectedKeys().hasOnly(['dueDate','previousDueDate','extendedBy','extendedAt','updatedAt'])
   && after.dueDate is string && after.dueDate.matches('^[0-9]{4}-[0-9]{2}-[0-9]{2}$')
   && after.dueDate > before.get('dueDate','') && after.dueDate >= before.loanDate
   && after.previousDueDate == before.get('dueDate','') && after.extendedBy == request.auth.uid
   && after.extendedAt == request.time && after.updatedAt == request.time;
 }
 ${anchor}
 `);
 // The active-team check already proves the matching profile team exists and is active.
 // Avoid evaluating it twice in the ownership predicate (Firestore expression limit).
 source=source.replace("function loanOwner(loan) { return admin() || (activeTeamMember() && (loan.ownerUid == request.auth.uid || sameTeam(loan))); }", "function loanOwner(loan) { return admin() || (activeTeamMember() && (loan.ownerUid == request.auth.uid || (loan.get('teamId', '') != '' && profile().get('teamId', '') == loan.teamId))); }");
 source=source.replace("allow update: if (admin() || member()) && (", "allow update: if request.resource.data.get('dueDate','') == resource.data.get('dueDate','') && (admin() || member()) && (");
 const end="allow delete: if admin() && resource.data.status == 'returned' && resource.data.get('damageQuantity',0) == 0 && resource.data.get('damageEa',0) == 0;";
 if(!source.includes(end))throw Error('Loan update anchor missing');
 source=source.replace(end,end+"\n allow update: if request.resource.data.get('dueDate','') != resource.data.get('dueDate','') && lnsValidExtension(resource.data,request.resource.data) && lnsCapacityLockMatches(resource.data.equipmentId,loanId,'extension');");
 source=source.replace(marker,()=>`${marker}
 function extension() {
  let d=request.resource.data; let p=loanPath(d.operationId);
  return d.operationType == 'extension' && get(p).data.equipmentId == equipmentId
   && lnsValidExtension(get(p).data,getAfter(p).data);
 }
 `);
 source=source.replace("request.resource.data.operationType in ['loan','reservation']","request.resource.data.operationType in ['loan','reservation','extension']");
 source=source.replace('&& operation();','&& (request.resource.data.operationType == \'extension\' ? extension() : operation());');
 return source;
}
