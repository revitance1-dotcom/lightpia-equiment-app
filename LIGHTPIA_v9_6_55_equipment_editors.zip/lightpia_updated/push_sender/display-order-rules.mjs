import fs from 'node:fs';
export function patchDisplayOrderRules(source){
 if(source.includes('LNS_DISPLAY_ORDER_V1'))return source;
 if(/match\s+\/company\/main\/appSettings/.test(source))throw Error('Existing display preference rules require review.');
 const match=source.match(/match\s+\/databases\/\{database\}\/documents\s*\{/);
 if(!match)throw Error('Unexpected rules structure.');
 const at=match.index+match[0].length;
 return source.slice(0,at)+'\n'+fs.readFileSync(new URL('./display-order.rules',import.meta.url),'utf8')+source.slice(at);
}
