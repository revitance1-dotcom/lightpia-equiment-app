import {normalizeEquipmentTags} from '../www/equipment-search.js';
export function correct18kTags(name,value){
 const key=String(name||'').toUpperCase().replace(/\s+/g,'');
 if(!['18KCOM','18KPAR'].includes(key))return value;
 let tags=normalizeEquipmentTags(value).split(' ').filter(Boolean);
 if(key==='18KCOM')return normalizeEquipmentTags([...tags,'#sun','#컴'].join(' '));
 return tags.filter(t=>!['#sun','#컴'].includes(t.toLocaleLowerCase())).join(' ');
}

export async function apply18kTagCorrection(db,timestamp){
const marker=db.doc('appMigrations/equipment-tags-v9630');
if((await marker.get()).exists){console.log('Equipment tag correction already applied.');return;}
const snapshot=await db.collection('company/main/equipment').get();
const targets=snapshot.docs.filter(d=>['18KCOM','18KPAR'].includes(String(d.data().name||'').toUpperCase().replace(/\s+/g,'')));
// Refuse ambiguous names instead of editing an unintended record.
for(const name of ['18KCOM','18KPAR'])if(targets.filter(d=>String(d.data().name).toUpperCase().replace(/\s+/g,'')===name).length!==1)throw Error('Expected one equipment record for each named correction target.');
await db.runTransaction(async tx=>{
 const existing=await tx.get(marker);if(existing.exists)return;
 const records=await Promise.all(targets.map(d=>tx.get(d.ref))),audit=[];
 for(const snap of records){
  if(!snap.exists)throw Error('Equipment changed during correction');
  const data=snap.data(),before=data.searchTags||'',after=correct18kTags(data.name,before);
  audit.push({equipmentId:snap.id,name:data.name,before,after});
  if(after!==before)tx.update(snap.ref,{searchTags:after,updatedAt:timestamp()});
 }
 // Preserve original tags in a server-only audit document; run this correction once.
 tx.create(marker,{records:audit,completedAt:timestamp()});
});
console.log('Applied and audited the two requested equipment tag corrections.');

}
