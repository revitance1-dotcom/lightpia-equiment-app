const fs=require('fs'),assert=require('assert');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing');
const api=require('firebase/firestore');
(async()=>{
 if(!process.env.FIRESTORE_EMULATOR_HOST)throw Error('Emulator required');
 const model=await import('../www/maintenance-model.js'),ADMIN=model.MAINTENANCE_ADMIN_UID;
 const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8')}});
 try{
 await env.clearFirestore();const actor={uid:ADMIN,isAdmin:true,teamId:'admin',name:'관리자'},owner={uid:'owner',isAdmin:false,teamId:'A',name:'직원'},colleague={uid:'colleague',isAdmin:false,teamId:'A',name:'같은 팀'},outsider={uid:'outsider',isAdmin:false,teamId:'B',name:'다른 팀'};
 const a=env.authenticatedContext(ADMIN).firestore(),o=env.authenticatedContext('owner').firestore(),c=env.authenticatedContext('colleague').firestore(),x=env.authenticatedContext('outsider').firestore();
 const eq=(db,id)=>api.doc(db,'company/main/equipment',id),loan=(db,id)=>api.doc(db,'company/main/loans',id),report=(db,id)=>api.doc(db,'company/main/damageReports',id);
 await env.withSecurityRulesDisabled(async ctx=>{const db=ctx.firestore();for(const id of ['A','B'])await api.setDoc(api.doc(db,'teams',id),{name:id,active:true,projectId:'project'});await api.setDoc(api.doc(db,'projects','project'),{name:'작품',active:true});for(const u of [owner,colleague,outsider])await api.setDoc(api.doc(db,'members',u.uid),{role:'team',active:true,teamId:u.teamId,teamName:u.teamId});});
 async function seed(id,qty=4,total=10){await env.withSecurityRulesDisabled(async ctx=>{const db=ctx.firestore();await api.setDoc(eq(db,id),{name:'M90',total,loaned:qty,repairing:0});await api.setDoc(loan(db,id),{equipmentId:id,equipmentName:'M90',quantity:qty,ownerUid:'owner',teamId:'A',team:'A',status:'active'});});}
 const state=async id=>model.stockState((await api.getDoc(eq(a,id))).data());
 async function returnIt(db,id,legacy=false){return api.runTransaction(db,async tx=>{const lr=loan(db,id),ls=await tx.get(lr),er=eq(db,id),es=await tx.get(er);tx.update(er,legacy?{loaned:es.data().loaned-ls.data().quantity,lastLoanId:id}:model.maintenanceReturnFields(es.data(),ls.data(),id));tx.update(lr,{status:'returned',returnedAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});});}
 await seed('one');await assertSucceeds(model.setRepairQuantity(api,a,'one',2,actor));assert.equal((await state('one')).available,4);
 await assertFails(api.updateDoc(eq(o,'one'),{repairing:3}));await assert.rejects(model.setRepairQuantity(api,o,'one',1,owner));await assert.rejects(model.setRepairQuantity(api,a,'one',7,actor));await assert.rejects(model.setRepairQuantity(api,a,'one',-1,actor));
 const r1=await assertSucceeds(model.submitDamageReport(api,o,'one',2,'점등 불량',owner));assert.equal((await state('one')).available,4);assert.equal((await api.getDoc(loan(a,'one'))).data().damageQuantity,2);
 const r2=await assertSucceeds(model.submitDamageReport(api,c,'one',1,'전원 불량',colleague));await assert.rejects(model.submitDamageReport(api,x,'one',1,'위조',outsider));await assert.rejects(model.submitDamageReport(api,o,'one',2,'초과',owner));await assert.rejects(model.submitDamageReport(api,o,'one',0,'0개',owner));await assert.rejects(model.submitDamageReport(api,o,'one',1,'',owner));
 await assertFails(api.updateDoc(loan(o,'one'),{damageQuantity:4,lastDamageId:'forged',updatedAt:api.serverTimestamp()}));await assertFails(api.updateDoc(report(o,r1.reportId),{status:'cancelled',reviewedBy:'owner',updatedAt:api.serverTimestamp()}));
 await assert.rejects(model.transitionDamageReport(api,a,r1.reportId,'repairing',actor));
 await assertFails(returnIt(o,'one',true));assert.equal((await api.getDoc(loan(a,'one'))).data().status,'active');
 await assertSucceeds(returnIt(o,'one'));assert.deepEqual([ (await state('one')).loaned,(await state('one')).brokenStock,(await state('one')).available],[0,3,5]);await assertFails(api.deleteDoc(loan(a,'one')));
 await assertSucceeds(model.transitionDamageReport(api,a,r1.reportId,'repairing',actor));assert.deepEqual([(await state('one')).repairing,(await state('one')).reportRepairing,(await state('one')).brokenStock,(await state('one')).available],[4,2,1,5]);await assert.rejects(model.setRepairQuantity(api,a,'one',1,actor));
 await assertFails(api.updateDoc(eq(a,'one'),{brokenStock:0}));
 await assertSucceeds(model.transitionDamageReport(api,a,r1.reportId,'completed',actor));assert.equal((await state('one')).available,7);await model.transitionDamageReport(api,a,r1.reportId,'completed',actor);assert.equal((await state('one')).available,7);
 await assertSucceeds(model.transitionDamageReport(api,a,r2.reportId,'cancelled',actor));assert.equal((await state('one')).available,8);assert.equal((await api.getDoc(loan(a,'one'))).data().damageQuantity,0);await assertSucceeds(model.setRepairQuantity(api,a,'one',0,actor));assert.equal((await state('one')).available,10);await assertSucceeds(api.deleteDoc(loan(a,'one')));
 await seed('onsite',2);const onsite=await model.submitDamageReport(api,o,'onsite',1,'현장 확인',owner);await assertSucceeds(model.transitionDamageReport(api,a,onsite.reportId,'cancelled',actor));assert.equal((await state('onsite')).available,8);assert.equal((await api.getDoc(loan(a,'onsite'))).data().damageQuantity,0);
 await seed('race',3);const race=await Promise.allSettled([model.submitDamageReport(api,o,'race',2,'동시 신고 1',owner),model.submitDamageReport(api,c,'race',2,'동시 신고 2',colleague)]);assert.equal(race.filter(x=>x.status==='fulfilled').length,1);assert.equal((await api.getDoc(loan(a,'race'))).data().damageQuantity,2);
 async function forgedCancel(db,uid,reportId){return api.runTransaction(db,async tx=>{
  const rr=report(db,reportId),rs=await tx.get(rr),r=rs.data(),lr=loan(db,r.loanId),ls=await tx.get(lr),l=ls.data(),er=eq(db,r.equipmentId),es=await tx.get(er),e=es.data();
  if(l.status==='returned')tx.update(er,r.status==='repairing'?{repairing:e.repairing-r.quantity,reportRepairing:e.reportRepairing-r.quantity,lastMaintenanceId:reportId,updatedAt:api.serverTimestamp()}:{brokenStock:e.brokenStock-r.quantity,lastMaintenanceId:reportId,updatedAt:api.serverTimestamp()});
  tx.update(lr,{damageQuantity:l.damageQuantity-r.quantity,lastDamageId:reportId,updatedAt:api.serverTimestamp()});
  tx.update(rr,{status:'cancelled',reviewedBy:uid,updatedAt:api.serverTimestamp()});
 });}
 for(const stage of ['field','returned','repairing']){
  const id='cancel-'+stage;await seed(id,3);const r=await model.submitDamageReport(api,o,id,1,'취소 권한 확인',owner);
  if(stage!=='field')await returnIt(o,id);
  if(stage==='repairing')await model.transitionDamageReport(api,a,r.reportId,'repairing',actor);
  await assert.rejects(model.transitionDamageReport(api,c,r.reportId,'cancelled',colleague));
  await assertFails(forgedCancel(c,'colleague',r.reportId));await assertFails(forgedCancel(x,'outsider',r.reportId));
  await assertFails(api.updateDoc(report(o,r.reportId),{reporterUid:'colleague'}));
  await assert.rejects(model.transitionDamageReport(api,o,r.reportId,'completed',owner));
  await assertSucceeds(model.transitionDamageReport(api,o,r.reportId,'cancelled',owner));
  await model.transitionDamageReport(api,o,r.reportId,'cancelled',owner);
  assert.equal((await api.getDoc(report(a,r.reportId))).data().reviewedBy,'owner');
  assert.equal((await api.getDoc(loan(a,id))).data().damageQuantity,0);
  assert.deepEqual([(await state(id)).repairing,(await state(id)).brokenStock,(await state(id)).available],[0,0,stage==='field'?7:10]);
 }
 await seed('admin-cancel',2);const ar=await model.submitDamageReport(api,c,'admin-cancel',1,'다른 신고자',colleague);await returnIt(o,'admin-cancel');await model.transitionDamageReport(api,a,ar.reportId,'repairing',actor);await assertSucceeds(model.transitionDamageReport(api,a,ar.reportId,'cancelled',actor));assert.equal((await state('admin-cancel')).available,10);
 await seed('moved-team',2);const mr=await model.submitDamageReport(api,o,'moved-team',1,'팀 변경 후 본인 신고',owner);await returnIt(o,'moved-team');
 await env.withSecurityRulesDisabled(async ctx=>{const db=ctx.firestore();await api.updateDoc(api.doc(db,'members','owner'),{teamId:'',teamName:'대기 직원'});});
 await assertSucceeds(model.transitionDamageReport(api,o,mr.reportId,'cancelled',{...owner,teamId:''}));
 await seed('unknown',2,0);await assertSucceeds(model.setRepairQuantity(api,a,'unknown',100,actor));assert.equal((await state('unknown')).repairing,100);
 console.log('PASS report cancellation: reporter-only (including same-team denial), raw forged transactions denied, field/returned/repairing stock restored once, administrator cancels any reporter, immutable author, team change, no employee repair completion');
 console.log('PASS maintenance: administrator repair counts, staff/same-team reporting, outsider denial, concurrent overreport protection, no double deduction, damaged return quarantine, repair intake/completion, onsite/returned cancellation, immutable stock, idempotence, unresolved history protection, untracked stock');
 }finally{await env.cleanup();}
})().catch(e=>{console.error(e);process.exit(1)});
