V9.2 Studio UI preview
- Redesigned cinematic dashboard and navigation
- Click active teams for current loan groups
- Booking/project lifecycle NOT implemented yet
- Existing V9.1 Firestore rules and operations unchanged
- Back up before installing; APK and Firebase not tested
