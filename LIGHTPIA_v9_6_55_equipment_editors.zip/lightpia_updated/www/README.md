# LnS 조명장비 재고관리 (개인용 웹앱 / PWA)

기존 `lightpia_equipment_app.zip`을 바탕으로 개인용으로 정리한 버전입니다. 직원 계정이나 공동 사용자 승인 없이 Firebase 익명 인증을 사용하며, 로그인한 익명 UID별로 Firestore 데이터를 분리합니다.

## 기능
- 장비 등록/수정/삭제 및 장비별 상세 화면: 전체/가용/대여/수리 수량 자동 집계
- 팀별 대여 수량 집계 및 팀별 활성 대여 기록
- 수리 이력 관리: 수리 수량, 고장 증상, 업체, 날짜, 메모, 완료 처리
- 대여 팀, 담당자, 수량, 대여일, 반납 예정일 기록
- 반납 처리 및 반납 지연 표시
- 검색/필터, 대시보드
- Firestore 실시간 동기화 및 브라우저 IndexedDB 오프라인 캐시
- JSON 전체 백업 및 가져오기, CSV 내보내기
- 설치 가능한 PWA 기본 구성

## 최초 연결
1. Firebase Console에서 본인 Google 계정으로 프로젝트를 생성합니다.
2. Project settings → General → Your apps에서 Web App을 추가하고 Firebase 설정 JSON을 복사합니다.
3. Authentication → Sign-in method에서 **Anonymous** 로그인을 활성화합니다.
4. Firestore Database를 생성합니다.
5. Firestore Rules에 `firestore.rules` 내용을 붙여넣고 게시합니다.
6. 앱을 HTTPS로 호스팅합니다. 예: Firebase Hosting.
7. 앱을 열어 `온라인 저장소 연결 설정`에 Firebase Web App JSON을 입력합니다.
8. 앱이 연결되면 장비를 등록합니다. 직원 계정/이메일/비밀번호를 만들 필요가 없습니다.

## 호스팅
이 앱은 PWA이며 ZIP을 직접 APK처럼 설치하는 방식은 아닙니다. Firebase Hosting 등 HTTPS 정적 호스팅에 폴더 내용을 올린 뒤 Android Chrome에서 주소를 열고 메뉴 → 홈 화면에 추가를 선택하세요.

## 백업/복원
- 설정 탭의 `전체 백업 다운로드 (JSON)`은 장비, 대여 기록 및 수리 이력을 파일로 내보냅니다.
- `JSON 백업 가져오기`는 파일 안의 항목을 현재 저장소에 병합합니다. 백업에 포함된 동일 ID 항목은 갱신되고, 백업에 없는 기존 항목은 유지됩니다.
- CSV는 스프레드시트에서 확인하기 위한 목록 내보내기입니다. 복원용으로는 JSON을 사용하세요.
- 익명 인증 ID는 브라우저 데이터에 연결됩니다. 앱 데이터/브라우저 저장소를 지우면 원래 클라우드 공간에 자동 재접속하지 못할 수 있습니다. 따라서 JSON 백업을 별도 위치에 보관하세요. 다른 기기로 옮길 때는 JSON 백업을 가져오면 됩니다.

## 보안/운영 참고
- Firestore Rules는 로그인한 익명 UID가 자기 `users/{uid}/...` 경로에만 접근하도록 제한합니다.
- Firebase Web App 설정은 클라이언트용 설정값입니다. 보안은 반드시 Firestore Rules로 적용해야 합니다.
- Firebase 익명 ID를 잃어버린 경우를 대비해 JSON 백업을 정기적으로 보관하세요. 이 버전은 여러 기기 간 자동 동기화를 위해 Google 로그인 계정을 연결하지는 않습니다.
- Firestore와 Authentication은 Firebase 사용량/요금 정책이 적용될 수 있습니다.
