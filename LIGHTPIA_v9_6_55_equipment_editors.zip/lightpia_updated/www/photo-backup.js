// Equipment photos are backed up separately so restoring images never changes stock.
const FORMAT='lightpia-equipment-photo-backup',VERSION=1,PART_SIZE=50;
const validId=id=>typeof id==='string'&&id.length>0&&id.length<=1500&&!id.includes('/')&&!/^\.{1,2}$/.test(id)&&!/^__.*__$/.test(id);
const validImage=(data,max)=>typeof data==='string'&&data.length<=max&&/^data:image\/jpeg;base64,[A-Za-z0-9+/]+={0,2}$/.test(data);
export function inspectPhotoBackup(data){
 if(!data||data.format!==FORMAT||data.version!==VERSION||!Array.isArray(data.photos)||!data.photos.length||data.photos.length>PART_SIZE)throw Error('사진 백업 JSON 형식이 아닙니다. 사진 백업 버튼으로 저장한 파일을 선택해 주세요.');
 const seen=new Set();
 for(const p of data.photos){
  if(!p||!validId(p.equipmentId)||seen.has(p.equipmentId))throw Error('사진 백업에 잘못된 장비 ID 또는 중복 장비가 있습니다.');
  seen.add(p.equipmentId);
  if(!validImage(p.thumbnail,24000)||!validImage(p.image,240000))throw Error('사진 데이터가 손상되었거나 허용 크기를 초과했습니다.');
  if(p.equipmentName!==undefined&&(typeof p.equipmentName!=='string'||p.equipmentName.length>500))throw Error('장비 이름 형식을 확인해 주세요.');
 }
 return data.photos;
}
export function createPhotoBackup(ui){
 const {api}=ui;let exporting=false,restoring=false,inspecting=false,restoreSession=null;
 const col=name=>api.collection(ui.db(),'company/main/'+name),ref=(name,id)=>api.doc(ui.db(),'company/main/'+name,id);
 function admin(){if(!ui.isAdmin())throw Error('사진 백업·복원은 관리자만 사용할 수 있습니다.');}
 function status(message){const el=document.getElementById('photoBackupStatus');if(el)el.textContent=message;}
 function controls(){for(const id of ['exportPhotoBackupBtn','importPhotoBackupBtn']){const el=document.getElementById(id);if(el)el.disabled=exporting||restoring||inspecting;}}
 function locked(){return exporting||restoring||inspecting;}
 async function exportPhotos(){
  admin();if(locked())return;exporting=true;controls();let files=0,total=0;
  try{
   let cursor=null;
   const stamp=new Date().toISOString(),tag=stamp.replace(/[^0-9]/g,'').slice(0,17);
   do{
    admin();status(`사진 백업 준비 중 · ${total}장 처리`);
    const clauses=[api.orderBy(api.documentId()),api.limit(PART_SIZE)];if(cursor)clauses.push(api.startAfter(cursor));
    const page=await api.getDocsFromServer(api.query(col('equipmentPhotos'),...clauses));if(!page.docs.length)break;
    const detailMap=new Map();
    for(let offset=0;offset<page.docs.length;offset+=25){
     const ids=page.docs.slice(offset,offset+25).map(d=>d.id);
     const details=await api.getDocsFromServer(api.query(col('equipmentPhotoDetails'),api.where(api.documentId(),'in',ids)));
     for(const d of details.docs)detailMap.set(d.id,d.data());
    }
    const photos=page.docs.map(d=>{const t=d.data(),full=detailMap.get(d.id),eq=ui.equipment().find(e=>e.id===d.id);if(!full||!eq)throw Error(`장비 ${eq?.name||d.id}: 연결된 장비 또는 상세 사진이 없습니다. 사진 등록 상태를 확인해 주세요.`);if(t.equipmentId!==d.id||full.equipmentId!==d.id)throw Error('사진 연결 정보를 확인해 주세요.');const stamp=v=>v?.seconds+':'+v?.nanoseconds;if(stamp(t.updatedAt)!==stamp(full.updatedAt))throw Error('사진이 변경 중입니다. 잠시 후 다시 백업해 주세요.');return {equipmentId:d.id,equipmentName:String(eq.name||'').slice(0,500),thumbnail:t.thumbnail,image:full.image};});
    const data={format:FORMAT,version:VERSION,exportedAt:stamp,part:files+1,photos};inspectPhotoBackup(data);
    const filename=`장비사진_백업_${tag}_${String(files+1).padStart(3,'0')}.json`;
    status(`${files+1}번 사진 백업 · ${photos.length}장 · 저장 위치를 선택해 주세요.`);
    const result=await ui.download(filename,new Blob([JSON.stringify(data)],{type:'application/json;charset=utf-8'}));
    if(result===false){status(`사진 백업 저장을 취소했습니다. 앞서 저장한 ${files}개 파일은 사용할 수 있습니다.`);return;}
    total+=photos.length;files++;cursor=page.docs.at(-1);
    if(page.docs.length<PART_SIZE)break;
   }while(true);
   status(total?`사진 ${total}장 · 백업 ${files}개 파일 저장 절차를 마쳤습니다. 파일 앱에서 저장된 파일을 확인해 주세요.`:'등록된 장비 사진이 없습니다.');
  }catch(e){status(`사진 백업 중단: ${e.message}${files?` · 앞서 저장한 ${files}개 파일은 사용할 수 있습니다.`:''}`);}
  finally{exporting=false;controls();}
 }
 async function importPhotos(file){
  if(!file)return;admin();if(locked())return;inspecting=true;controls();
  try{
   if(file.size>16*1024*1024)throw Error('16MB 이하의 사진 백업 파일을 선택해 주세요. 여러 파일은 번호순으로 하나씩 가져오세요.');
   const data=JSON.parse(await file.text()),photos=inspectPhotoBackup(data);
   const rows=photos.map(p=>({photo:p,equipment:ui.equipment().find(e=>e.id===p.equipmentId)}));
   const connected=rows.filter(r=>r.equipment),missing=rows.filter(r=>!r.equipment);
   const session={running:false};restoreSession=session;
   ui.modal('장비 사진 복원',`<div class="notice">재고 수량과 대여·반납 기록은 변경하지 않습니다. 장비 ID가 같은 항목에만 사진을 연결합니다.</div><p class="meta">파일: ${ui.esc(file.name)}<br>백업일: ${ui.esc(data.exportedAt||'미기록')} · ${ui.esc(data.part||1)}번 파일<br>사진 ${photos.length}장 · 연결 장비 ${connected.length}종 · 장비 없음 ${missing.length}종</p>${missing.length?'<div class="notice warning">장비가 없는 사진은 건너뜁니다. 먼저 기존 장비 백업을 가져온 뒤 이 사진 파일을 다시 가져오세요.</div>':''}<label class="photo-backup-option"><input type="checkbox" id="replaceBackupPhotos"> 기존 사진도 백업 사진으로 교체</label><p class="meta">선택하지 않으면 현재 사진이 있는 장비는 건너뜁니다. 다른 장비 ID나 이름만 같은 장비에는 적용하지 않습니다.</p><p id="photoRestoreStatus" class="meta" role="status" aria-live="polite"></p><button id="restoreEquipmentPhotos" ${connected.length?'':'disabled'}>사진 복원 실행</button>`);
   const button=document.getElementById('restoreEquipmentPhotos'),option=document.getElementById('replaceBackupPhotos'),report=document.getElementById('photoRestoreStatus');
   button.onclick=async()=>{
    if(session.running||locked())return;admin();const replace=option.checked;
    if(!confirm(`연결된 장비 ${connected.length}종의 사진을 복원할까요?\n${replace?'현재 사진을 백업 사진으로 교체합니다.':'현재 사진이 있으면 그대로 유지합니다.'}\n재고와 대여 기록은 변경하지 않습니다.`))return;
    session.running=true;restoring=true;button.disabled=true;option.disabled=true;controls();
    let restored=0,existing=0,unmatched=missing.length;const failed=[];
    try{
     for(const {photo:p,equipment:e}of connected){
      admin();report.textContent=`사진 복원 중 · ${restored+existing+failed.length}/${connected.length}종`;
      try{
       const outcome=await api.runTransaction(ui.db(),async tx=>{
        const eq=await tx.get(ui.eqDoc(p.equipmentId));if(!eq.exists())return 'missing';
        const tr=ref('equipmentPhotos',p.equipmentId),dr=ref('equipmentPhotoDetails',p.equipmentId);
        const thumb=await tx.get(tr),full=await tx.get(dr);
        if(!replace&&(thumb.exists()||full.exists()))return 'existing';
        const base={equipmentId:p.equipmentId,updatedBy:ui.uid(),updatedAt:api.serverTimestamp()};
        tx.set(tr,{...base,thumbnail:p.thumbnail});tx.set(dr,{...base,image:p.image});return 'restored';
       });
       if(outcome==='restored')restored++;else if(outcome==='existing')existing++;else unmatched++;
      }catch(e){failed.push(`${p.equipmentName||p.equipmentId}: ${e.message}`);}
     }
     report.textContent=`복원 완료 · 사진 ${restored}장 · 기존 사진 유지 ${existing}장 · 장비 없음 ${unmatched}장 · 실패 ${failed.length}장${failed.length?'\n'+failed.slice(0,5).join('\n'):''}`;
     status(report.textContent);button.textContent=failed.length?'실패 항목 다시 시도':'사진 복원 완료';button.disabled=!failed.length;
    }catch(e){report.textContent=`복원 중단: ${e.message} · 처리된 사진 ${restored}장`;button.textContent='다시 시도';button.disabled=false;}
    finally{session.running=false;restoring=false;option.disabled=false;controls();}
   };
  }catch(e){alert('사진 백업 검사 실패: '+e.message);}
  finally{inspecting=false;controls();const input=document.getElementById('photoBackupFile');if(input)input.value='';}
 }
 document.getElementById('exportPhotoBackupBtn')?.addEventListener('click',()=>exportPhotos().catch(e=>alert(e.message)));
 document.getElementById('importPhotoBackupBtn')?.addEventListener('click',()=>{if(!ui.isAdmin())return alert('관리자 전용입니다.');document.getElementById('photoBackupFile').click();});
 document.getElementById('photoBackupFile')?.addEventListener('change',e=>importPhotos(e.target.files?.[0]).catch(e=>alert(e.message)));
 return {exportPhotos,importPhotos,beforeClose:()=>!restoring};
}
