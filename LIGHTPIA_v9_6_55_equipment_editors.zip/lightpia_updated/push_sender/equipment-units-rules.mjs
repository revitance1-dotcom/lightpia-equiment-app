import fs from 'node:fs';
export function patchEquipmentUnitsRules(source){
 if(source.includes('LNS_EQUIPMENT_UNITS_V1'))return source;
 const marker='function validQty(d) {';if(!source.includes(marker))throw Error('Missing quantity validation');
 source=source.replace(marker,fs.readFileSync(new URL('./equipment-units.rules',import.meta.url),'utf8')+'\n  '+marker);
 source=source.replace('return d.total is int && d.loaned is int','return lnsUnit(d) && d.total is int && d.loaned is int');
 const update='allow update: if (admin() || member()) && validQty(request.resource.data) && (';if(!source.includes(update))throw Error('Unexpected equipment update rules');source=source.replace(update,'allow update: if (admin() || member()) && validQty(request.resource.data) && lnsUnitChangeAllowed(resource.data,request.resource.data) && (');
 const start=source.indexOf('match /company/main/loans/{loanId}'),end=source.indexOf('match /company/main/reservations/',start);let loan=source.slice(start,end);
 const keys="'externalPerson','projectName'])";if(!loan.includes(keys))throw Error('Unexpected loan fields');loan=loan.replace(keys,"'externalPerson','projectName','unit','unitsPerBox']) && lnsUnit(request.resource.data) && lnsSameUnit(request.resource.data,get(eqPath(request.resource.data.equipmentId)).data)");source=source.slice(0,start)+loan+source.slice(end);
 const report="'quantity','symptom','status','createdAt','updatedAt'])";if(!source.includes(report))throw Error('Unexpected damage fields');source=source.replace(report,"'quantity','symptom','status','createdAt','updatedAt','unit','unitsPerBox']) && lnsUnit(request.resource.data) && lnsSameUnit(request.resource.data,get(loanPath(request.resource.data.loanId)).data)");
 return source;
}
