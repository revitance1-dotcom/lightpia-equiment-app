import {notificationKinds,safeNotificationTab} from './notification-model.js';
export function createNotifications(api){
 const {doc,collection,getDoc,setDoc,updateDoc,addDoc,onSnapshot,query,orderBy,limit,serverTimestamp,db,user,isAdmin,teams,escape:esc}=api;
 let uid='',prefs={enabled:false,kinds:{},scope:'team'},stops=[],items=[],device='',busy=false,pluginHandles=[];
 const root=document.createElement('div');root.id='notificationCenter';root.className='panel hidden';
 const key=()=>`lns-notifications:${uid}`;
 function say(s){const el=root.querySelector('[data-notify-status]');if(el)el.textContent=s;}
 function permission(){return window.Capacitor?.isNativePlatform?.()?'앱 알림':!('Notification' in window)?'이 브라우저는 푸시 알림을 지원하지 않습니다.':Notification.permission==='denied'?'휴대폰·브라우저 설정에서 이 사이트 알림을 허용해 주세요.':'아이폰은 홈 화면에 추가한 웹앱에서 알림을 켜 주세요.';}
 function draw(){
  root.innerHTML=`<h2>🔔 알림 설정</h2><label class="notify-row"><span><b>알림 받기</b><small>이 계정의 모든 기기에 적용</small></span><input type="checkbox" role="switch" data-notify-master ${prefs.enabled?'checked':''}></label><p class="meta" data-notify-status>${esc(permission())}</p><div class="notify-options">${Object.entries(notificationKinds).filter(([k])=>isAdmin()||!['loan','join'].includes(k)).map(([k,label])=>`<label class="notify-row"><span>${label}</span><input type="checkbox" role="switch" data-notify-kind="${k}" ${prefs.kinds[k]!==false?'checked':''} ${!prefs.enabled?'disabled':''}></label>`).join('')}<label class="notify-row"><span>팀 전체 업무 알림 받기<small>끄면 본인 신청 알림만 받습니다.</small></span><input type="checkbox" role="switch" data-notify-scope ${prefs.scope==='team'?'checked':''} ${!prefs.enabled?'disabled':''}></label></div><button type="button" class="secondary" data-notify-register>이 기기 알림 연결·다시 연결</button> <button type="button" class="secondary" data-notify-test>테스트 알림</button><details><summary>알림함 · 안 읽음 ${items.filter(x=>!x.read).length}건</summary><p class="meta">최근 50건 · 푸시를 꺼도 업무 알림은 여기서 확인할 수 있습니다.</p><div>${items.map(n=>`<button type="button" class="notify-message secondary" data-notify-open="${esc(n.id)}"><b>${n.read?'':'● '}${esc(n.title)}</b><span>${esc(n.body)}</span><small>${n.createdAt?.seconds?new Date(n.createdAt.seconds*1000).toLocaleString('ko-KR'):''}</small></button>`).join('')||'<p class="meta">새 알림이 없습니다.</p>'}</div></details>${isAdmin()?`<details><summary>직원에게 공지 보내기</summary><form data-notify-notice><label>수신 대상<select name="team"><option value="">전체 승인 직원</option>${teams().filter(t=>t.active!==false).map(t=>`<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('')}</select></label><label>제목<input name="title" maxlength="100" required></label><label>내용<textarea name="body" maxlength="2000" required></textarea></label><button type="submit">공지 발송</button><p class="meta">알림함에 저장되며, 푸시를 허용한 직원에게 발송됩니다. 예약 발송 작업 상황에 따라 지연될 수 있습니다.</p></form></details>`:''}`;
 }
 async function save(next){await setDoc(doc(db(),'notificationPreferences',uid),{...next,updatedAt:serverTimestamp()});prefs=next;localStorage.setItem(key(),JSON.stringify(next));draw();}
 async function register(){
  const owner=uid;if(!owner)throw Error('로그인 후 설정해 주세요.');
  const native=window.Capacitor?.isNativePlatform?.();let payload;
  if(native){
   const plugin=window.Capacitor?.Plugins?.PushNotifications;if(!plugin)throw Error('최신 APK를 설치해 주세요.');
   let p=await plugin.checkPermissions();if(p.receive!=='granted')p=await plugin.requestPermissions();if(p.receive!=='granted')throw Error('휴대폰 설정에서 앱 알림을 허용해 주세요.');
   const token=await new Promise(async(resolve,reject)=>{
    let timer;const handles=[];const done=async(err,value)=>{clearTimeout(timer);for(const h of handles)await h.remove();err?reject(err):resolve(value);};
    try{handles.push(await plugin.addListener('registration',x=>done(null,x.value)));handles.push(await plugin.addListener('registrationError',x=>done(Error(x.error||'등록 실패'))));timer=setTimeout(()=>done(Error('알림 등록 시간이 초과됐습니다. 다시 시도해 주세요.')),20000);await plugin.register();}catch(e){done(e);}
   });payload={ownerUid:owner,platform:'android',token,enabled:true};
  }else{
   if(!('serviceWorker' in navigator)||!('PushManager' in window)||!('Notification' in window))throw Error('지원 브라우저로 열어 주세요. 아이폰은 홈 화면에 추가 후 실행해 주세요.');
   // Permission must be requested directly from the switch/button gesture.
   const permission=await Notification.requestPermission();if(permission!=='granted')throw Error('휴대폰·브라우저 설정에서 알림을 허용해 주세요.');
   const config=await getDoc(doc(db(),'notificationConfig','public'));const publicKey=config.data()?.vapidPublicKey;if(!publicKey)throw Error('서버 알림 설정을 준비 중입니다. 잠시 후 다시 시도해 주세요.');
   const registration=await navigator.serviceWorker.ready;
   const decoded=atob(publicKey.replace(/-/g,'+').replace(/_/g,'/').padEnd(Math.ceil(publicKey.length/4)*4,'='));
   const subscription=await registration.pushManager.getSubscription()||await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:Uint8Array.from(decoded,c=>c.charCodeAt(0))});
   payload={ownerUid:owner,platform:'web',subscription:subscription.toJSON(),enabled:true};
  }
  if(uid!==owner)throw Error('계정이 변경되었습니다. 다시 설정해 주세요.');
  const identity=payload.token||payload.subscription.endpoint;
  const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(identity));device=Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
  // Delete old account's device at logout. A device cannot be stolen by another account.
  await setDoc(doc(db(),'notificationDevices',device),{...payload,updatedAt:serverTimestamp()});
  localStorage.setItem('lns-notification-device',JSON.stringify({uid,device}));say('이 기기 알림 연결 완료 ✓');
 }
 root.addEventListener('change',async e=>{
  if(busy)return;busy=true;const el=e.target;
  try{
   if(el.matches('[data-notify-master]')){if(el.checked)await register();await save({...prefs,enabled:el.checked});}
   if(el.dataset.notifyKind)await save({...prefs,kinds:{...prefs.kinds,[el.dataset.notifyKind]:el.checked}});
   if(el.matches('[data-notify-scope]'))await save({...prefs,scope:el.checked?'team':'mine'});
  }catch(err){draw();say(err.message);}finally{busy=false;}
 });
 root.addEventListener('click',async e=>{
  const b=e.target.closest('button');if(!b||busy)return;
  busy=true;
  try{
   if(b.hasAttribute('data-notify-register')){await register();if(!prefs.enabled)await save({...prefs,enabled:true});say('이 기기 알림 연결 완료 ✓');}
   if(b.hasAttribute('data-notify-test')){
    if(!prefs.enabled)throw Error('먼저 알림 받기를 켜 주세요.');
    await addDoc(collection(db(),'notificationTests'),{ownerUid:uid,createdAt:serverTimestamp()});say('테스트 발송을 접수했습니다. 예약 발송 작업에 따라 도착까지 지연될 수 있습니다.');
   }
   if(b.dataset.notifyOpen){const n=items.find(x=>x.id===b.dataset.notifyOpen);await updateDoc(doc(db(),'notificationInboxes',uid,'items',n.id),{read:true});document.querySelector(`[data-tab="${safeNotificationTab(n.tab)}"]`)?.click();}
  }catch(err){say(err.message);}finally{busy=false;}
 });
 root.addEventListener('submit',async e=>{
  if(!e.target.matches('[data-notify-notice]'))return;e.preventDefault();if(busy)return;busy=true;
  const button=e.target.querySelector('button');button.disabled=true;
  try{const f=new FormData(e.target),title=String(f.get('title')).trim(),body=String(f.get('body')).trim();if(!title||!body)throw Error('제목과 내용을 입력해 주세요.');if(!confirm('선택한 직원들에게 공지를 보낼까요?'))return;await addDoc(collection(db(),'notificationAnnouncements'),{title,body,teamId:String(f.get('team')),createdAt:serverTimestamp()});e.target.reset();say('공지 발송을 접수했습니다.');}catch(err){say(err.message);}finally{busy=false;button.disabled=false;}
 });
 function reset(){pluginHandles.forEach(h=>h.remove());pluginHandles=[];stops.forEach(s=>s());stops=[];uid='';items=[];root.classList.add('hidden');}
 function connect(u,pending=false){
  reset();uid=u.uid;prefs={enabled:false,kinds:{},scope:'team'};
  try{const saved=JSON.parse(localStorage.getItem('lns-notification-device')||'null');device=saved?.uid===uid?saved.device:'';}catch{}
  try{prefs={...prefs,...JSON.parse(localStorage.getItem(key())||'{}')};}catch{}
  const mount=document.getElementById(pending?'loginGate':'view-settings');mount.prepend(root);root.classList.remove('hidden');draw();
  const nativePlugin=window.Capacitor?.isNativePlatform?.()&&window.Capacitor?.Plugins?.PushNotifications;
  if(nativePlugin)nativePlugin.addListener('pushNotificationActionPerformed',n=>{if(uid)document.querySelector(`[data-tab="${safeNotificationTab(n.notification?.data?.tab)}"]`)?.click();}).then(h=>pluginHandles.push(h));
  stops.push(onSnapshot(doc(db(),'notificationPreferences',uid),s=>{if(s.exists())prefs=s.data();draw();},()=>say('알림 설정 연결을 준비 중입니다. 가입·대여 기능은 계속 사용할 수 있습니다.')));
  stops.push(onSnapshot(query(collection(db(),'notificationInboxes',uid,'items'),orderBy('createdAt','desc'),limit(50)),s=>{items=s.docs.map(d=>({id:d.id,...d.data()}));draw();},()=>{}));
 }
 return {connect,reset,refresh(){if(uid)draw();},async logout(){
  if(device&&uid)await api.deleteDoc(doc(db(),'notificationDevices',device)).catch(()=>{});device='';localStorage.removeItem('lns-notification-device');reset();
 }};
}
