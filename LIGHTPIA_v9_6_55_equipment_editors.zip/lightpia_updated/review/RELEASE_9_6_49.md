# 9.6.49 — Approved reservation checkout and overdue reminders

Administrators can explicitly confirm actual checkout of approved reservations. Stable per-item loan IDs, paired stock/loan/reservation transactions, and shared capacity locks transfer each held item to a real rental without double counting. Up to 20 equipment items are processed in one-item atomic chunks within security budgets. Interrupted requests retain completed items and resume only the remainder. Checkout dates/group are fixed once progress starts; internal/external team metadata and BOX contents are retained. Reservations remain as fulfilled history and do not automatically check out on a date.

Overdue unshipped pending/approved reservations (KST start date before today) are visible on the admin home; an on-open daily summary prompts attention. Daily admin push summaries run after 09:00 KST on the existing scheduled worker, use a receipt/lease to deduplicate, retry failures, and exclude fulfilled/cancelled/deleted items. Partial checkouts remind only about remaining items.

Tests cover 20-item access budgets, normal returns, interruptions/retries/races, forged/staff denial, BOX/EA preservation, KST boundaries, remaining capacity, daily receipt races and next-day reminders.
