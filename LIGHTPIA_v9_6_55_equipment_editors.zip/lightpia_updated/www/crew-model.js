export function validateCrewPost(data){
 for(const [key,max] of Object.entries({projectName:120,pay:80,rank:80,contact:80,location:200,details:4000}))if(typeof data[key]!=='string'||data[key].length>max||(['projectName','pay','rank','contact'].includes(key)&&!data[key].trim()))throw Error('작품명·페이·직급·연락처를 확인해 주세요.');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(data.startDate)||!/^\d{4}-\d{2}-\d{2}$/.test(data.endDate)||data.endDate<data.startDate)throw Error('모집 날짜를 확인해 주세요.');
 if(!Number.isInteger(data.slots)||data.slots<1||data.slots>99)throw Error('모집 인원은 1~99명으로 입력해 주세요.');
 return data;
}
export async function applyForCrew(api,db,postId,data,uid){
 if(!uid||!data.contact?.trim()||data.contact.length>80||!data.name?.trim()||data.memo.length>1000)throw Error('지원자 이름과 연락처를 확인해 주세요.');
 const post=api.doc(db,'company/main/crewPosts',postId),ref=api.doc(db,'company/main/crewApplications',postId+'_'+uid);
 return api.runTransaction(db,async tx=>{
  const p=await tx.get(post),old=await tx.get(ref);
  if(!p.exists()||p.data().status!=='open')throw Error('모집이 마감되었거나 삭제된 글입니다.');
  if(p.data().authorUid===uid)throw Error('본인이 올린 글에는 지원할 수 없습니다.');
  if(old.exists()&&['pending','accepted'].includes(old.data().status))throw Error('이미 지원한 글입니다.');
  tx.set(ref,{postId,applicantUid:uid,name:data.name,contact:data.contact.trim(),memo:data.memo.trim(),status:'pending',createdAt:old.exists()?old.data().createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});
 });
}
