import {serialEquipmentMatches,validateSerialImport} from './serial-model.js';
export function createSerialRegister(ui){
 const {api,esc}=ui,$=id=>document.getElementById(id),ref=(name,id)=>api.doc(ui.db(),'company/main/'+name,id);
 let rows=[],open=false,loaded=false,stopRows=null,page=0,generation=0;
 const canRead=()=>!!ui.uid()&&(ui.isAdmin()||open),money=n=>'₩'+Number(n||0).toLocaleString('ko-KR');
 function render(){
  const visible=canRead();document.querySelector('[data-tab="serials"]')?.classList.toggle('hidden',!visible);
  $('serialAdmin')?.classList.toggle('hidden',!ui.isAdmin());$('serialAdd')?.classList.toggle('hidden',!ui.isAdmin());
  if($('serialOpen'))$('serialOpen').checked=open;
  if(!visible){if(!$('view-serials')?.classList.contains('hidden'))ui.goHome();$('serialList').replaceChildren();$('serialSummary').textContent='';return;}
  const group=$('serialGroup'),selected=group.value,names=[...new Set(rows.map(r=>r.sourceName))].sort((a,b)=>a.localeCompare(b,'ko'));
  group.innerHTML='<option value="">전체</option>'+names.map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');group.value=names.includes(selected)?selected:'';
  const q=$('serialSearch').value.trim().toLocaleLowerCase(),filter=$('serialFilter').value,eq=ui.equipment(),eqNames=new Map(eq.map(e=>[e.id,e.name]));
  const counts=new Map();for(const r of rows){if(r.serial){const k=r.sourceName+'\0'+r.serial;counts.set(k,(counts.get(k)||0)+1);}}
  const duplicated=r=>!!r.serial&&counts.get(r.sourceName+'\0'+r.serial)>1;
  const list=rows.filter(r=>(!group.value||r.sourceName===group.value)&&(!filter||filter==='unlinked'&&(!r.equipmentId||!eqNames.has(r.equipmentId))||filter==='duplicate'&&duplicated(r))&&[r.sourceName,eqNames.get(r.equipmentId),r.no,r.serial,r.ballastSerial,r.note].join(' ').toLocaleLowerCase().includes(q)).sort((a,b)=>a.sourceName.localeCompare(b.sourceName,'ko')||Number(a.no)-Number(b.no)||a.id.localeCompare(b.id));
  const pages=Math.max(1,Math.ceil(list.length/40));page=Math.min(page,pages-1);
  $('serialSummary').textContent=loaded?`전체 ${rows.length.toLocaleString()}건 · 검색 ${list.length.toLocaleString()}건 · 검색 결과 기재가격 합계 ${money(list.reduce((n,r)=>n+Number(r.price||0),0))} · 장비 연결 확인 ${rows.filter(r=>!r.equipmentId||!eqNames.has(r.equipmentId)).length}건`:'시리얼 목록을 불러오는 중…';
  $('serialList').innerHTML=list.slice(page*40,(page+1)*40).map(r=>`<article class="serial-card"><strong>${esc(r.sourceName)}</strong> <span class="pill">No. ${esc(r.no)}</span>${duplicated(r)?'<span class="pill amber">중복 시리얼 확인</span>':''}<p class="meta">${r.equipmentId&&eqNames.has(r.equipmentId)?'연결 장비: '+esc(eqNames.get(r.equipmentId)):'장비 연결 확인 필요'}</p><dl><dt>본체 S/N</dt><dd><code>${esc(r.serial||'미기재')}</code></dd><dt>발라스트 S/N</dt><dd><code>${esc(r.ballastSerial||'미기재')}</code></dd><dt>날짜</dt><dd>${esc(r.date||'미기재')}</dd><dt>가격</dt><dd>${r.priceText?esc(r.priceText):'미기재'}</dd></dl><p class="meta">${esc(r.note||'')}</p>${ui.isAdmin()?`<button class="secondary" data-serial-edit="${esc(r.id)}">수정 · 장비 연결</button> <button class="danger" data-serial-delete="${esc(r.id)}">삭제</button>`:''}</article>`).join('')||(loaded?'<div class="empty">조건에 맞는 시리얼이 없습니다.</div>':'');
  $('serialPage').textContent=`${page+1} / ${pages}`;$('serialPrev').disabled=page===0;$('serialNext').disabled=page>=pages-1;
 }
 function sync(){
  if(canRead()&&!stopRows){const g=generation;stopRows=api.onSnapshot(api.collection(ui.db(),'company/main/equipmentSerials'),snap=>{if(g!==generation||!canRead())return;rows=snap.docs.map(d=>({...d.data(),id:d.id}));loaded=true;render();},()=>{rows=[];loaded=false;render();$('serialSummary').textContent='시리얼을 읽지 못했습니다. 다시 로그인해 주세요.';});}
  if(!canRead()&&stopRows){stopRows();stopRows=null;rows=[];loaded=false;}render();
 }
 function edit(id=''){
  if(!ui.isAdmin())return;const old=rows.find(r=>r.id===id)||{},eq=ui.equipment().slice().sort((a,b)=>a.name.localeCompare(b.name,'ko'));
  const field=(key,label,type='text')=>`<div class="field"><label for="serial-${key}">${label}</label><input id="serial-${key}" type="${type}" maxlength="${key==='note'?2000:300}" value="${esc(old[key]??'')}" ${key==='price'?'min="0" step="1"':''} ${key==='sourceName'?'required':''}></div>`;
  ui.modal(id?'시리얼 수정 · 장비 연결':'개별 장비 등록',`<form id="serialForm">${field('sourceName','장비명 *')}<div class="field"><label for="serial-equipment">앱 장비 연결</label><select id="serial-equipment"><option value="">미연결 · 확인 대기</option>${eq.map(e=>`<option value="${esc(e.id)}" ${e.id===old.equipmentId?'selected':''}>${esc(e.name)}</option>`).join('')}</select></div><div class="formgrid">${field('no','관리번호')}${field('date','날짜 · 원본 표기')}${field('serial','본체 S/N')}${field('ballastSerial','발라스트 S/N')}${field('price','가격 · 원','number')}</div><p class="meta">가격 미기재는 빈칸으로 두세요. 장비 수량과 대여 기록에는 영향을 주지 않습니다.</p>${field('note','메모')}<button type="submit">저장</button></form>`);
  if(!old.priceText)$('serial-price').value='';
  const form=$('serialForm');form.onsubmit=async e=>{e.preventDefault();if(!ui.isAdmin()||form.dataset.saving)return;form.dataset.saving='1';const b=form.querySelector('button');b.disabled=true;
   try{const data={};for(const k of ['sourceName','no','date','serial','ballastSerial','note'])data[k]=$('serial-'+k).value.trim();if(!data.sourceName)throw Error('장비명을 입력해 주세요.');const raw=$('serial-price').value;if(raw!==''&&(!Number.isSafeInteger(Number(raw))||Number(raw)<0))throw Error('가격을 확인해 주세요.');data.price=Number(raw||0);data.priceText=raw===''?'':money(data.price);data.equipmentId=$('serial-equipment').value;data.updatedAt=api.serverTimestamp();if(id)await api.updateDoc(ref('equipmentSerials',id),data);else await api.addDoc(api.collection(ui.db(),'company/main/equipmentSerials'),{...data,source:'관리자 직접 등록',createdAt:api.serverTimestamp()});ui.closeModal();}catch(err){alert('시리얼 저장 실패: '+err.message);}finally{delete form.dataset.saving;b.disabled=false;}
  };
 }
 for(const id of ['serialSearch','serialGroup','serialFilter'])$(id)?.addEventListener(id==='serialSearch'?'input':'change',()=>{page=0;render();});
 $('serialOpen').onchange=async e=>{const b=e.target;if(!ui.isAdmin()){b.checked=open;return;}const next=b.checked;if(next&&!confirm('가격을 포함한 시리얼 전체 목록을 승인된 직원에게 공개할까요?')){b.checked=open;return;}b.disabled=true;try{await api.setDoc(ref('appSettings','serialAccess'),{employeeRead:next,updatedAt:api.serverTimestamp()});}catch(err){b.checked=open;alert('조회 설정 저장 실패: '+err.message);}finally{b.disabled=false;}};
 $('serialAdd').onclick=()=>edit();$('serialPrev').onclick=()=>{page=Math.max(0,page-1);render();};$('serialNext').onclick=()=>{page++;render();};
 $('serialImport').onclick=()=>{if(ui.isAdmin())$('serialImportFile').click();};
 $('serialImportFile').onchange=async event=>{
  const file=event.target.files?.[0];event.target.value='';if(!file||!ui.isAdmin())return;
  try{
   if(file.size>20*1024*1024)throw Error('20MB 이하 JSON 파일을 선택해 주세요.');
   const input=validateSerialImport(JSON.parse(await file.text())),groups=[...new Set(input.map(r=>r.sourceName))],equipment=ui.equipment(),matches=new Map(groups.map(n=>[n,serialEquipmentMatches(n,equipment)])),missing=groups.filter(n=>matches.get(n).length!==1);
   ui.modal('시리얼 일괄 등록 확인',`<p>등록 대상 ${input.length.toLocaleString()}건 · 기재 가격 합계 ${money(input.reduce((n,r)=>n+r.price,0))}</p><p class="meta">명칭이 확실히 일치하는 장비만 자동 연결합니다. 연결을 지정하지 않은 항목도 원본 명칭으로 보관하며, 장비 목록과 재고 수량은 변경하지 않습니다. 이미 등록된 관리 ID는 건너뜁니다.</p><div id="serialImportMappings">${missing.map((n,i)=>`<div class="field"><label for="serialMap-${i}">${esc(n)} · ${input.filter(r=>r.sourceName===n).length}건</label><select id="serialMap-${i}"><option value="">확인 대기 · 미연결로 보관</option>${equipment.map(e=>`<option value="${esc(e.id)}">${esc(e.name)}</option>`).join('')}</select></div>`).join('')||'<p>모든 장비명이 연결되었습니다.</p>'}</div><p id="serialImportProgress" class="meta">연결 확인 필요 ${missing.length}종</p><button id="serialImportConfirm">${input.length.toLocaleString()}건 등록</button>`);
   $('serialImportConfirm').onclick=async e=>{
    if(!ui.isAdmin())return;const button=e.target;button.disabled=true;for(const select of document.querySelectorAll('#serialImportMappings select'))select.disabled=true;
    const mapping=new Map(groups.map(n=>[n,matches.get(n).length===1?matches.get(n)[0].id:'']));missing.forEach((n,i)=>mapping.set(n,$('serialMap-'+i).value));let created=0,skipped=0;
    try{for(let at=0;at<input.length;at+=100){if(!ui.isAdmin())throw Error('관리자 권한이 필요합니다.');const chunk=input.slice(at,at+100);const result=await api.runTransaction(ui.db(),async tx=>{
      const refs=chunk.map(r=>ref('equipmentSerials',r.id)),snaps=await Promise.all(refs.map(r=>tx.get(r)));let done=0,skip=0;
      chunk.forEach((row,i)=>{if(snaps[i].exists()){skip++;return;}const {id,...r}=row;tx.set(refs[i],{...r,equipmentId:mapping.get(r.sourceName)||'',createdAt:api.serverTimestamp(),updatedAt:api.serverTimestamp()});done++;});return {done,skip};});created+=result.done;skipped+=result.skip;if($('serialImportProgress'))$('serialImportProgress').textContent=`${Math.min(at+100,input.length)} / ${input.length}건 처리 · 신규 ${created}건 · 기존 ${skipped}건`;
     }if($('serialImportProgress'))$('serialImportProgress').textContent=`완료 · 신규 ${created}건 · 기존 ${skipped}건 · 장비 연결 확인 ${groups.filter(n=>!mapping.get(n)).length}종`;button.textContent='등록 완료';
    }catch(err){if($('serialImportProgress'))$('serialImportProgress').textContent=`${created}건 등록 후 중단: ${err.message}. 같은 파일로 다시 진행하면 기존 기록은 건너뜁니다.`;button.disabled=false;}
   };
  }catch(err){alert('시리얼 파일 확인 실패: '+err.message);}
 };
 $('serialExport').onclick=()=>{if(ui.isAdmin())ui.download('Lightpia_serials_'+ui.today()+'.json',new Blob([JSON.stringify({format:'lightpia-serial-register-v1',rows},null,2)],{type:'application/json'}));};
 document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b||!ui.isAdmin())return;if(b.dataset.serialEdit)edit(b.dataset.serialEdit);if(b.dataset.serialDelete&&confirm('이 시리얼 기록을 삭제할까요?')){b.disabled=true;try{await api.deleteDoc(ref('equipmentSerials',b.dataset.serialDelete));}catch(err){alert('삭제 실패: '+err.message);b.disabled=false;}}});
 return {render,canRead,reset(){generation++;stopRows?.();stopRows=null;rows=[];open=false;loaded=false;page=0;render();},subscribe(){const g=generation;const stop=api.onSnapshot(ref('appSettings','serialAccess'),snap=>{if(g!==generation)return;open=snap.exists()&&snap.data().employeeRead===true;sync();},()=>{open=false;sync();});sync();return ()=>{stop();stopRows?.();stopRows=null;};}};
}
