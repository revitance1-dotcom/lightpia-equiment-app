export const normalizeSerialEquipmentName=s=>String(s||'').toLowerCase().replace(/\[.*?\]/g,'').replace(/[^a-z0-9가-힣]/g,'');
const aliases={
 'HMI 18K SUN':['18k com','18k sun'], 'HMI 18K MAX':['18k par','18k max'],
 'HMI AS-Series 12K':['as 12k'], 'HMI 6K SUN':['as 6k'], 'HMI 4K SUN(as)':['as 4k'],
 'HMI 1.8 SUN(as)':['as 1.8k'], 'HMI M90':['m90'], 'HMI M40':['m40'], 'HMI M1.8':['m18','m1.8'],
 'ARRI 오비터(Orbiter)':['오비터','orbiter'], 'VORTEX8 (크림소스)':['vortex8','보텍스8'],
 '[ARRI]SkyPanel 60c':['s60c','skypanel s60c','skypanel 60c'],
 '[ARRI]SkyPanel S360c':['s360c','skypanel s360c'], '[ARRI] SkyPanel X':['skypanel x'], '[ARRI] Skypanel S30c':['s30c','skypanel s30c'],
 'SUPER WIND UP (6k 롤스탠드)':['6k 롤스탠드'], 'STRATO SAFE STEN (마징가)':['마징가'],
 'Tungsten T25':['t25'], 'Tungsten T12':['t12'], 'Tungsten T9':['t9'], 'Tungsten T5':['t5'], 'Tungsten T2':['t2'], 'Tungsten T1':['t1'],
 'Tungsten 650w':['650w'], 'Tungsten 300w':['300w']
};
export function serialEquipmentMatches(name,equipment){const keys=[name,...(aliases[name]||[])].map(normalizeSerialEquipmentName);return equipment.filter(e=>keys.includes(normalizeSerialEquipmentName(e.name)));}
export function validateSerialImport(value){
 const rows=Array.isArray(value)?value:value?.rows;
 if(!Array.isArray(rows)||!rows.length||rows.length>10000)throw Error('1~10,000건의 시리얼 목록이 필요합니다.');
 const ids=new Set();
 return rows.map(row=>{const {id,sourceName,no,date,serial,ballastSerial,price,priceText,note,source}=row||{};
 if(typeof id!=='string'||!/^[a-zA-Z0-9_-]{1,100}$/.test(id)||ids.has(id))throw Error('관리 ID 누락 또는 중복입니다.');ids.add(id);
 for(const [key,v] of Object.entries({sourceName,no,date,serial,ballastSerial,priceText,note,source}))if(typeof v!=='string'||v.length>(key==='note'?2000:300))throw Error('필드 형식이 잘못되었습니다: '+key);
 if(!sourceName.trim()||!Number.isSafeInteger(price)||price<0)throw Error('장비명 또는 가격을 확인해 주세요.');
 return {id,sourceName,no,date,serial,ballastSerial,price,priceText,note,source};});
}
