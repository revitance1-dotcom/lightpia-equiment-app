import {normalizeEquipmentTags} from '../www/equipment-search.js';
export function correct18kTags(name,value){
 const key=String(name||'').toUpperCase().replace(/\s+/g,'');
 if(!['18KCOM','18KPAR'].includes(key))return value;
 let tags=normalizeEquipmentTags(value).split(' ').filter(Boolean);
 if(key==='18KCOM')return normalizeEquipmentTags([...tags,'#sun','#컴'].join(' '));
 return tags.filter(t=>!['#sun','#컴'].includes(t.toLocaleLowerCase())).join(' ');
}
