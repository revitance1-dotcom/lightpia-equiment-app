const assert=require('assert');
(async()=>{const {koreanHolidays,koreanHolidayForDay,koreanHolidayText,koreaToday}=await import('../www/korean-holidays.js');
 const has=(day,name)=>assert(koreanHolidayForDay(day)?.names.includes(name),day+' '+name),sub=day=>has(day,'대체공휴일');
 // KASA 2026/2027 almanac, plus 2026 Labor/Constitution Day amendment.
 for(const [day,name] of [['2026-01-01','신정'],['2026-02-17','설날'],['2026-05-24','부처님오신날'],['2026-06-06','현충일'],['2026-09-25','추석'],['2026-10-03','개천절'],['2026-10-09','한글날'],['2026-12-25','성탄절'],['2026-05-01','노동절'],['2026-07-17','제헌절'],['2026-06-03','전국동시지방선거']])has(day,name);
 for(const day of ['2026-03-02','2026-05-25','2026-08-17','2026-10-05','2027-02-09','2027-05-03','2027-07-19','2027-08-16','2027-10-04','2027-10-11','2027-12-27'])sub(day);
 assert(!koreanHolidayForDay('2026-06-08'));assert(!koreanHolidayForDay('2027-06-07'));assert(!koreanHolidayForDay('2027-01-04'));
 has('2027-02-07','설날');has('2027-05-13','부처님오신날');has('2027-09-15','추석');assert.equal(koreanHolidays(2026).size,22);assert.equal(koreanHolidays(2027).size,24);
 for(const y of [2026,2027]){const all=new Set(koreanHolidays(y).keys());for(let d=new Date(y+'-01-01T00:00:00Z');d.getUTCFullYear()===y;d.setUTCDate(d.getUTCDate()+1))if(d.getUTCDay()===0)all.add(d.toISOString().slice(0,10));assert.equal(all.size,72);}
 // Colliding names do not invent a second weekday off.
 has('2025-05-05','어린이날');has('2025-05-05','부처님오신날');sub('2025-05-06');assert(!koreanHolidayForDay('2025-05-07'));assert(koreanHolidayText(koreanHolidayForDay('2025-05-06')).includes('부처님오신날'));
 // Chuseok's Saturday alone does not create a substitute; New Year/Memorial excluded.
 assert(!koreanHolidayForDay('2026-09-28'));sub('2020-01-27');assert(!koreanHolidayForDay('2022-12-26'));sub('2023-05-29');has('2025-01-27','임시공휴일');has('2024-10-01','임시공휴일');
 assert.equal(koreanHolidays(2019).size,0);assert.equal(koreanHolidays(2051).size,0);assert(koreanHolidays(2050).size>15);
 assert.equal(koreaToday(new Date('2026-10-29T15:01:00Z')),'2026-10-30');assert.equal(koreaToday(new Date('2026-12-31T15:01:00Z')),'2027-01-01');
 console.log('PASS Korean holidays: official 2026/2027 dates and totals, Korean lunar dates, substitute exceptions/collisions, Labor/Constitution amendments, declared one-off days, supported range and KST day/year boundary');
})().catch(e=>{console.error(e);process.exit(1)});
