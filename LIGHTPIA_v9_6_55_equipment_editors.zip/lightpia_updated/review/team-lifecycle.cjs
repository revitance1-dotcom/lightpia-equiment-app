const fs=require('fs'),vm=require('vm'),assert=require('assert');
const s=fs.readFileSync('www/app.js','utf8'),code=s.slice(s.indexOf('let teamClosing='),s.indexOf('function renderProjects(){'));
(async()=>{
 for(const scenario of ['success','reservation','failed-return','non-admin']){
 const writes=[],alerts=[],returned=[],t={id:'B',name:'B팀',projectId:'dash',active:true},a={id:'A',name:'대시',projectId:'dash',active:true},p={id:'dash',name:'대시',active:true};
 const rows=[{id:'b',teamId:'B',status:'active'},{id:'a',teamId:'A',status:'active'},{id:'legacy-b',teamId:'B',status:'active'}];
 const c={Set,isAdmin:()=>scenario!=='non-admin',teamList:[t,a],projects:[p],activeLoans:()=>rows.filter(l=>l.status==='active'),reservations:scenario==='reservation'?[{teamId:'B',status:'approved',endDate:'2099-01-01'}]:[],today:()=> '2026-10-29',confirm:()=>true,alert:x=>alerts.push(x),db:{},doc:(_,col,id)=>col+'/'+id,updateDoc:async(ref,data)=>{writes.push(ref);Object.assign(t,data)},returnLoan:async l=>{if(scenario==='failed-return')throw Error('offline');returned.push(l.id);l.status='returned'}};
 vm.createContext(c);vm.runInContext(fs.readFileSync("www/display-order.js","utf8").replace(/export /g,""),c);vm.runInContext(code,c);
 if(scenario==='non-admin')await assert.rejects(c.closeTeam('B'));else await c.closeTeam('B');
 assert(a.active&&p.active);assert.equal(rows[1].status,'active');
 if(scenario==='success'){assert.deepEqual(returned,['b','legacy-b']);assert.deepEqual(writes,['teams/B']);assert.equal(t.active,false);await c.closeTeam('B');assert.equal(writes.length,1);}
 else{assert.equal(writes.length,0);assert.equal(t.active,true);}
 }
 assert(s.includes('data-close-team='));assert(s.includes('data-member-fold="archived-teams"'));console.log('PASS team-only close, legacy team ID, sibling/project isolation, reservations, failed return retry, admin guard');
})().catch(e=>{console.error(e);process.exit(1)});
