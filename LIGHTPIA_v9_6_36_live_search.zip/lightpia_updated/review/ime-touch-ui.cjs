const fs=require('fs'),assert=require('assert'),path=require('path'),{chromium,webkit}=require('playwright');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/www/app.js','utf8');
const html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const categories=s.slice(s.indexOf('let equipmentCategoryFilter='),s.indexOf('function render(){'));
const results=s.slice(s.indexOf('function renderEquipmentList(){'),s.indexOf('function loanCard('));
const loan=s.slice(s.indexOf('function modal('),s.indexOf('function addEquipment('))+s.slice(s.indexOf('let cartItems='),s.indexOf('async function submitCart('));
const clicks=s.slice(s.indexOf('document.addEventListener("click",e=>{\n const cat='),s.indexOf('document.addEventListener("click",async e=>'));
(async()=>{
 for(const engine of process.env.CHECK_WEBKIT?['chromium','webkit']:['chromium']){
 const browser=await ({chromium,webkit}[engine]).launch({headless:true,args:engine==='chromium'?['--no-sandbox']:[]});
 try{for(const width of [320,393]){
  const page=await browser.newPage({viewport:{width,height:850},isMobile:true,hasTouch:true,locale:'ko-KR'});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.setContent(html);
  for(const name of ['equipment-search','search-input'])await page.addScriptTag({content:fs.readFileSync(root+'/www/'+name+'.js','utf8').replace(/export /g,'')});
  await page.addScriptTag({content:`const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
   const ready=true,isAdmin=()=>false,teamName='촬영팀',teamId='a',teamList=[],member={displayName:'직원'},today=()=> '2026-10-28';
   const equipment=[{id:'orbiter',name:'오비터',category:'LED',total:50},{id:'obi',name:'오비',category:'LED',total:50},{id:'com',name:'18K COM',category:'HMI',searchTags:'#sun #컴',total:50}];
   const repairQtyFor=()=>0,brokenQtyFor=()=>0,borrowedQtyFor=()=>0,untracked=()=>false,availableQtyFor=()=>50;
   function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}function submitCart(){}
   ${categories}\n${results}\n${loan}\n${clicks}
   show('app',true);show('loginGate',false);show('setupNotice',false);show('view-home',false);show('view-equipment',true);
   bindSearchInput($('equipmentSearch'),renderEquipmentList);renderEquipmentList();
   window.inputNode=$('equipmentSearch');window.renderCount=0;
   new MutationObserver(()=>window.renderCount++).observe($('equipmentList'),{childList:true});`});
  assert.equal(await page.locator('#equipmentSearch').getAttribute('contenteditable'),'plaintext-only');
  await page.locator('#equipmentSearch').focus();
  await page.evaluate(()=>{
   const input=$('equipmentSearch');input.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true}));
   window.beforeComposition=$('equipmentList').firstChild;window.beforeCount=renderCount;
   for(const text of ['오','오비','오비터']){input.textContent=text;input.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,inputType:'insertCompositionText',data:text}));}
   window.liveTextNode=input.firstChild;
  });
  // The final syllable is visible but still composing: results must update before Enter.
  await page.waitForFunction(()=>document.querySelectorAll('#equipmentList .item').length===1&&document.querySelector('#equipmentList').textContent.includes('오비터'));
  assert(await page.evaluate(()=>isSearchComposing(inputNode)&&inputNode.firstChild===liveTextNode&&$('equipmentSearch')===inputNode&&document.activeElement===inputNode));
  await page.evaluate(()=>{$('equipmentList').innerHTML='';});
  await page.locator('[data-search-submit=equipmentSearch]').tap();
  assert.equal(await page.locator('#equipmentList .item').count(),1);
  assert(await page.evaluate(()=>document.activeElement===inputNode&&isSearchComposing(inputNode)&&inputNode.firstChild===liveTextNode));

  await page.evaluate(()=>{
   const input=$('equipmentSearch');input.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'터'}));
   input.textContent='오비터';const range=document.createRange();range.selectNodeContents(input);range.collapse(false);getSelection().removeAllRanges();getSelection().addRange(range);window.commitSelectionNode=getSelection().focusNode;window.commitSelectionOffset=getSelection().focusOffset;input.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:false,inputType:'insertText',data:'터'}));
  });
  await page.waitForFunction(()=>document.querySelectorAll('#equipmentList .item').length===1);
  assert.equal(await page.locator('#equipmentSearch').textContent(),'오비터');
  assert((await page.locator('#equipmentList').innerText()).includes('오비터'));
  assert(await page.evaluate(()=>document.activeElement===inputNode&&$('equipmentSearch')===inputNode&&getSelection().focusNode===commitSelectionNode&&getSelection().focusOffset===commitSelectionOffset));
  // Android-style end: final value is already present, without another input event.
  await page.evaluate(()=>{const el=$('equipmentSearch');el.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true}));el.textContent='컴';el.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true}));el.dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'컴'}));});
  await page.waitForFunction(()=>document.querySelector('#equipmentList')?.textContent.includes('18K COM'));
  for(const q of ['#sun','18K','']){await page.locator('#equipmentSearch').fill(q);assert.equal(await page.locator('#equipmentList .item').count(),q?1:3);}
  if(engine==='chromium'){
   const cdp=await page.context().newCDPSession(page);await page.locator('#equipmentSearch').focus();
   await cdp.send('Input.imeSetComposition',{text:'오비ㅌ',selectionStart:3,selectionEnd:3});
   await cdp.send('Input.imeSetComposition',{text:'오비터',selectionStart:3,selectionEnd:3});
   await page.waitForFunction(()=>document.querySelectorAll('#equipmentList .item').length===1&&document.querySelector('#equipmentList').textContent.includes('오비터'));
   assert(await page.evaluate(()=>isSearchComposing(inputNode)));
   await cdp.send('Input.insertText',{text:'오비터'});
   await page.waitForFunction(()=>document.querySelectorAll('#equipmentList .item').length===1);
   assert.equal(await page.locator('#equipmentSearch').textContent(),'오비터');
  }
  // Real text editing: final syllable survives blur, selection replacement and backspace.
  await page.locator('#equipmentSearch').blur();
  assert.equal(await page.locator('#equipmentSearch').textContent(),'오비터');
  await page.locator('#equipmentSearch').focus();
  await page.keyboard.press('ControlOrMeta+A');await page.keyboard.insertText('오비터');
  await page.keyboard.press('End');await page.keyboard.press('Backspace');
  assert.equal(await page.locator('#equipmentSearch').textContent(),'오비');
  await page.keyboard.insertText('터');await page.keyboard.press('Enter');
  assert.equal(await page.locator('#equipmentSearch').textContent(),'오비터');
  await page.waitForFunction(()=>document.querySelectorAll('#equipmentList .item').length===1);
  await page.evaluate(()=>addLoan());await page.evaluate(()=>{window.plusNode=document.querySelector('[data-cart-plus="orbiter"]');window.rowNode=plusNode.closest('.cart-row');});
  const plus=page.locator('[data-cart-plus="orbiter"]'),minus=page.locator('[data-cart-minus="orbiter"]');
  assert.equal(await plus.evaluate(el=>getComputedStyle(el).touchAction),'manipulation');
  const viewport=await page.evaluate(()=>visualViewport.scale);
  for(let i=0;i<12;i++)await plus.tap();
  for(let i=0;i<5;i++)await minus.tap();
  assert.equal(await plus.locator('..').locator('strong').textContent(),'7');
  assert(await page.evaluate(()=>plusNode===document.querySelector('[data-cart-plus="orbiter"]')&&rowNode===plusNode.closest('.cart-row')));
  assert.equal(await page.evaluate(()=>visualViewport.scale),viewport);
  await page.evaluate(()=>{for(let i=0;i<100;i++)document.querySelector('[data-cart-plus="orbiter"]').click();});
  assert.equal(await plus.locator('..').locator('strong').textContent(),'50');assert(await plus.isDisabled());
  await page.evaluate(()=>{for(let i=0;i<100;i++)document.querySelector('[data-cart-minus="orbiter"]').click();});
  assert.equal(await plus.locator('..').locator('strong').textContent(),'0');assert(await minus.isDisabled());
  const meta=await page.locator('meta[name=viewport]').getAttribute('content');assert(!/user-scalable\s*=\s*no|maximum-scale\s*=\s*1/.test(meta));
  await page.locator('#cartSearch').focus();
  await page.evaluate(()=>{const el=$('cartSearch');el.dispatchEvent(new CompositionEvent('compositionstart',{bubbles:true}));el.textContent='오비터';el.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true,data:'오비터'}));window.cartEditorNode=el;window.cartTextNode=el.firstChild;});
  await page.waitForFunction(()=>document.querySelectorAll('.cart-row').length===1);
  assert(await page.evaluate(()=>isSearchComposing(cartEditorNode)&&cartEditorNode.firstChild===cartTextNode));
  await page.locator('[data-search-submit=cartSearch]').tap();
  assert.equal(await page.locator('.cart-row').count(),1);
  assert(await page.evaluate(()=>document.activeElement===cartEditorNode&&cartEditorNode.firstChild===cartTextNode));
  await page.evaluate(()=>{$('cartSearch').dispatchEvent(new CompositionEvent('compositionend',{bubbles:true,data:'오비터'}));});
  await page.locator('#cartSearch').fill('');await page.waitForFunction(()=>document.querySelectorAll('.cart-row').length===3);
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
  assert.equal(await page.locator('#cartSearch').getAttribute('contenteditable'),'plaintext-only');
  assert.equal(errors.length,0,errors.join('\n'));
  console.log('PASS IME/touch',engine,width,'live results during ongoing Korean composition BEFORE Enter, explicit Search tap keeps editor/IME/focus, real IME preview/commit/blur/selection/backspace, Korean final syllable, both event orders, stable focus/caret/results during composition, English/tag/clear search, repeated taps counted, stable buttons, min/max, unchanged viewport and pinch zoom available');await page.close();
 }}finally{await browser.close();}
 }
})().catch(e=>{console.error(e);process.exit(1)});
