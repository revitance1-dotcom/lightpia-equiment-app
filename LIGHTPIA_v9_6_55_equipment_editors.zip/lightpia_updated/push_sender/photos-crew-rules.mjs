import fs from 'node:fs';
export function patchPhotosCrewRules(source){
 if(source.includes('LNS_PHOTOS_CREW_V1'))return source;
 if(/match\s+\/company\/main\/(crewPosts|crewApplications|equipmentPhotos|equipmentPhotoDetails)\//.test(source))throw Error('Unexpected existing photo/crew rules');
 const marker='match /databases/{database}/documents {',at=source.indexOf(marker);if(at<0)throw Error('Unexpected rules structure');
 return source.slice(0,at+marker.length)+'\n'+fs.readFileSync(new URL('./photos-crew.rules',import.meta.url),'utf8')+source.slice(at+marker.length);
}
