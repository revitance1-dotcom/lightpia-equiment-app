const fs=require('fs'),assert=require('assert');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing');
const fire=require('firebase/firestore');
(async()=>{
 const {patchSignupRules}=await import('../push_sender/signup-rules.mjs');
 const {submitSignup}=await import('../www/signup-model.js');
 const source=fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8');
 const optional='request.resource.data.requestedTeam is string && request.resource.data.requestedTeam.size() <= 100';
 const stale=source.replace(optional,'request.resource.data.requestedTeam is string && request.resource.data.requestedTeam.size() > 0 && request.resource.data.requestedTeam.size() <= 100').replace(' // LNS_OPTIONAL_SIGNUP_TEAM_V1','');
 assert(stale!==source);const patched=patchSignupRules(stale);
 assert.equal(patchSignupRules(patched),patched);
 assert.equal(patched.replace(' // LNS_OPTIONAL_SIGNUP_TEAM_V1',''),source.replace(' // LNS_OPTIONAL_SIGNUP_TEAM_V1',''));
 const payload=()=>({email:'new@accounts.lightpia.internal',username:'new1',name:'신규 직원',requestedTeam:'',status:'pending',createdAt:fire.serverTimestamp()});
 const old=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:stale}});
 try{
  await old.clearFirestore();const db=old.authenticatedContext('new',{email:'new@accounts.lightpia.internal'}).firestore();
  await assertFails(fire.setDoc(fire.doc(db,'joinRequests/new'),payload()));
 }finally{await old.cleanup();}
 const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:source}});
 try{
  await env.clearFirestore();
  const own=env.authenticatedContext('new',{email:'new@accounts.lightpia.internal'}).firestore(),other=env.authenticatedContext('other',{email:'other@test.invalid'}).firestore(),guest=env.unauthenticatedContext().firestore();
  const ref=fire.doc(own,'joinRequests/new');
  await assertFails(fire.setDoc(fire.doc(guest,'joinRequests/new'),payload()));
  await assertFails(fire.setDoc(fire.doc(other,'joinRequests/new'),payload()));
  for(const bad of [{email:'spoof@test.invalid'},{status:'approved'},{role:'admin'},{name:''}])await assertFails(fire.setDoc(ref,{...payload(),...bad}));
  await assertSucceeds(fire.setDoc(ref,payload()));
  await assertFails(fire.getDoc(fire.doc(other,'joinRequests/new')));
  await assertFails(fire.getDocs(fire.collection(own,'joinRequests')));
  await assertFails(fire.updateDoc(ref,{status:'approved'}));
  await assertFails(fire.setDoc(fire.doc(own,'members/new'),{role:'team',active:true,teamName:'대기 직원'}));
  if(process.env.FIREBASE_AUTH_EMULATOR_HOST){
   const {initializeApp,deleteApp}=require('firebase/app'),authApi=require('firebase/auth');
   const app=initializeApp({projectId:'demo-lightpia',apiKey:'fake-key',authDomain:'demo-lightpia.firebaseapp.com'},'signup-'+Date.now());
   const auth=authApi.getAuth(app);authApi.connectAuthEmulator(auth,'http://'+process.env.FIREBASE_AUTH_EMULATOR_HOST,{disableWarnings:true});
   const db=fire.getFirestore(app),[host,port]=process.env.FIRESTORE_EMULATOR_HOST.split(':');fire.connectFirestoreEmulator(db,host,Number(port));
   const fields={email:'retry'+Date.now()+'@accounts.lightpia.internal',username:'retry1',password:'original-password',name:'재신청 직원',requestedTeam:''};
   const api={...fire,...authApi};
   try{
    await authApi.createUserWithEmailAndPassword(auth,fields.email,fields.password);
    const uid=auth.currentUser.uid;await authApi.signOut(auth);
    await assert.rejects(submitSignup(api,auth,db,{...fields,password:'incorrect-password'}));
    await env.withSecurityRulesDisabled(async c=>assert(!(await fire.getDoc(fire.doc(c.firestore(),'joinRequests',uid))).exists()));
    assert.equal(await submitSignup(api,auth,db,fields),'pending');assert.equal(auth.currentUser.uid,uid);
    assert.equal((await fire.getDoc(fire.doc(db,'joinRequests',uid))).data().requestedTeam,'');
    assert.equal(await submitSignup(api,auth,db,{...fields,name:'덮어쓰기 금지'}),'pending');
    assert.equal((await fire.getDoc(fire.doc(db,'joinRequests',uid))).data().name,'재신청 직원');
    await env.withSecurityRulesDisabled(c=>fire.updateDoc(fire.doc(c.firestore(),'joinRequests',uid),{status:'approved'}));
    assert.equal(await submitSignup(api,auth,db,fields),'approved');await authApi.signOut(auth);
    assert.equal(await submitSignup(api,auth,db,{...fields,email:'fresh'+Date.now()+'@accounts.lightpia.internal',requestedTeam:'선택한 팀'}),'pending');
   }finally{await authApi.signOut(auth);await deleteApp(app);}
  }
  console.log('PASS signup: reproduced stale required-team rejection; optional team allowed; Auth recovery requires original password; retry preserves application; approval and private-data guards intact; isolated idempotent patch');
 }finally{await env.cleanup();}
})().catch(e=>{console.error(e);process.exit(1)});
