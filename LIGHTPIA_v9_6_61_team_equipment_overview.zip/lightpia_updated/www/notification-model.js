export const notificationKinds={signup:'가입 승인',reservation:'예약 신청·승인·취소',due:'반납 예정·기한 초과',departure:'출고 전날',notice:'관리자 공지',loan:'대여·반납',join:'신규 가입 신청'};
export function acceptsNotification(p,event,uid){return p?.enabled===true&&p.kinds?.[event.kind]!==false&&(!(event.teamId&&event.ownerUid!==uid)||p.scope!=='mine');}
export function safeNotificationTab(tab){return ['home','loans','reservations','settings'].includes(tab)?tab:'settings';}

// Capacitor bridges may return a handle directly or return a Promise of a handle.
export async function attachNotificationAction(plugin,callback){return await plugin.addListener('pushNotificationActionPerformed',callback);}
export function releaseNotificationHandle(handle){try{Promise.resolve(handle?.remove?.()).catch(()=>{});}catch{}}
