import fs from 'node:fs';
export function patchEquipmentEditorRules(source){
 if(source.includes('LNS_EQUIPMENT_EDITORS_V1'))return source;
 const memberStart=source.indexOf('match /members/{uid}'),memberEnd=source.indexOf('\n  match ',memberStart+10);
 if(memberStart<0||memberEnd<0)throw Error('Unexpected member rules');
 let block=source.slice(memberStart,memberEnd);
 const keys="['role','teamName','teamId','displayName','active','updatedAt']";
 if(!block.includes(keys))throw Error('Unexpected member fields');
 block=block.replace(keys,"['role','teamName','teamId','displayName','active','updatedAt','equipmentEditor']");
 const active='&& request.resource.data.active is bool';
 if(!block.includes(active))throw Error('Missing member validation');
 block=block.replace(active,active+" && request.resource.data.get('equipmentEditor',false) is bool");
 source=source.slice(0,memberStart)+block+source.slice(memberEnd);
 for(const name of ['equipmentPhotos','equipmentPhotoDetails']){
  const start=source.indexOf('match /company/main/'+name+'/{id}'),end=source.indexOf('\n  }',start);
  if(start<0||end<0)throw Error('Missing photo rules');
  let photo=source.slice(start,end);
  if(!photo.includes('allow create, update: if admin() && validEquipmentPhoto')||!photo.includes('allow delete: if admin();'))throw Error('Unexpected photo permissions');
  photo=photo.replace('if admin() && validEquipmentPhoto','if lnsEquipmentEditor() && validEquipmentPhoto').replace('allow delete: if admin();','allow delete: if lnsEquipmentEditor();');
  source=source.slice(0,start)+photo+source.slice(end);
 }
 // Keep one equipment allow-update path: loan counter changes reject the catalog branch immediately.
 const start=source.indexOf('match /company/main/equipment/{equipmentId}'),end=source.indexOf('\n}',start)+2;
 if(start<0||end<2)throw Error('Missing equipment rules');
 let eq=source.slice(start,end);
 const create='allow create: if admin() &&';
 const metadata='(admin() && lnsEaStockSame(request.resource.data,resource.data) && request.resource.data.loaned == resource.data.loaned && request.resource.data.repairing == resource.data.repairing';
 if(!eq.includes(create)||!eq.includes(metadata))throw Error('Unexpected catalog validation');
 eq=eq.replace(create,'allow create: if lnsEquipmentEditor() && (admin() || lnsEditorCreate(request.resource.data)) &&');
 const branchEnd=eq.indexOf('\n  || (admin()',eq.indexOf(metadata));
 if(branchEnd<0)throw Error('Missing maintenance branch');
 const branchStart=eq.indexOf(metadata);
 eq=eq.slice(0,branchStart)+`(request.resource.data.loaned == resource.data.loaned && request.resource.data.repairing == resource.data.repairing
   && request.resource.data.get('brokenStock',0) == resource.data.get('brokenStock',0) && request.resource.data.get('reportRepairing',0) == resource.data.get('reportRepairing',0)
   && request.resource.data.get('lastLoanId','') == resource.data.get('lastLoanId','') && request.resource.data.get('lastMaintenanceId','') == resource.data.get('lastMaintenanceId','')
   && lnsEaStockSame(request.resource.data,resource.data) && lnsEquipmentEditor() && (admin() || lnsEditorUpdate(request.resource.data,resource.data)))`+eq.slice(branchEnd);
 source=source.slice(0,start)+eq+source.slice(end);
 const old='function lnsUnitChangeAllowed(a,b) { return lnsSameUnit(a,b) || (admin() &&';
 if(!source.includes(old))throw Error('Unexpected unit validation');
 source=source.replace(old,'function lnsUnitChangeAllowed(a,b) { return lnsSameUnit(a,b) || (lnsEquipmentEditor() &&');
 const match=source.match(/match\s+\/databases\/\{database\}\/documents\s*\{/);
 if(!match)throw Error('Unexpected rules structure');
 const at=match.index+match[0].length;
 return source.slice(0,at)+'\n'+fs.readFileSync(new URL('./equipment-editors.rules',import.meta.url),'utf8')+source.slice(at);
}
