const fs=require('fs'),assert=require('assert'),path=require('path');
const {chromium}=require('playwright');
const base=path.resolve(__dirname,'..')+'/';
const shots=process.env.UI_SCREENSHOT_DIR||'/tmp/lightpia-ui/screenshots';fs.mkdirSync(shots,{recursive:true});
const s=fs.readFileSync(base+'www/app.js','utf8');
const fn=s.slice(s.indexOf('function modal('),s.indexOf('function addEquipment('))+s.slice(s.indexOf('let cartItems='),s.indexOf('async function submitCart('));
const listener=s.slice(s.indexOf('document.addEventListener("click",e=>{\n const cat='),s.indexOf('document.addEventListener("click",async e=>'));
const html=fs.readFileSync(base+'www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 for(const [width,height] of [[393,850],[320,640],[768,1024],[850,393]]){
  const page=await browser.newPage({viewport:{width,height}});await page.setContent(html);await page.addScriptTag({content:fs.readFileSync(base+'www/equipment-search.js','utf8').replace(/export /g,'')});await page.addScriptTag({content:fs.readFileSync(base+'www/search-input.js','utf8').replace(/export /g,'')});await page.addScriptTag({content:fs.readFileSync(base+'www/loan-groups.js','utf8').replace(/export /g,'')});
  await page.addScriptTag({content:`const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const today=()=> '2026-10-27',isAdmin=()=>true,teamName='관리자',member=null,teamList=[],teamId='admin';
  const equipment=Array.from({length:35},(_,i)=>({id:'e'+i,name:'조명장비 '+(i+1),category:i%2?'LED':'HMI',model:'TEST',searchTags:'#sun'}));
  const untracked=()=>false,availableQtyFor=()=>10,borrowedQtyFor=()=>0;
  function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}
  function submitCart(){window.submitted=true;}
  ${fn}\n${listener}\naddLoan();`});
  assert(await page.locator('#cartDate').isHidden());assert(await page.locator('#cartNext').isDisabled());
  await page.locator('[data-cart-plus="e0"]').click();await page.locator('[data-cart-plus="e0"]').click();
  const bounds=await page.evaluate(()=>{const list=$('loanSelectStep').getBoundingClientRect(),footer=document.querySelector('.loan-footer').getBoundingClientRect();return {listBottom:list.bottom,footerTop:footer.top,footerBottom:footer.bottom,width:document.querySelector('.loan-modal').getBoundingClientRect().width,scroll:document.querySelector('.loan-modal').scrollWidth};});
  assert(bounds.listBottom<=bounds.footerTop+1);assert(bounds.footerBottom<=height+1);assert(bounds.scroll<=bounds.width+1);
  await page.locator('#cartNext').click();assert(await page.locator('#cartDate').isVisible());
  await page.locator('[data-loan-days="7"]').click();assert.equal(await page.locator('#cartDue').inputValue(),'2026-11-03');
  await page.locator('#cartNote').fill('테스트 촬영');
  await page.locator('#cartBack').click();assert(await page.locator('#cartDate').isHidden());assert.equal(await page.locator('[data-cart-plus="e0"]').locator('..').locator('strong').textContent(),'2');
  await page.locator('#cartNext').click();assert.equal(await page.locator('#cartDue').inputValue(),'2026-11-03');assert.equal(await page.locator('#cartNote').inputValue(),'테스트 촬영');
  await page.locator('#cartDate').fill('2026-11-05');await page.locator('#cartDate').dispatchEvent('change');assert.equal(await page.locator('#cartDue').inputValue(),'2026-11-05');
  await page.locator('#cartBack').click();
  await page.locator('#cartSearch').fill('조명장비 35');assert.equal(await page.locator('.cart-row').count(),1);await page.locator('[data-cart-plus="e34"]').click();
  await page.locator('#cartSearch').fill('');await page.locator('[data-cart-plus="e34"]').scrollIntoViewIfNeeded();await page.locator('[data-cart-plus="e34"]').click();
  if(width===393){await page.screenshot({path:path.join(shots,'loan-select.png')});await page.locator('#cartNext').click();await page.screenshot({path:path.join(shots,'loan-dates.png')});}
  console.log('PASS viewport',width,height,'no overlap, two-step navigation, selection/date/note retention, shortcuts, date correction, search and last row reachable');await page.close();
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
