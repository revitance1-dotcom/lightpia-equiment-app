const fs=require('fs'),path=require('path'),assert=require('assert'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),s=fs.readFileSync(root+'/www/app.js','utf8'),html=fs.readFileSync(root+'/www/index.html','utf8').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'');
const rendering=s.slice(s.indexOf('let equipmentCategoryFilter='),s.indexOf('function modal(')),modal=s.slice(s.indexOf('function modal('),s.indexOf('function addEquipment('));
const cart=s.slice(s.indexOf('let cartItems='),s.indexOf('function showEquipmentDetail('));
const click=s.slice(s.indexOf('document.addEventListener("click",e=>{\n const cat='),s.indexOf('document.addEventListener("click",async e=>'));
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{for(const width of [320,393,768]){
 const page=await browser.newPage({viewport:{width,height:900},locale:'ko-KR'});page.setDefaultTimeout(10000);const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());await page.setContent(html);await page.locator('#loanViewMode').evaluate(el=>el.value='details');await page.addScriptTag({content:fs.readFileSync(require('path').resolve(__dirname,'../www/display-order.js'),'utf8').replace(/export /g,'')});await page.addScriptTag({content:fs.readFileSync(path.resolve(__dirname,'../www/equipment-units.js'),'utf8').replace(/export /g,'')});
 for(const module of ['equipment-search','search-input','loan-groups','reservation-parties'])await page.addScriptTag({content:fs.readFileSync(root+'/www/'+module+'.js','utf8').replace(/export /g,'')});
 await page.addScriptTag({content:`const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const ADMIN_UID='7iSB1gW9PAhYPgi253IUk4Dooyp2',ready=true,db={},currentUser={uid:ADMIN_UID},member={displayName:'직원'},projects=[{id:'P',name:'언내추럴',active:true}],teamList=[{id:'A',name:'본팀',projectId:'P',active:true}],reservations=[];
 let adminMode=true,teamId='admin',teamName='관리자';const isAdmin=()=>adminMode,today=()=> '2026-10-28',late=l=>l.status==='active'&&l.dueDate<'2026-10-28';
 const equipment=[{id:'e',name:'오비터',category:'LED',total:100,loaned:10,repairing:0}];
 const base={equipmentId:'e',equipmentName:'오비터',quantity:1,status:'active',loanDate:'2026-10-28',dueDate:'2026-10-31',note:'기존 비고 보존',person:'직원',ownerUid:'staff',team:'본팀',teamId:'A'};
 let loans=[{...base,id:'stay',equipmentGroup:'상주장비'},{...base,id:'set',equipmentGroup:'세트장비'},{...base,id:'extra',equipmentGroup:'추가장비'},{...base,id:'legacy',ownerUid:ADMIN_UID,team:'관리자',teamId:'admin',person:'관리자'},{...base,id:'external',ownerUid:ADMIN_UID,team:'관리자',teamId:'admin',rentalType:'external',externalTeam:'외부 촬영팀',externalPerson:'김광민 기사님'},{...base,id:'other-external',ownerUid:ADMIN_UID,team:'관리자',teamId:'admin',rentalType:'external',externalPerson:'이 담당자'},{...base,id:'returned',status:'returned',equipmentGroup:'상주장비'}];
 const activeLoans=()=>loans.filter(l=>l.status!=='returned'),canHandleLoan=l=>adminMode||l.teamId===teamId,canReportDamage=()=>false,untracked=()=>false,availableQtyFor=()=>90,borrowedQtyFor=()=>10,repairQtyFor=()=>0,brokenQtyFor=()=>0;
 function show(id,on=true){$(id)?.classList.toggle('hidden',!on)}function showEquipmentDetail(){}
 const serverTimestamp=()=>0,loanDoc=id=>id,loanCol=()=>({}),doc=()=>({id:String(Math.random())}),runTransaction=()=>{};
 async function updateDoc(id,data){Object.assign(loans.find(l=>l.id===id),data);render();}
 async function submitBulkLoans(api,db,items,payload,onProgress){window.savedPayload=payload;for(const item of items)loans.push({...payload,id:item.loanId,equipmentId:item.equipmentId,equipmentName:'오비터',quantity:item.quantity,status:'active'});onProgress(items,items.length,items.length);render();}
 ${rendering}\n${modal}\n${cart}\n${click}
 $('loanSearch').addEventListener('input',render);$('loanFilter').addEventListener('change',render);
 show('app',true);show('loginGate',false);show('setupNotice',false);show('view-home',false);show('view-loans',true);render();`});

 await page.addScriptTag({content:fs.readFileSync(root+'/www/equipment-photos.js','utf8').replace(/export /g,'')});
 const returns=s.slice(s.indexOf('let bulkReturnSubmitting='),s.indexOf('async function returnLoans(')),reservation=s.slice(s.indexOf('const dateOverlap='),s.indexOf('document.addEventListener("click",e=>{const btn=e.target.closest("[data-equipment-category]")'));
 await page.addScriptTag({content:`${returns}\n${reservation}
 let photoSnapshot;window.photoReads=0;
 const equipmentPhotos=createEquipmentPhotos({esc,isAdmin,db:()=>db,uid:()=>currentUser.uid,equipment:id=>equipment.find(e=>e.id===id),modal,closeModal,error:()=>{},render:()=>{render();renderReservations()},api:{collection:()=>({}),doc:()=>({}),getDoc:async()=>{photoReads++;return {exists:()=>false}},onSnapshot:(q,callback)=>{photoSnapshot=callback;return ()=>{};}}});
 equipmentPhotos.subscribe();
 window.photo=(color)=>{const c=document.createElement('canvas');c.width=192;c.height=192;const ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,192,192);ctx.fillStyle=color;ctx.fillRect(25,25,142,142);return c.toDataURL('image/jpeg')};
 window.redPhoto=photo('#ad231d');window.bluePhoto=photo('#1d4bad');
 window.emitPhoto=value=>photoSnapshot({docs:value?[{id:'e',data:()=>({thumbnail:value})}]:[]});
 equipment[0].name='AS 6K';equipment.push({id:'nophoto',name:'사진 없는 장비',category:'HMI',total:5});
 loans.forEach(l=>l.equipmentName='AS 6K');reservations.push({id:'reservation',teamId:'A',projectId:'P',status:'pending',startDate:today(),endDate:today(),person:'담당자',items:[{id:'e',name:'AS 6K',qty:1}]});
 emitPhoto(null);
 `});
 const height=async selector=>page.locator(selector).first().evaluate(el=>el.getBoundingClientRect().height);
 const within=async selector=>assert(await page.locator(selector).first().evaluate(el=>el.scrollWidth<=el.clientWidth+1),selector+' overflow');
 // Stock board: 22px thumbnail, existing tile height, no nested button.
 await page.evaluate(()=>showStockOverview());const stockH=await height('#stockRows .stock-item');await page.evaluate(()=>emitPhoto(redPhoto));assert.equal(await height('#stockRows .stock-item'),stockH);assert.equal(await page.locator('#stockRows [data-equipment-label=e] img').count(),1);assert.equal(await page.locator('#stockRows .stock-item button').count(),0);await within('.stock-modal');
 if(width===393&&process.env.SHARED_PHOTO_SHOTS)await page.screenshot({path:process.env.SHARED_PHOTO_SHOTS+'/stock.png'});
 await page.locator('#closeModal').click();
 // Main loan/return history, also used in dashboard due/recent lists.
 await page.locator('#loanSearch').fill('AS 6K');const cardH=await height('#loanList .item');assert(await page.locator('#loanList [data-equipment-label=e] img').count()>0);await page.evaluate(()=>emitPhoto(null));assert.equal(await height('#loanList .item'),cardH);await page.evaluate(()=>emitPhoto(redPhoto));
 // Cart: only image slots change during a live update; quantities and controls stay intact.
 await page.evaluate(()=>{emitPhoto(null);addLoan()});const cartH=await height('[data-cart-row=e]');await page.locator('[data-cart-plus=e]').click();const plus=await page.locator('[data-cart-plus=e]').boundingBox();await page.evaluate(()=>emitPhoto(redPhoto));assert.equal(await height('[data-cart-row=e]'),cartH);assert.equal(await page.locator('[data-cart-row=e] .qty-control strong').textContent(),'1');assert.deepEqual(await page.locator('[data-cart-plus=e]').boundingBox(),plus);assert.equal(await page.locator('[data-cart-row=nophoto] img').count(),0);assert.equal(await page.locator('[data-cart-row=e] [data-equipment-photo]').count(),0);
 const before=await page.locator('[data-cart-row=e] img').getAttribute('src');await page.evaluate(()=>emitPhoto(bluePhoto));assert.notEqual(await page.locator('[data-cart-row=e] img').getAttribute('src'),before);await page.locator('[data-cart-plus=e]').click();assert.equal(await page.locator('[data-cart-row=e] .qty-control strong').textContent(),'2');await page.locator('#cartNext').click();assert.equal(await page.locator('#loanReviewList img').count(),1);await within('.loan-modal');await page.locator('#closeModal').click();
 // Grouped returns: image refresh must preserve the checked record and folds.
 await page.evaluate(()=>{emitPhoto(null);bulkReturnDialog()});await page.locator('#bulkReturnSearch').fill('상주장비');const returnH=await height('.return-row');await page.locator('.bulk-return-check').first().check();await page.evaluate(()=>emitPhoto(redPhoto));assert.equal(await height('.return-row'),returnH);assert(await page.locator('.bulk-return-check').first().isChecked());assert.equal(await page.locator('.return-row img').count(),1);await within('.return-modal');await page.locator('#closeModal').click();
 // Reservation history and summary use 16px marks in existing text lines.
 await page.evaluate(()=>{show('view-loans',false);show('view-reservations',true);emitPhoto(null)});const reserveCardH=await height('#reservationList .item');await page.evaluate(()=>emitPhoto(redPhoto));assert.equal(await height('#reservationList .item'),reserveCardH);assert.equal(await page.locator('#reservationList img').count(),1);
 await page.evaluate(()=>{emitPhoto(null);openReservation()});const reserveH=await height('[data-reserve-row=e]');await page.locator('[data-reserve-plus=e]').click();const rplus=await page.locator('[data-reserve-plus=e]').boundingBox();await page.evaluate(()=>emitPhoto(redPhoto));assert.equal(await height('[data-reserve-row=e]'),reserveH);assert.equal(await page.locator('[data-reserve-qty=e]').inputValue(),'1');assert.deepEqual(await page.locator('[data-reserve-plus=e]').boundingBox(),rplus);assert.equal(await page.locator('[data-reserve-row=e] img').count(),1);assert.equal(await page.locator('#reserveSelectionSummary img').count(),1);await page.locator('[data-reserve-plus=e]').click();assert.equal(await page.locator('[data-reserve-qty=e]').inputValue(),'2');await within('.modal');
 await page.evaluate(()=>emitPhoto(null));assert.equal(await page.locator('[data-reserve-row=e] img').count(),0);assert.equal(await page.locator('[data-reserve-qty=e]').inputValue(),'2');assert.equal(await page.evaluate(()=>photoReads),0,'inline views must reuse subscribed thumbnails, with no full-photo reads');assert.equal(errors.length,0,errors.join('\n'));
 console.log('PASS shared compact photos',width,'dashboard stock/loan history/cart/review/grouped return/reservation picker/history/summary, exact row heights and control positions unchanged, live replace/delete preserves counts and selection, no placeholders/nested buttons/full-photo reads, no overflow');await page.close();
}}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1)});
