const fs=require('fs'),assert=require('assert');
const {JSDOM}=require('jsdom');
(async()=>{
const dom=new JSDOM('<div id="view-settings"></div><div id="loginGate"></div>',{url:'https://example.test',runScripts:'outside-only'}),w=dom.window;
const callbacks={},writes=[];let committed=0;
const api={doc:(_,...p)=>p.join('/'),collection:(_,...p)=>p.join('/'),getDoc:async()=>({data:()=>({})}),setDoc:async()=>{},updateDoc:async(p,d)=>writes.push({p,d}),addDoc:async()=>{},onSnapshot:(p,fn)=>{callbacks[p]=fn;return ()=>{}},query:p=>p,orderBy:()=>{},limit:()=>{},serverTimestamp:()=>0,db:()=>({}),isAdmin:()=>true,teams:()=>[],escape:s=>String(s??'').replaceAll('<','&lt;'),getDocs:async()=>({docs:Array.from({length:501},(_,i)=>({ref:'item/'+i}))}),writeBatch:()=>({update:(p,d)=>writes.push({p,d}),commit:async()=>{committed++;}})};
w.eval(fs.readFileSync('www/notification-model.js','utf8').replaceAll('export ','')+'\n'+fs.readFileSync('www/notifications.js','utf8').replace(/^import[^\n]*\n/,'').replace('export ',''));
const center=w.createNotifications(api);center.connect({uid:'u'});
callbacks['notificationInboxes/u/items']({docs:[{id:'a',data:()=>({title:'대여',body:'8건',read:false})},{id:'b',data:()=>({title:'삭제됨',body:'숨김',read:false,deleted:true})}]});
assert.equal(w.document.querySelectorAll('[data-notify-open]').length,1);assert(w.document.querySelector('summary').textContent.includes('1건'));
w.document.querySelector('[data-notify-delete=a]').click();await new Promise(setImmediate);assert.deepEqual(writes[0],{p:'notificationInboxes/u/items/a',d:{deleted:true,read:true}});
w.confirm=()=>false;w.document.querySelector('[data-notify-clear]').click();await new Promise(setImmediate);assert.equal(committed,0);
w.confirm=()=>true;w.document.querySelector('[data-notify-clear]').click();await new Promise(setImmediate);assert.equal(committed,2);assert.equal(writes.length,502);
callbacks['notificationInboxes/u/items']({docs:[{id:'a',data:()=>({title:'대여',body:'8건',read:true,deleted:true})}]});assert.equal(w.document.querySelectorAll('[data-notify-open]').length,0);assert(w.document.querySelector('summary').textContent.includes('0건'));assert(w.document.querySelector('[data-notify-clear]').disabled);
center.reset();dom.window.close();console.log('PASS inbox deletion: owner path, hidden tombstones, unread count, confirmation cancellation, 501-item bulk deletion, empty state');
})().catch(e=>{console.error(e);process.exit(1)});
