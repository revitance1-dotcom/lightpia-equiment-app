import admin from 'firebase-admin';
import {correct18kTags} from './tag-correction-model.mjs';
const account=JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON||'null');
if(account?.project_id!=='light-4e07d')throw Error('Unexpected project');
admin.initializeApp({credential:admin.credential.cert(account)});
const db=admin.firestore(),marker=db.doc('appMigrations/equipment-tags-v9630');
if((await marker.get()).exists()){console.log('Equipment tag correction already applied.');process.exit(0);}
const snapshot=await db.collection('company/main/equipment').get();
const targets=snapshot.docs.filter(d=>['18KCOM','18KPAR'].includes(String(d.data().name||'').toUpperCase().replace(/\s+/g,'')));
// Refuse ambiguous names instead of editing an unintended record.
for(const name of ['18KCOM','18KPAR'])if(targets.filter(d=>String(d.data().name).toUpperCase().replace(/\s+/g,'')===name).length!==1)throw Error('Expected one equipment record for each named correction target.');
await db.runTransaction(async tx=>{
 const existing=await tx.get(marker);if(existing.exists())return;
 const records=await Promise.all(targets.map(d=>tx.get(d.ref))),audit=[];
 for(const snap of records){
  if(!snap.exists())throw Error('Equipment changed during correction');
  const data=snap.data(),before=data.searchTags||'',after=correct18kTags(data.name,before);
  audit.push({equipmentId:snap.id,name:data.name,before,after});
  if(after!==before)tx.update(snap.ref,{searchTags:after,updatedAt:admin.firestore.FieldValue.serverTimestamp()});
 }
 // Preserve original tags in a server-only audit document; run this correction once.
 tx.create(marker,{records:audit,completedAt:admin.firestore.FieldValue.serverTimestamp()});
});
console.log('Applied and audited the two requested equipment tag corrections.');
