const fs=require('fs'),assert=require('assert');
const {initializeTestEnvironment,assertSucceeds,assertFails}=require('@firebase/rules-unit-testing');
const {doc,setDoc,getDoc,getDocs,collection,updateDoc,writeBatch,serverTimestamp}=require('firebase/firestore');
const ADMIN='7iSB1gW9PAhYPgi253IUk4Dooyp2';
(async()=>{
 if(!process.env.FIRESTORE_EMULATOR_HOST)throw Error('Emulator required');
 const env=await initializeTestEnvironment({projectId:'demo-lightpia',firestore:{rules:fs.readFileSync(process.env.RULES_FILE||'firestore.rules','utf8')}});
 try{
 await env.clearFirestore();
 await env.withSecurityRulesDisabled(async c=>{const store=c.firestore();await setDoc(doc(store,'members','employee'),{active:true,role:'team',teamName:'대기 직원'});await setDoc(doc(store,'projects','closed'),{name:'종료 작품',active:false});await setDoc(doc(store,'projects','open'),{name:'진행 작품',active:true});});
 await env.withSecurityRulesDisabled(async c=>{const store=c.firestore();await setDoc(doc(store,'teams','closed-team'),{name:'B팀',active:false});await setDoc(doc(store,'teams','open-team'),{name:'대시',active:true});});
 const a=env.authenticatedContext(ADMIN).firestore(),e=env.authenticatedContext('employee').firestore(),guest=env.unauthenticatedContext().firestore();
 const payload=(type,id)=>({type,targetId:id,targetName:'테스트',createdBy:ADMIN,status:'pending',createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
 await assertFails(setDoc(doc(e,'adminOperations','delete_user_employee'),payload('delete_user','employee')));
 await assertFails(getDocs(collection(e,'adminOperations')));await assertFails(getDocs(collection(guest,'adminOperations')));
 await assertFails(setDoc(doc(a,'adminOperations','delete_user_'+ADMIN),payload('delete_user',ADMIN)));
 await assertFails(setDoc(doc(a,'adminOperations','delete_project_open'),payload('delete_project','open')));
 await assertFails(setDoc(doc(a,'adminOperations','delete_user_missing'),payload('delete_user','missing')));
 await assertSucceeds(setDoc(doc(a,'adminOperations','delete_team_closed-team'),payload('delete_team','closed-team')));
 await assertFails(setDoc(doc(a,'adminOperations','delete_team_open-team'),payload('delete_team','open-team')));
 await assertFails(setDoc(doc(e,'adminOperations','delete_team_closed-team'),payload('delete_team','closed-team')));
 const batch=writeBatch(a);batch.update(doc(a,'members','employee'),{active:false,updatedAt:serverTimestamp()});batch.set(doc(a,'adminOperations','delete_user_employee'),payload('delete_user','employee'));await assertSucceeds(batch.commit());
 assert.equal((await getDoc(doc(a,'members','employee'))).data().active,false);
 await assertSucceeds(setDoc(doc(a,'adminOperations','delete_project_closed'),payload('delete_project','closed')));
 await assertFails(updateDoc(doc(a,'adminOperations','delete_user_employee'),{targetId:ADMIN}));
 await assertFails(updateDoc(doc(a,'adminOperations','delete_user_employee'),{status:'completed'}));
 await env.withSecurityRulesDisabled(c=>updateDoc(doc(c.firestore(),'adminOperations','delete_user_employee'),{status:'failed',error:'test'}));
 await assertSucceeds(updateDoc(doc(a,'adminOperations','delete_user_employee'),{status:'pending',error:'',updatedAt:serverTimestamp()}));
 let b=writeBatch(a);for(let i=0;i<50;i++)b.set(doc(a,'company/main/equipment','bulk'+i),{name:'장비'+i,total:i,loaned:0,repairing:0});await assertSucceeds(b.commit());
 await assertFails(setDoc(doc(e,'company/main/equipment','staff-create'),{name:'장비',total:1,loaned:0,repairing:0}));
 b=writeBatch(a);b.set(doc(a,'company/main/equipment','atomic-good'),{name:'정상',total:1,loaned:0,repairing:0});b.set(doc(a,'company/main/equipment','atomic-bad'),{name:'오류',total:-1,loaned:0,repairing:0});await assertFails(b.commit());assert(!(await getDoc(doc(a,'company/main/equipment','atomic-good'))).exists());
 console.log('PASS: admin-only queue, self/active-project protection, immutable targets, retry restrictions, immediate access removal, 50-item registration, atomic rollback');
 }finally{await env.cleanup();}
})().catch(e=>{console.error(e);process.exit(1)});
