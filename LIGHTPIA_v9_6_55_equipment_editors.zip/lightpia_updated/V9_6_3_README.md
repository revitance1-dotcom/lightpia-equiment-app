V9.6.3: stray brace removed; compact responsive header; app display name Lightpia&Softsun; build workflow produces Lightpia&Softsun.apk. Existing Firebase appId remains unchanged.
