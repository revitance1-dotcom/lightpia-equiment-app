const {spawnSync}=require('child_process');
for(const file of ['review/admin-rules.cjs','review/maintenance-rules.cjs']){const r=spawnSync(process.execPath,[file],{stdio:'inherit',env:process.env});if(r.status!==0)process.exit(r.status||1);}
